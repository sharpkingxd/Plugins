package dev.krispyy;

import dev.krispyy.gui.ClickGUI;
import dev.krispyy.manager.ConfigManager;
import dev.krispyy.manager.EventManager;
import dev.krispyy.module.ModuleManager;
import java.io.File;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_638;
import net.minecraft.class_746;

public final class DonutBBC {
   public ConfigManager configManager;
   public ModuleManager MODULE_MANAGER;
   public EventManager EVENT_BUS;
   public static class_310 mc;
   public String version;
   public static DonutBBC INSTANCE;
   public boolean shouldPreventClose;
   public ClickGUI GUI;
   public class_437 screen;
   public long modified;
   public File jar;

   public DonutBBC() {
      try {
         INSTANCE = this;
         this.version = " b1.3";
         this.screen = null;
         this.EVENT_BUS = new EventManager();
         this.MODULE_MANAGER = new ModuleManager();
         this.GUI = new ClickGUI();
         this.configManager = new ConfigManager();
         this.getConfigManager().loadProfile();
         this.jar = new File(DonutBBC.class.getProtectionDomain().getCodeSource().getLocation().toURI());
         this.modified = this.jar.lastModified();
         this.shouldPreventClose = false;
         mc = class_310.method_1551();
      } catch (Throwable var2) {
         var2.printStackTrace(System.err);
      }

   }

   public static boolean isInWorld() {
      return mc != null && mc.field_1724 != null && mc.field_1687 != null;
   }

   public static class_746 getPlayerSafe() {
      return isInWorld() ? mc.field_1724 : null;
   }

   public static class_638 getWorldSafe() {
      return isInWorld() ? mc.field_1687 : null;
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public ModuleManager getModuleManager() {
      return this.MODULE_MANAGER;
   }

   public EventManager getEventBus() {
      return this.EVENT_BUS;
   }

   public void resetModifiedDate() {
      this.jar.setLastModified(this.modified);
   }
}
