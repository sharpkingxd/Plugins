package dev.krispyy;

import net.fabricmc.api.ModInitializer;

public final class Main implements ModInitializer {
   public void onInitialize() {
      new DonutBBC();
   }
}
