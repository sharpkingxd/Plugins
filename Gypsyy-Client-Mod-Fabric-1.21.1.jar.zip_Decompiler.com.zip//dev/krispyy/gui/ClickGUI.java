package dev.krispyy.gui;

import dev.krispyy.DonutBBC;
import dev.krispyy.gui.components.FriendsBox;
import dev.krispyy.gui.components.FriendsFilter;
import dev.krispyy.gui.components.ItemBox;
import dev.krispyy.gui.components.ItemFilter;
import dev.krispyy.gui.components.MacroBox;
import dev.krispyy.gui.components.MacroFilter;
import dev.krispyy.gui.components.ModuleButton;
import dev.krispyy.gui.components.StringBox;
import dev.krispyy.gui.components.TextBox;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg;
import dev.krispyy.module.Category;
import dev.krispyy.module.Module;
import dev.krispyy.module.setting.BindSetting;
import dev.krispyy.module.setting.BooleanSetting;
import dev.krispyy.module.setting.ColorSetting;
import dev.krispyy.module.setting.FriendsSetting;
import dev.krispyy.module.setting.ItemSetting;
import dev.krispyy.module.setting.MacroSetting;
import dev.krispyy.module.setting.MinMaxSetting;
import dev.krispyy.module.setting.ModeSetting;
import dev.krispyy.module.setting.NumberSetting;
import dev.krispyy.module.setting.Setting;
import dev.krispyy.module.setting.StringSetting;
import java.awt.Color;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class ClickGUI extends class_437 {
   private static final Color invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = new Color(15, 15, 20, 245);
   private static final Color invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = new Color(25, 25, 35, 200);
   private static final Color invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = new Color(35, 35, 50, 180);
   private static final Color invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = new Color(139, 92, 246);
   private static final Color invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = new Color(99, 102, 241);
   private static final Color invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = new Color(248, 250, 252);
   private static final Color invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = new Color(148, 163, 184);
   private static final Color invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = new Color(100, 116, 139);
   private static final Color invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = new Color(34, 197, 94);
   private static final Color invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX = new Color(239, 68, 68);
   private static final Color invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg = new Color(255, 255, 255, 15);
   private int invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn = -1;
   private int invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav = -1;
   private final int invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft = 900;
   private final int invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK = 600;
   private final int invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG = 220;
   private final int invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy = 24;
   private Category invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu;
   private Module invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz;
   private String invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL;
   private boolean invokeConnorftw_KRISPYYCLIENT_avFlPzcXVFPfpYsCnkluLdXBQXniIsPgxwitwcsfrezoOzxLxrzeeog;
   private int invokeConnorftw_KRISPYYCLIENT_KoQcacrsFXDUvaeYSUpxlHNTvxbojrxdn;
   private int invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi;
   private boolean invokeConnorftw_KRISPYYCLIENT_rmJDFppvXdYxPyprpilioqmyebbamOHxkrbhlzzgwmObbvjlabbgUAgMR;
   private float invokeConnorftw_KRISPYYCLIENT_PyrJMQRvJViwseVKxigfeEdjitrrOJgLObaomPdRWTm;
   private float invokeConnorftw_KRISPYYCLIENT_bfzznteptasTrbjozkexnYqkWwqwqyMHBftc;
   private float invokeConnorftw_KRISPYYCLIENT_xUcJMYtgoHIuOdnAxUvlqksvbmhmLDltyNsgdMhhzeNxzgz;
   private boolean invokeConnorftw_KRISPYYCLIENT_xZrhvVPvluscyEkHsxngLlULvdpXzPrEsWIpWjgfsuHolnwuip;
   private int invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun;
   private int invokeConnorftw_KRISPYYCLIENT_slcehdGLvyoZNZqWHWcqoJXTexSXpQFXETbcNjfgzX;
   private boolean invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ;
   private Setting invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci;

   public ClickGUI() {
      super(class_2561.method_43473());
      this.invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu = Category.CRYSTAL;
      this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz = null;
      this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL = "";
      this.invokeConnorftw_KRISPYYCLIENT_avFlPzcXVFPfpYsCnkluLdXBQXniIsPgxwitwcsfrezoOzxLxrzeeog = false;
      this.invokeConnorftw_KRISPYYCLIENT_KoQcacrsFXDUvaeYSUpxlHNTvxbojrxdn = 0;
      this.invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi = 0;
      this.invokeConnorftw_KRISPYYCLIENT_rmJDFppvXdYxPyprpilioqmyebbamOHxkrbhlzzgwmObbvjlabbgUAgMR = false;
      this.invokeConnorftw_KRISPYYCLIENT_PyrJMQRvJViwseVKxigfeEdjitrrOJgLObaomPdRWTm = 0.0F;
      this.invokeConnorftw_KRISPYYCLIENT_bfzznteptasTrbjozkexnYqkWwqwqyMHBftc = 0.0F;
      this.invokeConnorftw_KRISPYYCLIENT_xUcJMYtgoHIuOdnAxUvlqksvbmhmLDltyNsgdMhhzeNxzgz = 0.0F;
      this.invokeConnorftw_KRISPYYCLIENT_xZrhvVPvluscyEkHsxngLlULvdpXzPrEsWIpWjgfsuHolnwuip = false;
      this.invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun = 0;
      this.invokeConnorftw_KRISPYYCLIENT_slcehdGLvyoZNZqWHWcqoJXTexSXpQFXETbcNjfgzX = 0;
      this.invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ = false;
      this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci = null;
   }

   public void method_25394(class_332 this, int v1, int i2, float i3) {
      int i5 = (int)((double)i2 * class_310.method_1551().method_22683().method_4495());
      int i6 = (int)((double)i3 * class_310.method_1551().method_22683().method_4495());
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm();
      if (this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn == -1 || this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav == -1) {
         int i7 = class_310.method_1551().method_22683().method_4480();
         int i8 = class_310.method_1551().method_22683().method_4507();
         this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn = (i7 - 900) / 2;
         this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav = (i8 - 600) / 2;
      }

      if (this.invokeConnorftw_KRISPYYCLIENT_xZrhvVPvluscyEkHsxngLlULvdpXzPrEsWIpWjgfsuHolnwuip) {
         this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn = i5 - this.invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun;
         this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav = i6 - this.invokeConnorftw_KRISPYYCLIENT_slcehdGLvyoZNZqWHWcqoJXTexSXpQFXETbcNjfgzX;
      }

      this.invokeConnorftw_KRISPYYCLIENT_xUcJMYtgoHIuOdnAxUvlqksvbmhmLDltyNsgdMhhzeNxzgz = Math.min(1.0F, this.invokeConnorftw_KRISPYYCLIENT_xUcJMYtgoHIuOdnAxUvlqksvbmhmLDltyNsgdMhhzeNxzgz + f4 * 0.05F);
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1);
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, i5, i6, f4);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy();
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 this) {
      int i2 = class_310.method_1551().method_22683().method_4480();
      int i3 = class_310.method_1551().method_22683().method_4507();
      Color v4 = new Color(10, 10, 15, 180);
      Color v5 = new Color(20, 15, 30, 200);
      v1.method_25296(0, 0, i2, i3, v4.getRGB(), v5.getRGB());
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, i3, i2);
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 this, int v1, int i2) {
      long j4 = System.currentTimeMillis();

      for(int i6 = 0; i6 < 15; ++i6) {
         float f7 = (float)((double)((float)i3 * 0.1F * (float)i6) + Math.sin(((double)j4 / 5000.0D + (double)i6) * 3.1415926536D) * 100.0D);
         float f8 = (float)((double)((float)i2 * 0.15F) + Math.cos(((double)j4 / 7000.0D + (double)i6) * 3.1415926536D) * 80.0D);
         int i9 = 3 + i6 % 3;
         Color v10 = new Color(invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRed(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getGreen(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getBlue(), 8 + i6);
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), v10, (double)f7, (double)f8, (double)i9, 16);
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 this, int v1, int i2, float i3) {
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, (double)this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn, (double)this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav, 900.0D, 600.0D, 16.0D, 100.0D);
      Color v5 = new Color(invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRed(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getGreen(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getBlue(), 60);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, v5, (double)this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn, (double)this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav, (double)(this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn + 900), (double)(this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + 600), 16.0D, 16.0D, 16.0D, 16.0D, 1.5D, 100.0D);
      this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1, i2, i3);
      this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1, i2, i3, f4);
      this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(v1, i2, i3, f4);
      if (this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz != null) {
         this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm(v1, i2, i3, f4);
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_332 this, int v1, int i2) {
      int i4 = 60;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), new Color(30, 30, 40, 150), (double)this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn, (double)this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav, 900.0D, (double)i4, 16.0D, 100.0D);
      String v5 = "GYPSY CLIENT";
      int i6 = this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn + 24;
      int i7 = this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + (i4 - 8) / 2;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v5, v1, i6, i7, invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRGB());
      String v8 = "v1.3 - discord.gg/vzXzFpv2gk";
      int i9 = i6 + dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v5) + 12;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), new Color(invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRed(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getGreen(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getBlue(), 60), (double)i9, (double)(i7 - 2), 45.0D, 14.0D, 7.0D, 50.0D);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v8, v1, i9 + 8, i7, invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.getRGB());
      int i10 = this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn + 900 - 50;
      int i11 = this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + (i4 - 30) / 2;
      int i12 = i2 >= i10 && i2 <= i10 + 30 && i3 >= i11 && i3 <= i11 + 30;
      Color v13 = i12 ? new Color(invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getRed(), invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getGreen(), invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getBlue(), 100) : new Color(60, 60, 70, 80);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), v13, (double)i10, (double)i11, 30.0D, 30.0D, 8.0D, 50.0D);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp("✕", v1, i10 + 15, i11 + 8, invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.getRGB());
      v1.method_25294(this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn, this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + i4, this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn + 900, this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + i4 + 1, (new Color(invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRed(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getGreen(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getBlue(), 30)).getRGB());
   }

   private void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_332 this, int v1, int i2, float i3) {
      int i5 = this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn;
      int i6 = this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + 60;
      int i7 = 540;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp, (double)i5, (double)i6, 220.0D, (double)i7, 0.0D, 100.0D);
      int i8 = i6 + 24;
      Category[] v9 = Category.values();

      for(int i10 = 0; i10 < v9.length; ++i10) {
         Category v11 = v9[i10];
         int i12 = v11 == this.invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu;
         int i13 = i2 >= i5 && i2 <= i5 + 220 && i3 >= i8 && i3 <= i8 + 46;
         Color v14;
         if (i12) {
            v14 = new Color(invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRed(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getGreen(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getBlue(), 120);
         } else if (i13) {
            v14 = new Color(50, 50, 65, 100);
         } else {
            v14 = new Color(40, 40, 55, 60);
         }

         int i15 = i5 + 12;
         int i16 = 196;
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), v14, (double)i15, (double)i8, (double)i16, 46.0D, 10.0D, 80.0D);
         if (i12) {
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm, (double)i15, (double)i8, 4.0D, 46.0D, 2.0D, 50.0D);
         }

         int i17 = i15 + 16;
         int i18 = i8 + 23;
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), i12 ? invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm : invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku, (double)i17, (double)i18, 6.0D, 12);
         int i19 = i17 + 20;
         int i20 = i8 + 19;
         Color v21 = i12 ? invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo : invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v11.name, v1, i19, i20, v21.getRGB());
         int i22 = DonutBBC.INSTANCE.getModuleManager().a(v11).size();
         String v23 = String.valueOf(i22);
         int i24 = i15 + i16 - 40;
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), new Color(50, 50, 60, 100), (double)i24, (double)(i8 + 14), 28.0D, 18.0D, 9.0D, 50.0D);
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v23, v1, i24 + 14, i8 + 19, invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW.getRGB());
         i8 += 54;
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(class_332 this, int v1, int i2, float i3) {
      int i5 = this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn + 220;
      int i6 = this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + 60;
      int i7 = 680 - (this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz != null ? 320 : 0);
      int i8 = 540;
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, i5, i6, i7, i2, i3);
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, i5, i6 + 70, i7, i8 - 70, i2, i3, f4);
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 this, int v1, int i2, int i3, int i4, int i5) {
      int i7 = 46;
      int i8 = i2 + 24;
      int i9 = i3 + 24;
      int i10 = i4 - 48;
      int i11 = i5 >= i8 && i5 <= i8 + i10 && i6 >= i9 && i6 <= i9 + i7;
      Color v12 = !i11 && !this.invokeConnorftw_KRISPYYCLIENT_avFlPzcXVFPfpYsCnkluLdXBQXniIsPgxwitwcsfrezoOzxLxrzeeog ? invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp : invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), v12, (double)i8, (double)i9, (double)i10, (double)i7, 12.0D, 80.0D);
      int i13 = i8 + 16;
      int i14 = i9 + 23;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("\ud83d\udd0d", v1, i13, i14 - 4, invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.getRGB());
      String v15 = this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL.isEmpty() ? "Search modules..." : this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL;
      Color v16 = this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL.isEmpty() ? invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW : invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v15, v1, i13 + 24, i9 + 19, v16.getRGB());
      if (this.invokeConnorftw_KRISPYYCLIENT_avFlPzcXVFPfpYsCnkluLdXBQXniIsPgxwitwcsfrezoOzxLxrzeeog && System.currentTimeMillis() / 500L % 2L == 0L) {
         int i17 = i13 + 24 + dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL);
         v1.method_25294(i17, i9 + 15, i17 + 1, i9 + 31, invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.getRGB());
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 this, int v1, int i2, int i3, int i4, int i5, int i6, float i7) {
      List v9 = DonutBBC.INSTANCE.getModuleManager().a(this.invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu);
      if (!this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL.isEmpty()) {
         v9 = (List)v9.stream().filter((v1x) -> {
            return v1x.getName().toString().toLowerCase().contains(this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL.toLowerCase());
         }).collect(Collectors.toList());
      }

      int i10 = 260;
      int i11 = 100;
      int i12 = 16;
      int i13 = Math.max(1, (i4 - 48) / (i10 + i12));
      int i14 = i2 + 24;
      int i15 = i3 + 24;
      double d16 = class_310.method_1551().method_22683().method_4495();
      int i18 = (int)((double)i2 / d16);
      int i19 = (int)((double)i3 / d16);
      int i20 = (int)((double)i4 / d16);
      int i21 = (int)((double)i5 / d16);
      v1.method_44379(i18, i19, i18 + i20, i19 + i21);

      for(int i22 = 0; i22 < v9.size(); ++i22) {
         Module v23 = (Module)v9.get(i22);
         int i24 = i22 / i13;
         int i25 = i22 % i13;
         int i26 = i14 + i25 * (i10 + i12);
         int i27 = i15 + i24 * (i11 + i12) - this.invokeConnorftw_KRISPYYCLIENT_KoQcacrsFXDUvaeYSUpxlHNTvxbojrxdn * 50;
         if (i27 + i11 >= i3 && i27 <= i3 + i5) {
            int i28 = i6 >= i26 && i6 <= i26 + i10 && i7 >= i27 && i7 <= i27 + i11;
            int i29 = v23.isEnabled();
            int i30 = v23 == this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz;
            Color v31;
            if (i30) {
               v31 = new Color(invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRed(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getGreen(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getBlue(), 80);
            } else if (i28) {
               v31 = new Color(45, 45, 60, 180);
            } else {
               v31 = invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
            }

            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), v31, (double)i26, (double)i27, (double)i10, (double)i11, 12.0D, 80.0D);
            Color v32 = i29 ? invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh : new Color(60, 60, 70);
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), v32, (double)(i26 + 20), (double)(i27 + 26), 6.0D, 12);
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v23.getName().toString(), v1, i26 + 36, i27 + 22, invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.getRGB());
            String v33 = v23.getDescription().toString();
            if (dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v33) > i10 - 32) {
               while(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v33 + "...") > i10 - 32 && v33.length() > 1) {
                  v33 = v33.substring(0, v33.length() - 1);
               }

               v33 = v33 + "...";
            }

            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v33, v1, i26 + 16, i27 + 50, invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW.getRGB());
            int i34 = i26 + i10 - 60;
            int i35 = i27 + i11 - 34;
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, i34, i35, i29, i28);
            if (i28) {
               dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm, (double)i26, (double)i27, (double)(i26 + i10), (double)(i27 + i11), 12.0D, 12.0D, 12.0D, 12.0D, 1.5D, 80.0D);
            }
         }
      }

      v1.method_44380();
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 this, int v1, int i2, boolean i3, boolean i4) {
      int i6 = 44;
      int i7 = 24;
      Color v8 = i4 ? new Color(invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getRed(), invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getGreen(), invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getBlue(), 150) : new Color(60, 60, 70, 150);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), v8, (double)i2, (double)i3, (double)i6, (double)i7, 12.0D, 60.0D);
      int i9 = 18;
      float f10 = i4 ? (float)(i2 + i6 - i9 - 3) : (float)(i2 + 3);
      Color v11 = i4 ? invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh : new Color(140, 140, 150);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), v11, (double)(f10 + (float)i9 / 2.0F), (double)((float)i3 + (float)i7 / 2.0F), (double)((float)i9 / 2.0F), 16);
   }

   private void invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm(class_332 this, int v1, int i2, float i3) {
      int i5 = 300;
      int i6 = this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn + 900 - i5;
      int i7 = this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + 60;
      int i8 = 540;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), new Color(20, 20, 30, 200), (double)i6, (double)i7, (double)i5, (double)i8, 0.0D, 100.0D);
      int i9 = i7 + 24;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz.getName().toString(), v1, i6 + 24, i9, invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.getRGB());
      int i10 = i6 + i5 - 40;
      int i11 = i2 >= i10 && i2 <= i10 + 24 && i3 >= i9 - 4 && i3 <= i9 + 20;
      Color v12 = i11 ? new Color(invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getRed(), invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getGreen(), invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getBlue(), 100) : invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), v12, (double)i10, (double)(i9 - 4), 24.0D, 24.0D, 8.0D, 50.0D);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp("✕", v1, i10 + 12, i9 + 2, invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.getRGB());
      int i13 = i9 + 40;
      List v14 = this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz.getSettings();

      for(Iterator v15 = v14.iterator(); v15.hasNext(); i13 += 70) {
         Setting v16 = (Setting)v15.next();
         if (i13 + 60 > i7 + i8) {
            break;
         }

         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, i6 + 24, i13, i5 - 48, v16, i2, i3);
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 this, int v1, int i2, int i3, Setting i4, int v5, int i6) {
      int i8 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v5);
      int i9 = i6 >= i2 && i6 <= i2 + i4 && i7 >= i3 && i7 <= i3 + i8;
      Color v10 = i9 ? new Color(40, 40, 55, 120) : new Color(30, 30, 40, 80);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), v10, (double)i2, (double)i3, (double)i4, (double)i8, 10.0D, 60.0D);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v5.getName().toString(), v1, i2 + 12, i3 + 12, invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.getRGB());
      if (v5 instanceof BooleanSetting) {
         Setting v11 = (BooleanSetting)v5;
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, i2 + i4 - 56, i3 + 16, v11.getValue(), i9);
      } else {
         String v12;
         int i13;
         int i14;
         int i15;
         double d16;
         if (v5 instanceof NumberSetting) {
            Setting v11 = (NumberSetting)v5;
            v12 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v11);
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v12, v1, i2 + i4 - dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v12) - 12, i3 + 12, invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRGB());
            i13 = i3 + 36;
            i14 = i2 + 12;
            i15 = i4 - 24;
            v1.method_25294(i14, i13, i14 + i15, i13 + 4, (new Color(60, 60, 70)).getRGB());
            d16 = (v11.getValue() - v11.getMin()) / (v11.getMax() - v11.getMin());
            int i18 = (int)((double)i15 * d16);
            v1.method_25294(i14, i13, i14 + i18, i13 + 4, invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRGB());
            int i19 = i14 + i18;
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm, (double)i19, (double)(i13 + 2), 6.0D, 12);
         } else if (v5 instanceof MinMaxSetting) {
            Setting v11 = (MinMaxSetting)v5;
            v12 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v11);
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v12, v1, i2 + i4 - dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v12) - 12, i3 + 12, invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRGB());
            i13 = i3 + 36;
            i14 = i2 + 12;
            i15 = i4 - 24;
            v1.method_25294(i14, i13, i14 + i15, i13 + 4, (new Color(60, 60, 70)).getRGB());
            d16 = (v11.getCurrentMin() - v11.getMinValue()) / (v11.getMaxValue() - v11.getMinValue());
            double d18 = (v11.getCurrentMax() - v11.getMinValue()) / (v11.getMaxValue() - v11.getMinValue());
            int i20 = i14 + (int)((double)i15 * d16);
            int i21 = i14 + (int)((double)i15 * d18);
            v1.method_25294(i20, i13, i21, i13 + 4, invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRGB());
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm, (double)i20, (double)(i13 + 2), 6.0D, 12);
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy, (double)i21, (double)(i13 + 2), 6.0D, 12);
         } else if (v5 instanceof ModeSetting) {
            Setting v11 = (ModeSetting)v5;
            v12 = v11.getValue().name();
            i13 = Math.min(120, dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v12) + 20);
            i14 = i2 + i4 - i13 - 12;
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), new Color(60, 60, 70, 100), (double)i14, (double)(i3 + 32), (double)i13, 20.0D, 6.0D, 50.0D);
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v12, v1, i14 + i13 / 2, i3 + 38, invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRGB());
         } else if (v5 instanceof BindSetting) {
            Setting v11 = (BindSetting)v5;
            v12 = v11.isListening() ? "Listening..." : dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v11.getValue()).toString();
            i13 = Math.min(120, dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v12) + 20);
            i14 = i2 + i4 - i13 - 12;
            Color v15 = v11.isListening() ? new Color(invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRed(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getGreen(), invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getBlue(), 100) : new Color(60, 60, 70, 100);
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), v15, (double)i14, (double)(i3 + 32), (double)i13, 20.0D, 6.0D, 50.0D);
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v12, v1, i14 + i13 / 2, i3 + 38, invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.getRGB());
         } else if (v5 instanceof StringSetting) {
            Setting v11 = (StringSetting)v5;
            v12 = v11.getValue();
            if (v12.length() > 15) {
               v12 = v12.substring(0, 12) + "...";
            }

            i13 = Math.min(140, dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v12) + 24);
            i14 = i2 + i4 - i13 - 12;
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), new Color(30, 30, 35, 150), (double)i14, (double)(i3 + 32), (double)i13, 20.0D, 6.0D, 50.0D);
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v12, v1, i14 + 8, i3 + 38, invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.getRGB());
         } else {
            byte i13;
            if (v5 instanceof ColorSetting) {
               Setting v11 = (ColorSetting)v5;
               Object v12 = v11.getValue();
               i13 = 24;
               i14 = i2 + i4 - i13 - 12;
               i15 = i3 + 30;
               dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), v12, (double)i14, (double)i15, (double)i13, (double)i13, 6.0D, 50.0D);
               dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, new Color(60, 60, 65), (double)i14, (double)i15, (double)(i14 + i13), (double)(i15 + i13), 6.0D, 6.0D, 6.0D, 6.0D, 1.0D, 50.0D);
               String v16 = String.format("RGB(%d,%d,%d)", v12.getRed(), v12.getGreen(), v12.getBlue());
               dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v16, v1, i2 + 12, i3 + 36, invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW.getRGB());
            } else if (v5 instanceof ItemSetting) {
               Setting v11 = (ItemSetting)v5;
               Object v12 = v11.getItem();
               i13 = 24;
               i14 = i2 + i4 - i13 - 16;
               i15 = i3 + 28;
               dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), new Color(30, 30, 35, 150), (double)(i14 - 2), (double)(i15 - 2), (double)(i13 + 4), (double)(i13 + 4), 6.0D, 50.0D);
               if (v12 != null && v12 != class_1802.field_8162) {
                  v1.method_51427(new class_1799(v12), i14, i15);
               } else {
                  dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp("?", v1, i14 + i13 / 2, i15 + 6, invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW.getRGB());
               }
            } else {
               int i12;
               String v13;
               if (v5 instanceof MacroSetting) {
                  Setting v11 = (MacroSetting)v5;
                  i12 = v11.getCommands().size();
                  v13 = i12 + " command" + (i12 != 1 ? "s" : "");
                  i14 = Math.min(120, dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v13) + 20);
                  i15 = i2 + i4 - i14 - 12;
                  dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), new Color(60, 60, 70, 100), (double)i15, (double)(i3 + 32), (double)i14, 20.0D, 6.0D, 50.0D);
                  dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v13, v1, i15 + i14 / 2, i3 + 38, invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRGB());
               } else if (v5 instanceof FriendsSetting) {
                  Setting v11 = (FriendsSetting)v5;
                  i12 = v11.size();
                  v13 = i12 + " friend" + (i12 != 1 ? "s" : "");
                  i14 = Math.min(120, dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v13) + 20);
                  i15 = i2 + i4 - i14 - 12;
                  dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v1.method_51448(), new Color(60, 60, 70, 100), (double)i15, (double)(i3 + 32), (double)i14, 20.0D, 6.0D, 50.0D);
                  dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v13, v1, i15 + i14 / 2, i3 + 38, invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getRGB());
               }
            }
         }
      }

   }

   private int invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Setting this) {
      if (!(v1 instanceof NumberSetting) && !(v1 instanceof MinMaxSetting)) {
         return v1 instanceof ColorSetting ? 64 : 56;
      } else {
         return 56;
      }
   }

   private String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(NumberSetting this) {
      double d2 = v1.getFormat();
      double d4 = v1.getValue();
      if (d2 == 0.1D) {
         return String.format("%.1f", d4);
      } else if (d2 == 0.01D) {
         return String.format("%.2f", d4);
      } else if (d2 == 0.001D) {
         return String.format("%.3f", d4);
      } else {
         return d2 >= 1.0D ? String.format("%.0f", d4) : String.valueOf(d4);
      }
   }

   private String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(MinMaxSetting this) {
      double d2 = v1.getStep();
      String v4;
      String v5;
      if (d2 == 0.1D) {
         v4 = String.format("%.1f", v1.getCurrentMin());
         v5 = String.format("%.1f", v1.getCurrentMax());
      } else if (d2 == 0.01D) {
         v4 = String.format("%.2f", v1.getCurrentMin());
         v5 = String.format("%.2f", v1.getCurrentMax());
      } else if (d2 >= 1.0D) {
         v4 = String.format("%.0f", v1.getCurrentMin());
         v5 = String.format("%.0f", v1.getCurrentMax());
      } else {
         v4 = String.valueOf(v1.getCurrentMin());
         v5 = String.valueOf(v1.getCurrentMax());
      }

      return v4 + " - " + v5;
   }

   public boolean method_25402(double this, double d1, int d3) {
      int i6 = (int)(d1 * class_310.method_1551().method_22683().method_4495());
      int i7 = (int)(d3 * class_310.method_1551().method_22683().method_4495());
      int i8 = this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn + 900 - 50;
      int i9 = this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + 15;
      if (i6 >= i8 && i6 <= i8 + 30 && i7 >= i9 && i7 <= i9 + 30) {
         this.method_25419();
         return true;
      } else {
         int i10;
         int i14;
         int i15;
         int i16;
         int i20;
         int i21;
         int i22;
         int i24;
         int i25;
         int i26;
         if (this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz != null) {
            i10 = this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn + 900 - 300;
            int i11 = 300;
            int i12 = this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + 60;
            int i13 = i10 + i11 - 40;
            i14 = this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + 84;
            if (i6 >= i13 && i6 <= i13 + 24 && i7 >= i14 && i7 <= i14 + 24) {
               this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz = null;
               return true;
            }

            i15 = this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + 84;
            i16 = i15 + 40;
            List v17 = this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz.getSettings();

            for(Iterator v18 = v17.iterator(); v18.hasNext(); i16 += i22 + 14) {
               Setting v19 = (Setting)v18.next();
               i20 = i10 + 24;
               i21 = i11 - 48;
               i22 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v19);
               if (i6 >= i20 && i6 <= i20 + i21 && i7 >= i16 && i7 <= i16 + i22) {
                  if (v19 instanceof BooleanSetting) {
                     Setting v23 = (BooleanSetting)v19;
                     i24 = i20 + i21 - 56;
                     i25 = i16 + 16;
                     if (i6 >= i24 && i6 <= i24 + 44 && i7 >= i25 && i7 <= i25 + 24) {
                        v23.setValue(!v23.getValue());
                        return true;
                     }
                  } else if (v19 instanceof NumberSetting) {
                     Setting v23 = (NumberSetting)v19;
                     i24 = i16 + 36;
                     i25 = i20 + 12;
                     i26 = i21 - 24;
                     if (i7 >= i24 && i7 <= i24 + 12) {
                        this.invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ = true;
                        this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci = v19;
                        this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v23, i6, i25, i26);
                        return true;
                     }
                  } else if (v19 instanceof MinMaxSetting) {
                     Setting v23 = (MinMaxSetting)v19;
                     i24 = i16 + 36;
                     i25 = i20 + 12;
                     i26 = i21 - 24;
                     if (i7 >= i24 - 6 && i7 <= i24 + 10) {
                        double d27 = (v23.getCurrentMin() - v23.getMinValue()) / (v23.getMaxValue() - v23.getMinValue());
                        double d29 = (v23.getCurrentMax() - v23.getMinValue()) / (v23.getMaxValue() - v23.getMinValue());
                        int i31 = i25 + (int)((double)i26 * d27);
                        int i32 = i25 + (int)((double)i26 * d29);
                        int i33 = Math.abs(i6 - i31);
                        int i34 = Math.abs(i6 - i32);
                        this.invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ = true;
                        this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci = v19;
                        this.invokeConnorftw_KRISPYYCLIENT_rmJDFppvXdYxPyprpilioqmyebbamOHxkrbhlzzgwmObbvjlabbgUAgMR = i33 < i34;
                        this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v23, i6, i25, i26, this.invokeConnorftw_KRISPYYCLIENT_rmJDFppvXdYxPyprpilioqmyebbamOHxkrbhlzzgwmObbvjlabbgUAgMR);
                        return true;
                     }
                  } else {
                     if (v19 instanceof ModeSetting) {
                        Setting v23 = (ModeSetting)v19;
                        if (i5 == 0) {
                           v23.cycleUp();
                        } else if (i5 == 1) {
                           v23.cycleDown();
                        }

                        return true;
                     }

                     if (v19 instanceof BindSetting) {
                        Setting v23 = (BindSetting)v19;
                        int i24 = 120;
                        i25 = i20 + i21 - i24 - 12;
                        i26 = i16 + 32;
                        if (i6 >= i25 && i6 <= i25 + i24 && i7 >= i26 && i7 <= i26 + 20) {
                           if (i5 == 0) {
                              v23.setListening(!v23.isListening());
                           } else if (i5 == 1 && v23.isListening()) {
                              v23.setValue(-1);
                              v23.setListening(false);
                           }

                           return true;
                        }
                     } else if (v19 instanceof StringSetting) {
                        Setting v23 = (StringSetting)v19;
                        if (i5 == 0) {
                           class_310.method_1551().method_1507(new StringBox(new TextBox(this, (ModuleButton)null, v19, 0) {
                              public int parentX() {
                                 return 0;
                              }

                              public int parentY() {
                                 return 0;
                              }

                              public int parentWidth() {
                                 return 0;
                              }

                              public int parentHeight() {
                                 return 0;
                              }

                              public int parentOffset() {
                                 return 0;
                              }
                           }, v23));
                           return true;
                        }
                     } else if (v19 instanceof ItemSetting) {
                        Setting v23 = (ItemSetting)v19;
                        if (i5 == 0) {
                           class_310.method_1551().method_1507(new ItemFilter(new ItemBox(this, (ModuleButton)null, v19, 0) {
                              public int parentX() {
                                 return 0;
                              }

                              public int parentY() {
                                 return 0;
                              }

                              public int parentWidth() {
                                 return 0;
                              }

                              public int parentHeight() {
                                 return 0;
                              }

                              public int parentOffset() {
                                 return 0;
                              }
                           }, v23));
                           return true;
                        }
                     } else if (v19 instanceof MacroSetting) {
                        Setting v23 = (MacroSetting)v19;
                        if (i5 == 0) {
                           class_310.method_1551().method_1507(new MacroFilter(new MacroBox(this, (ModuleButton)null, v19, 0) {
                              public int parentX() {
                                 return 0;
                              }

                              public int parentY() {
                                 return 0;
                              }

                              public int parentWidth() {
                                 return 0;
                              }

                              public int parentHeight() {
                                 return 0;
                              }

                              public int parentOffset() {
                                 return 0;
                              }
                           }, v23));
                           return true;
                        }
                     } else if (v19 instanceof FriendsSetting) {
                        Setting v23 = (FriendsSetting)v19;
                        if (i5 == 0) {
                           class_310.method_1551().method_1507(new FriendsFilter(new FriendsBox(this, (ModuleButton)null, v19, 0) {
                              public int parentX() {
                                 return 0;
                              }

                              public int parentY() {
                                 return 0;
                              }

                              public int parentWidth() {
                                 return 0;
                              }

                              public int parentHeight() {
                                 return 0;
                              }

                              public int parentOffset() {
                                 return 0;
                              }
                           }, v23));
                           return true;
                        }
                     } else if (v19 instanceof ColorSetting) {
                        Setting v23 = (ColorSetting)v19;
                        if (i5 == 0) {
                           Serializable v24 = v23.getValue();
                           Color v25;
                           if (v24.equals(Color.WHITE)) {
                              v25 = Color.RED;
                           } else if (v24.equals(Color.RED)) {
                              v25 = Color.GREEN;
                           } else if (v24.equals(Color.GREEN)) {
                              v25 = Color.BLUE;
                           } else if (v24.equals(Color.BLUE)) {
                              v25 = Color.YELLOW;
                           } else if (v24.equals(Color.YELLOW)) {
                              v25 = Color.CYAN;
                           } else if (v24.equals(Color.CYAN)) {
                              v25 = Color.MAGENTA;
                           } else {
                              v25 = Color.WHITE;
                           }

                           v23.setValue(v25);
                           return true;
                        }
                     }
                  }
               }
            }
         }

         i10 = this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn;
         int i11 = this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + 84;
         Category[] v12 = Category.values();
         Object v13 = v12;
         i14 = v12.length;

         for(i15 = 0; i15 < i14; ++i15) {
            Category v16 = v13[i15];
            if (i6 >= i10 + 12 && i6 <= i10 + 220 - 12 && i7 >= i11 && i7 <= i11 + 46) {
               this.invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu = v16;
               this.invokeConnorftw_KRISPYYCLIENT_KoQcacrsFXDUvaeYSUpxlHNTvxbojrxdn = 0;
               return true;
            }

            i11 += 54;
         }

         Object v13 = DonutBBC.INSTANCE.getModuleManager().a(this.invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu);
         if (!this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL.isEmpty()) {
            v13 = (List)v13.stream().filter((v1) -> {
               return v1.getName().toString().toLowerCase().contains(this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL.toLowerCase());
            }).collect(Collectors.toList());
         }

         i14 = this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn + 220;
         i15 = this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + 130;
         i16 = 680 - (this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz != null ? 320 : 0);
         int i17 = 260;
         int i18 = 100;
         int i19 = 16;
         i20 = Math.max(1, (i16 - 48) / (i17 + i19));
         i21 = i14 + 24;
         i22 = i15 + 24;

         int i23;
         for(i23 = 0; i23 < v13.size(); ++i23) {
            Serializable v24 = (Module)v13.get(i23);
            i25 = i23 / i20;
            i26 = i23 % i20;
            int i27 = i21 + i26 * (i17 + i19);
            int i28 = i22 + i25 * (i18 + i19) - this.invokeConnorftw_KRISPYYCLIENT_KoQcacrsFXDUvaeYSUpxlHNTvxbojrxdn * 50;
            if (i6 >= i27 && i6 <= i27 + i17 && i7 >= i28 && i7 <= i28 + i18) {
               int i29 = i27 + i17 - 60;
               int i30 = i28 + i18 - 34;
               if (i6 >= i29 && i6 <= i29 + 44 && i7 >= i30 && i7 <= i30 + 24) {
                  v24.toggle();
                  return true;
               }

               if (i5 == 0) {
                  v24.toggle();
               } else if (i5 == 1) {
                  this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz = v24;
                  this.invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi = 0;
               }

               return true;
            }
         }

         i23 = i14 + 24;
         i24 = this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + 84;
         i25 = i16 - 48;
         if (i6 >= i23 && i6 <= i23 + i25 && i7 >= i24 && i7 <= i24 + 46) {
            this.invokeConnorftw_KRISPYYCLIENT_avFlPzcXVFPfpYsCnkluLdXBQXniIsPgxwitwcsfrezoOzxLxrzeeog = true;
            return true;
         } else {
            this.invokeConnorftw_KRISPYYCLIENT_avFlPzcXVFPfpYsCnkluLdXBQXniIsPgxwitwcsfrezoOzxLxrzeeog = false;
            if (i6 >= this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn && i6 <= this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn + 900 && i7 >= this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav && i7 <= this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav + 60) {
               this.invokeConnorftw_KRISPYYCLIENT_xZrhvVPvluscyEkHsxngLlULvdpXzPrEsWIpWjgfsuHolnwuip = true;
               this.invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun = i6 - this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn;
               this.invokeConnorftw_KRISPYYCLIENT_slcehdGLvyoZNZqWHWcqoJXTexSXpQFXETbcNjfgzX = i7 - this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav;
               return true;
            } else {
               return super.method_25402(d1, d3, i5);
            }
         }
      }
   }

   public boolean method_25403(double this, double d1, int d3, double i5, double d6) {
      if (this.invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ && this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci != null) {
         int i10 = (int)(d1 * class_310.method_1551().method_22683().method_4495());
         int i11 = this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn + 900 - 300;
         int i12 = i11 + 24 + 12;
         int i13 = 228;
         if (this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci instanceof NumberSetting) {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((NumberSetting)this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci, i10, i12, i13);
         } else if (this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci instanceof MinMaxSetting) {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((MinMaxSetting)this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci, i10, i12, i13, this.invokeConnorftw_KRISPYYCLIENT_rmJDFppvXdYxPyprpilioqmyebbamOHxkrbhlzzgwmObbvjlabbgUAgMR);
         }

         return true;
      } else {
         return super.method_25403(d1, d3, i5, d6, d8);
      }
   }

   public boolean method_25406(double this, double d1, int d3) {
      this.invokeConnorftw_KRISPYYCLIENT_xZrhvVPvluscyEkHsxngLlULvdpXzPrEsWIpWjgfsuHolnwuip = false;
      this.invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ = false;
      this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci = null;
      return super.method_25406(d1, d3, i5);
   }

   public void onGuiClose() {
      this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz = null;
      this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL = "";
      this.invokeConnorftw_KRISPYYCLIENT_avFlPzcXVFPfpYsCnkluLdXBQXniIsPgxwitwcsfrezoOzxLxrzeeog = false;
      this.invokeConnorftw_KRISPYYCLIENT_KoQcacrsFXDUvaeYSUpxlHNTvxbojrxdn = 0;
      this.invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi = 0;
      this.invokeConnorftw_KRISPYYCLIENT_xZrhvVPvluscyEkHsxngLlULvdpXzPrEsWIpWjgfsuHolnwuip = false;
      this.invokeConnorftw_KRISPYYCLIENT_PyrJMQRvJViwseVKxigfeEdjitrrOJgLObaomPdRWTm = 0.0F;
      this.invokeConnorftw_KRISPYYCLIENT_bfzznteptasTrbjozkexnYqkWwqwqyMHBftc = 0.0F;
      this.invokeConnorftw_KRISPYYCLIENT_xUcJMYtgoHIuOdnAxUvlqksvbmhmLDltyNsgdMhhzeNxzgz = 0.0F;
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(NumberSetting this, int v1, int i2, int i3) {
      double d5 = Math.max(0.0D, Math.min(1.0D, (double)(i2 - i3) / (double)i4));
      double d7 = v1.getMin() + d5 * (v1.getMax() - v1.getMin());
      double d9 = v1.getFormat();
      d7 = (double)Math.round(d7 / d9) * d9;
      v1.setValue(d7);
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(MinMaxSetting this, int v1, int i2, int i3, boolean i4) {
      double d6 = Math.max(0.0D, Math.min(1.0D, (double)(i2 - i3) / (double)i4));
      double d8 = v1.getMinValue() + d6 * (v1.getMaxValue() - v1.getMinValue());
      double d10 = v1.getStep();
      d8 = (double)Math.round(d8 / d10) * d10;
      if (i5) {
         v1.setCurrentMin(Math.min(d8, v1.getCurrentMax()));
      } else {
         v1.setCurrentMax(Math.max(d8, v1.getCurrentMin()));
      }

   }

   public boolean method_25404(int this, int i1, int i2) {
      if (this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz != null) {
         Iterator v4 = this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz.getSettings().iterator();

         while(v4.hasNext()) {
            Setting v5 = (Setting)v4.next();
            if (v5 instanceof BindSetting) {
               BindSetting v6 = (BindSetting)v5;
               if (v6.isListening()) {
                  if (i1 == 256) {
                     v6.setListening(false);
                  } else if (i1 == 259) {
                     v6.setValue(-1);
                     v6.setListening(false);
                  } else {
                     v6.setValue(i1);
                     v6.setListening(false);
                  }

                  return true;
               }
            }
         }
      }

      if (this.invokeConnorftw_KRISPYYCLIENT_avFlPzcXVFPfpYsCnkluLdXBQXniIsPgxwitwcsfrezoOzxLxrzeeog) {
         if (i1 == 259 && !this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL.isEmpty()) {
            this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL = this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL.substring(0, this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL.length() - 1);
            return true;
         }

         if (i1 == 256) {
            this.invokeConnorftw_KRISPYYCLIENT_avFlPzcXVFPfpYsCnkluLdXBQXniIsPgxwitwcsfrezoOzxLxrzeeog = false;
            this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL = "";
            return true;
         }
      }

      return super.method_25404(i1, i2, i3);
   }

   public boolean method_25400(char this, int i1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_avFlPzcXVFPfpYsCnkluLdXBQXniIsPgxwitwcsfrezoOzxLxrzeeog && !Character.isISOControl(i1)) {
         this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL = this.invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL + i1;
         return true;
      } else {
         return super.method_25400(i1, i2);
      }
   }

   public boolean method_25401(double this, double d1, double d3, double d5) {
      this.invokeConnorftw_KRISPYYCLIENT_KoQcacrsFXDUvaeYSUpxlHNTvxbojrxdn = Math.max(0, this.invokeConnorftw_KRISPYYCLIENT_KoQcacrsFXDUvaeYSUpxlHNTvxbojrxdn - (int)d7);
      return true;
   }

   public void method_25419() {
      DonutBBC.INSTANCE.getModuleManager().getModuleByClass(dev.krispyy.module.modules.client.DonutBBC.class).setEnabled(false);
      super.method_25419();
   }

   public boolean method_25421() {
      return false;
   }
}
