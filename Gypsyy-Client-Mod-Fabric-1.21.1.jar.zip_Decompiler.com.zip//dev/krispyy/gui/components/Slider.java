package dev.krispyy.gui.components;

import dev.krispyy.gui.Component;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
import dev.krispyy.module.setting.MinMaxSetting;
import dev.krispyy.module.setting.Setting;
import java.awt.Color;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public final class Slider extends Component {
   private boolean invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy;
   private boolean invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo;
   private double invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
   private double invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW;
   public double lerpedOffsetMinX;
   public double lerpedOffsetMaxX;
   private float invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = 0.0F;
   private final MinMaxSetting invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX;
   public Color accentColor1;
   public Color accentColor2;
   private static final Color invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg = new Color(230, 230, 230);
   private static final Color invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn = new Color(255, 255, 255, 20);
   private static final Color invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav = new Color(60, 60, 65);
   private static final Color invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft = new Color(240, 240, 240);
   private static final float invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK = 4.0F;
   private static final float invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG = 2.0F;
   private static final float invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy = 8.0F;
   private static final float invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu = 0.25F;

   public Slider(ModuleButton var1, Setting var2, int var3) {
      super(var1, var2, var3);
      this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX = (MinMaxSetting)var2;
      this.lerpedOffsetMinX = (double)this.parentX();
      this.lerpedOffsetMaxX = (double)(this.parentX() + this.parentWidth());
   }

   public void render(class_332 var1, int var2, int var3, float var4) {
      super.render(var1, var2, var3, var4);
      class_4587 var5 = var1.method_51448();
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var2, var3, var4);
      this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = (this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getCurrentMin() - this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getMinValue()) / (this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getMaxValue() - this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getMinValue()) * (double)(this.parentWidth() - 10) + 5.0D;
      this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = (this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getCurrentMax() - this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getMinValue()) / (this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getMaxValue() - this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getMinValue()) * (double)(this.parentWidth() - 10) + 5.0D;
      this.lerpedOffsetMinX = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((float)(0.5D * (double)var4), this.lerpedOffsetMinX, this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku);
      this.lerpedOffsetMaxX = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((float)(0.5D * (double)var4), this.lerpedOffsetMaxX, this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW);
      if (!this.parent.parent.dragging) {
         var1.method_25294(this.parentX(), this.parentY() + this.parentOffset() + this.offset, this.parentX() + this.parentWidth(), this.parentY() + this.parentOffset() + this.offset + this.parentHeight(), (new Color(invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.getRed(), invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.getGreen(), invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.getBlue(), (int)((float)invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.getAlpha() * this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh))).getRGB());
      }

      int var6 = this.parentY() + this.offset + this.parentOffset() + 25;
      int var7 = this.parentX() + 5;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var5, invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav, (double)var7, (double)var6, (double)(var7 + (this.parentWidth() - 10)), (double)((float)var6 + 4.0F), 2.0D, 2.0D, 2.0D, 2.0D, 50.0D);
      if (this.lerpedOffsetMaxX > this.lerpedOffsetMinX) {
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var5, this.accentColor1, (double)var7 + this.lerpedOffsetMinX - 5.0D, (double)var6, (double)var7 + this.lerpedOffsetMaxX - 5.0D, (double)((float)var6 + 4.0F), 2.0D, 2.0D, 2.0D, 2.0D, 50.0D);
      }

      String var8 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getName(), var1, this.parentX() + 5, this.parentY() + this.parentOffset() + this.offset + 9, invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg.getRGB());
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var8, var1, this.parentX() + this.parentWidth() - dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var8) - 5, this.parentY() + this.parentOffset() + this.offset + 9, this.accentColor1.getRGB());
      float var9 = (float)var6 + 2.0F - 4.0F;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var5, invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft, (double)((float)((double)var7 + this.lerpedOffsetMinX - 5.0D - 4.0D)), (double)var9, (double)((float)((double)var7 + this.lerpedOffsetMinX - 5.0D + 4.0D)), (double)(var9 + 8.0F), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var5, invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft, (double)((float)((double)var7 + this.lerpedOffsetMaxX - 5.0D - 4.0D)), (double)var9, (double)((float)((double)var7 + this.lerpedOffsetMaxX - 5.0D + 4.0D)), (double)(var9 + 8.0F), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var1, int var2, float var3) {
      float var4;
      if (this.isHovered((double)var1, (double)var2) && !this.parent.parent.dragging) {
         var4 = 1.0F;
      } else {
         var4 = 0.0F;
      }

      this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = (float)dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((double)this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh, (double)var4, 0.25D, (double)(var3 * 0.05F));
   }

   private String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      if (this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getCurrentMin() == this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getCurrentMax()) {
         return this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getCurrentMin());
      } else {
         String var10000 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getCurrentMin());
         return var10000 + " - " + this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getCurrentMax());
      }
   }

   private String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(double var1) {
      double var3 = this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getStep();
      if (var3 == 0.1D) {
         return String.format("%.1f", var1);
      } else if (var3 == 0.01D) {
         return String.format("%.2f", var1);
      } else if (var3 == 0.001D) {
         return String.format("%.3f", var1);
      } else {
         return var3 >= 1.0D ? String.format("%.0f", var1) : String.valueOf(var1);
      }
   }

   public void mouseClicked(double var1, double var3, int var5) {
      if (var5 == 0 && this.isHovered(var1, var3)) {
         if (this.isHoveredMin(var1, var3)) {
            this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = true;
            this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var1);
         } else if (this.isHoveredMax(var1, var3)) {
            this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = true;
            this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(var1);
         } else if (var1 < (double)this.parentX() + this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku) {
            this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = true;
            this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var1);
         } else if (var1 > (double)this.parentX() + this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW) {
            this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = true;
            this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(var1);
         } else if (var1 - ((double)this.parentX() + this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku) < (double)this.parentX() + this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW - var1) {
            this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = true;
            this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var1);
         } else {
            this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = true;
            this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(var1);
         }
      }

      super.mouseClicked(var1, var3, var5);
   }

   public void keyPressed(int var1, int var2, int var3) {
      if (this.mouseOver && var1 == 259) {
         this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.setCurrentMax(this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getDefaultMax());
         this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.setCurrentMin(this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getDefaultMin());
      }

      super.keyPressed(var1, var2, var3);
   }

   public boolean isHoveredMin(double var1, double var3) {
      return this.isHovered(var1, var3) && var1 > (double)this.parentX() + this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku - 8.0D && var1 < (double)this.parentX() + this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku + 8.0D;
   }

   public boolean isHoveredMax(double var1, double var3) {
      return this.isHovered(var1, var3) && var1 > (double)this.parentX() + this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW - 8.0D && var1 < (double)this.parentX() + this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW + 8.0D;
   }

   public void mouseReleased(double var1, double var3, int var5) {
      if (var5 == 0) {
         this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = false;
         this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = false;
      }

      super.mouseReleased(var1, var3, var5);
   }

   public void mouseDragged(double var1, double var3, int var5, double var6, double var8) {
      if (this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy) {
         this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var1);
      }

      if (this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo) {
         this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(var1);
      }

      super.mouseDragged(var1, var3, var5, var6, var8);
   }

   public void onGuiClose() {
      this.accentColor1 = null;
      this.accentColor2 = null;
      this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = 0.0F;
      super.onGuiClose();
   }

   private void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(double var1) {
      this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.setCurrentMin(Math.min(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_3532.method_15350((var1 - (double)(this.parentX() + 5)) / (double)(this.parentWidth() - 10), 0.0D, 1.0D) * (this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getMaxValue() - this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getMinValue()) + this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getMinValue(), this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getStep()), this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getCurrentMax()));
   }

   private void invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(double var1) {
      this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.setCurrentMax(Math.max(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_3532.method_15350((var1 - (double)(this.parentX() + 5)) / (double)(this.parentWidth() - 10), 0.0D, 1.0D) * (this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getMaxValue() - this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getMinValue()) + this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getMinValue(), this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getStep()), this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getCurrentMin()));
   }

   public void onUpdate() {
      Color var1 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(255, this.parent.settings.indexOf(this));
      Color var2 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(255, this.parent.settings.indexOf(this) + 1);
      if (this.accentColor1 == null) {
         this.accentColor1 = new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), 0);
      } else {
         this.accentColor1 = new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), this.accentColor1.getAlpha());
      }

      if (this.accentColor2 == null) {
         this.accentColor2 = new Color(var2.getRed(), var2.getGreen(), var2.getBlue(), 0);
      } else {
         this.accentColor2 = new Color(var2.getRed(), var2.getGreen(), var2.getBlue(), this.accentColor2.getAlpha());
      }

      if (this.accentColor1.getAlpha() != 255) {
         this.accentColor1 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(0.05F, 255, this.accentColor1);
      }

      if (this.accentColor2.getAlpha() != 255) {
         this.accentColor2 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(0.05F, 255, this.accentColor2);
      }

      super.onUpdate();
   }
}
