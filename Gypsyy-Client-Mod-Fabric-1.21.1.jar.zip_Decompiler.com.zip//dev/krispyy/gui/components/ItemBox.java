package dev.krispyy.gui.components;

import dev.krispyy.gui.Component;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
import dev.krispyy.module.setting.ItemSetting;
import dev.krispyy.module.setting.Setting;
import java.awt.Color;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_332;

public class ItemBox extends Component {
   private final ItemSetting invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy;
   private float invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 0.0F;
   private Color invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
   private final Color invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = new Color(230, 230, 230);
   private final Color invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = new Color(255, 255, 255, 20);
   private final Color invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX = new Color(30, 30, 35);
   private final Color invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg = new Color(60, 60, 65);
   private final float invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn = 4.0F;
   private final float invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav = 0.25F;

   public ItemBox(ModuleButton var1, Setting var2, int var3) {
      super(var1, var2, var3);
      this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = (ItemSetting)var2;
   }

   public void onUpdate() {
      Color var1 = invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(255, this.parent.settings.indexOf(this));
      if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku == null) {
         this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), 0);
      } else {
         this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.getAlpha());
      }

      if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.getAlpha() != 255) {
         this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(0.05F, 255, this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku);
      }

      super.onUpdate();
   }

   public void render(class_332 var1, int var2, int var3, float var4) {
      super.render(var1, var2, var3, var4);
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var2, var3, var4);
      if (!this.parent.parent.dragging) {
         var1.method_25294(this.parentX(), this.parentY() + this.parentOffset() + this.offset, this.parentX() + this.parentWidth(), this.parentY() + this.parentOffset() + this.offset + this.parentHeight(), (new Color(this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getRed(), this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getGreen(), this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getBlue(), (int)((float)this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getAlpha() * this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo))).getRGB());
      }

      int var5 = this.parentX() + 5;
      int var6 = this.parentY() + this.parentOffset() + this.offset + this.parentHeight() / 2;
      invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(String.valueOf(this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getName()), var1, var5, var6 - 8, this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW.getRGB());
      int var7 = var5 + invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(String.valueOf(this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getName()) + ": ") + 5;
      int var8 = var6 - 11;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg, (double)var7, (double)var8, (double)(var7 + 22), (double)(var8 + 22), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX, (double)(var7 + 1), (double)(var8 + 1), (double)(var7 + 22 - 1), (double)(var8 + 22 - 1), 3.5D, 3.5D, 3.5D, 3.5D, 50.0D);
      class_1792 var9 = this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getItem();
      if (var9 != null && var9 != class_1802.field_8162) {
         var1.method_51427(new class_1799(var9), var7 + 3, var8 + 3);
      } else {
         invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp("?", var1, var7 + 11 - 1, var8 + 4, (new Color(150, 150, 150, 200)).getRGB());
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var1, int var2, float var3) {
      float var4;
      if (this.isHovered((double)var1, (double)var2) && !this.parent.parent.dragging) {
         var4 = 1.0F;
      } else {
         var4 = 0.0F;
      }

      this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = (float)dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((double)this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo, (double)var4, 0.25D, (double)(var3 * 0.05F));
   }

   public void mouseClicked(double var1, double var3, int var5) {
      if (this.isHovered(var1, var3) && var5 == 0) {
         this.mc.method_1507(new ItemFilter(this, this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy));
      }

      super.mouseClicked(var1, var3, var5);
   }

   public void onGuiClose() {
      this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = null;
      this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 0.0F;
      super.onGuiClose();
   }
}
