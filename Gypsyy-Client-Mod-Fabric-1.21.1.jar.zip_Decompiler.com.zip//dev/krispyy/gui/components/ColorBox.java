package dev.krispyy.gui.components;

import dev.krispyy.gui.Component;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
import dev.krispyy.module.setting.BooleanSetting;
import dev.krispyy.module.setting.ColorSetting;
import dev.krispyy.module.setting.ModeSetting;
import dev.krispyy.module.setting.NumberSetting;
import dev.krispyy.module.setting.Setting;
import java.awt.Color;
import net.minecraft.class_332;

public final class ColorBox extends Component {
   private final ColorSetting invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy;
   private float invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo;
   private Color invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
   private final Color invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW;
   private final Color invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh;
   private final Color invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX;
   private final float invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg = 4.0F;
   private final float invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn = 0.25F;
   private boolean invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav = false;
   private final Color[] invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft;

   public ColorBox(ModuleButton var1, Setting var2, int var3) {
      super(var1, var2, var3);
      this.invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft = new Color[]{Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.CYAN, Color.MAGENTA, Color.ORANGE, Color.PINK, Color.WHITE, Color.GRAY, Color.DARK_GRAY, Color.BLACK, new Color(255, 100, 100), new Color(100, 255, 100), new Color(100, 100, 255), new Color(255, 255, 100), new Color(255, 100, 255), new Color(100, 255, 255)};
      this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 0.0F;
      this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = new Color(230, 230, 230);
      this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = new Color(255, 255, 255, 20);
      this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX = new Color(60, 60, 65);
      this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = (ColorSetting)var2;
   }

   public void onUpdate() {
      Color var1 = invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(255, this.parent.settings.indexOf(this));
      if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku == null) {
         this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), 0);
      } else {
         this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.getAlpha());
      }

      if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.getAlpha() != 255) {
         this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(0.05F, 255, this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku);
      }

      super.onUpdate();
   }

   public void render(class_332 var1, int var2, int var3, float var4) {
      super.render(var1, var2, var3, var4);
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var2, var3, var4);
      if (!this.parent.parent.dragging) {
         var1.method_25294(this.parentX(), this.parentY() + this.parentOffset() + this.offset, this.parentX() + this.parentWidth(), this.parentY() + this.parentOffset() + this.offset + this.parentHeight(), (new Color(this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getRed(), this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getGreen(), this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getBlue(), (int)((float)this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getAlpha() * this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo))).getRGB());
      }

      int var5 = this.parentX() + 5;
      int var6 = this.parentY() + this.parentOffset() + this.offset + this.parentHeight() / 2;
      invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(String.valueOf(this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getName()), var1, var5, var6 - 8, this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW.getRGB());
      int var7 = var5 + invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(String.valueOf(this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getName()) + ": ") + 5;
      int var8 = var6 - 11;
      boolean var9 = true;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX, (double)var7, (double)var8, (double)(var7 + 20), (double)(var8 + 20), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
      Color var10 = this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getValue();
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), var10, (double)(var7 + 1), (double)(var8 + 1), (double)(var7 + 20 - 1), (double)(var8 + 20 - 1), 3.5D, 3.5D, 3.5D, 3.5D, 50.0D);
      int var11 = var7 + 20 + 10;
      int var12 = var6 - 8;
      String var13 = String.format("RGB(%d,%d,%d)", var10.getRed(), var10.getGreen(), var10.getBlue());
      invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var13, var1, var11, var12, this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW.getRGB());
      if (this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav) {
         int var14 = this.parentX() + this.parentWidth() + 5;
         int var15 = this.parentY() + this.parentOffset() + this.offset;
         short var16 = 160;
         byte var17 = 70;
         if (var14 + var16 > this.mc.method_22683().method_4480() - 10) {
            var14 = this.parentX() - var16 - 5;
         }

         if (var15 + var17 > this.mc.method_22683().method_4507() - 10) {
            var15 = this.mc.method_22683().method_4507() - var17 - 10;
         }

         if (var15 < 10) {
            var15 = 10;
         }

         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(20, 20, 25, 255), (double)(var14 - 2), (double)(var15 - 2), (double)(var14 + var16 + 2), (double)(var15 + var17 + 2), 6.0D, 6.0D, 6.0D, 6.0D, 50.0D);
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(40, 40, 45, 255), (double)var14, (double)var15, (double)(var14 + var16), (double)(var15 + var17), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
         byte var18 = 8;
         byte var19 = 16;
         byte var20 = 2;

         for(int var21 = 0; var21 < this.invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft.length; ++var21) {
            int var22 = var21 / var18;
            int var23 = var21 % var18;
            int var24 = var14 + 2 + var23 * (var19 + var20);
            int var25 = var15 + 2 + var22 * (var19 + var20);
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), this.invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft[var21], (double)var24, (double)var25, (double)(var24 + var19), (double)(var25 + var19), 2.0D, 2.0D, 2.0D, 2.0D, 50.0D);
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(80, 80, 85, 255), (double)var24, (double)var25, (double)(var24 + var19), (double)(var25 + var19), 2.0D, 2.0D, 2.0D, 2.0D, 50.0D);
         }
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var1, int var2, float var3) {
      float var4;
      if (this.isHovered((double)var1, (double)var2) && !this.parent.parent.dragging) {
         var4 = 1.0F;
      } else {
         var4 = 0.0F;
      }

      this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = (float)dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((double)this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo, (double)var4, 0.25D, (double)(var3 * 0.05F));
   }

   public void mouseClicked(double var1, double var3, int var5) {
      int var18;
      int var21;
      if (this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav) {
         var18 = this.parentX() + this.parentWidth() + 5;
         var21 = this.parentY() + this.parentOffset() + this.offset;
         short var19 = 160;
         byte var20 = 70;
         if (var18 + var19 > this.mc.method_22683().method_4480() - 10) {
            var18 = this.parentX() - var19 - 5;
         }

         if (var21 + var20 > this.mc.method_22683().method_4507() - 10) {
            var21 = this.mc.method_22683().method_4507() - var20 - 10;
         }

         if (var21 < 10) {
            var21 = 10;
         }

         if (var1 >= (double)var18 && var1 <= (double)(var18 + var19) && var3 >= (double)var21 && var3 <= (double)(var21 + var20)) {
            byte var22 = 8;
            byte var23 = 16;
            byte var24 = 2;
            int var28 = (int)(var1 - (double)var18);
            int var30 = (int)(var3 - (double)var21);
            int var31 = var30 / (var23 + var24) * var22 + var28 / (var23 + var24);
            if (var31 >= 0 && var31 < this.invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft.length) {
               this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.setValue(this.invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft[var31]);
               this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav = false;
            }

         } else {
            this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav = false;
         }
      } else {
         if (this.isHovered(var1, var3)) {
            if (var5 == 0) {
               Color var6 = this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getValue();
               Color var7;
               if (var6.equals(Color.WHITE)) {
                  var7 = Color.RED;
               } else if (var6.equals(Color.RED)) {
                  var7 = Color.GREEN;
               } else if (var6.equals(Color.GREEN)) {
                  var7 = Color.BLUE;
               } else if (var6.equals(Color.BLUE)) {
                  var7 = Color.YELLOW;
               } else if (var6.equals(Color.YELLOW)) {
                  var7 = Color.CYAN;
               } else if (var6.equals(Color.CYAN)) {
                  var7 = Color.MAGENTA;
               } else {
                  var7 = Color.WHITE;
               }

               this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.setValue(var7);
            } else if (var5 == 1) {
               var18 = this.parentX() + 5;
               var21 = this.parentY() + this.parentOffset() + this.offset + this.parentHeight() / 2;
               int var8 = var18 + invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(String.valueOf(this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getName()) + ": ") + 5;
               int var9 = var21 - 11;
               boolean var10 = true;
               if (var1 >= (double)var8 && var1 <= (double)(var8 + 20) && var3 >= (double)var9 && var3 <= (double)(var9 + 20)) {
                  int var11 = this.parent.settings.indexOf(this);
                  if (var11 >= 0 && var11 < this.parent.settings.size() - 1) {
                     Component var12 = (Component)this.parent.settings.get(var11 + 1);
                     if (var12 instanceof ColorBox) {
                        ColorBox var13 = (ColorBox)var12;
                        Color var14 = var13.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getValue();
                        Color var15;
                        if (var14.equals(Color.WHITE)) {
                           var15 = Color.RED;
                        } else if (var14.equals(Color.RED)) {
                           var15 = Color.GREEN;
                        } else if (var14.equals(Color.GREEN)) {
                           var15 = Color.BLUE;
                        } else if (var14.equals(Color.BLUE)) {
                           var15 = Color.YELLOW;
                        } else if (var14.equals(Color.YELLOW)) {
                           var15 = Color.CYAN;
                        } else if (var14.equals(Color.CYAN)) {
                           var15 = Color.MAGENTA;
                        } else {
                           var15 = Color.WHITE;
                        }

                        var13.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.setValue(var15);
                     } else if (var12.setting instanceof NumberSetting) {
                        NumberSetting var25 = (NumberSetting)var12.setting;
                        double var29 = var25.getValue();
                        double var16 = Math.max(var25.getMin(), var29 - var25.getFormat());
                        var25.setValue(var16);
                     } else if (var12.setting instanceof BooleanSetting) {
                        BooleanSetting var26 = (BooleanSetting)var12.setting;
                        var26.toggle();
                     } else if (var12.setting instanceof ModeSetting) {
                        ModeSetting var27 = (ModeSetting)var12.setting;
                        var27.cycleDown();
                     }
                  }
               } else {
                  this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav = true;
               }
            }
         }

      }
   }
}
