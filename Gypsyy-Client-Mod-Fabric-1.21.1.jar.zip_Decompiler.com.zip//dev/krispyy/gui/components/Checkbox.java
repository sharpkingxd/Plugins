package dev.krispyy.gui.components;

import dev.krispyy.gui.Component;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn;
import dev.krispyy.module.setting.BooleanSetting;
import dev.krispyy.module.setting.Setting;
import java.awt.Color;
import net.minecraft.class_332;

public final class Checkbox extends Component {
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy;
   private float invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 0.0F;
   private float invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = 0.0F;
   private final float invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = 3.0F;
   private final Color invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = new Color(230, 230, 230);
   private final Color invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX = new Color(255, 255, 255, 20);
   private final Color invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg = new Color(100, 100, 110);
   private final Color invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn = new Color(40, 40, 45);
   private final int invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav = 13;
   private final float invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft = 0.005F;
   private final float invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK = 0.002F;

   public Checkbox(ModuleButton var1, Setting var2, int var3) {
      super(var1, var2, var3);
      this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = (BooleanSetting)var2;
      float var4;
      if (this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getValue()) {
         var4 = 1.0F;
      } else {
         var4 = 0.0F;
      }

      this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = var4;
   }

   public void render(class_332 var1, int var2, int var3, float var4) {
      super.render(var1, var2, var3, var4);
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var2, var3, var4);
      if (!this.parent.parent.dragging) {
         var1.method_25294(this.parentX(), this.parentY() + this.parentOffset() + this.offset, this.parentX() + this.parentWidth(), this.parentY() + this.parentOffset() + this.offset + this.parentHeight(), (new Color(this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getRed(), this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getGreen(), this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getBlue(), (int)((float)this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getAlpha() * this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo))).getRGB());
      }

      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getName(), var1, this.parentX() + 27, this.parentY() + this.parentOffset() + this.offset + this.parentHeight() / 2 - 6, this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getRGB());
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1);
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var1, int var2, float var3) {
      float var4 = var3 * 0.05F;
      float var5;
      if (this.isHovered((double)var1, (double)var2) && !this.parent.parent.dragging) {
         var5 = 1.0F;
      } else {
         var5 = 0.0F;
      }

      this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = (float)dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((double)this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo, (double)var5, 0.004999999888241291D, (double)var4);
      float var6;
      if (this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getValue()) {
         var6 = 1.0F;
      } else {
         var6 = 0.0F;
      }

      this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = (float)dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((double)this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku, (double)var6, 0.0020000000949949026D, (double)var4);
      this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = (float)dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq((double)this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku, 0.0D, 1.0D);
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 var1) {
      int var2 = this.parentX() + 8;
      int var3 = this.parentY() + this.parentOffset() + this.offset + this.parentHeight() / 2 - 6;
      Color var4 = invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(255, this.parent.settings.indexOf(this));
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg, (double)var2, (double)var3, (double)(var2 + 13), (double)(var3 + 13), 3.0D, 3.0D, 3.0D, 3.0D, 50.0D);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn, (double)(var2 + 1), (double)(var3 + 1), (double)(var2 + 13 - 1), (double)(var3 + 13 - 1), 2.5D, 2.5D, 2.5D, 2.5D, 50.0D);
      if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku > 0.01F) {
         Color var5 = new Color(var4.getRed(), var4.getGreen(), var4.getBlue(), (int)(255.0F * this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku));
         float var6 = (float)(var2 + 2) + 9.0F * (1.0F - this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku) / 2.0F;
         float var7 = (float)(var3 + 2) + 9.0F * (1.0F - this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku) / 2.0F;
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), var5, (double)var6, (double)var7, (double)(var6 + 9.0F * this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku), (double)(var7 + 9.0F * this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku), 1.5D, 1.5D, 1.5D, 1.5D, 50.0D);
         if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku > 0.7F) {
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(var4.getRed(), var4.getGreen(), var4.getBlue(), (int)(40.0F * (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku - 0.7F) * 3.33F)), (double)(var2 - 1), (double)(var3 - 1), (double)(var2 + 13 + 1), (double)(var3 + 13 + 1), 3.5D, 3.5D, 3.5D, 3.5D, 50.0D);
         }
      }

   }

   public void keyPressed(int var1, int var2, int var3) {
      if (this.mouseOver && this.parent.extended && var1 == 259) {
         this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.setValue(this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getDefaultValue());
      }

      super.keyPressed(var1, var2, var3);
   }

   public void mouseClicked(double var1, double var3, int var5) {
      if (this.isHovered(var1, var3) && var5 == 0) {
         this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.toggle();
      }

      super.mouseClicked(var1, var3, var5);
   }

   public void onGuiClose() {
      super.onGuiClose();
      this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 0.0F;
      float var1;
      if (this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getValue()) {
         var1 = 1.0F;
      } else {
         var1 = 0.0F;
      }

      this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = var1;
   }
}
