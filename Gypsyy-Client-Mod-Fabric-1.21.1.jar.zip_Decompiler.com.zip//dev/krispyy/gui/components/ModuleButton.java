package dev.krispyy.gui.components;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.krispyy.DonutBBC;
import dev.krispyy.gui.CategoryWindow;
import dev.krispyy.gui.Component;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
import dev.krispyy.module.Module;
import dev.krispyy.module.setting.BindSetting;
import dev.krispyy.module.setting.BooleanSetting;
import dev.krispyy.module.setting.ColorSetting;
import dev.krispyy.module.setting.ItemSetting;
import dev.krispyy.module.setting.MacroSetting;
import dev.krispyy.module.setting.MinMaxSetting;
import dev.krispyy.module.setting.ModeSetting;
import dev.krispyy.module.setting.NumberSetting;
import dev.krispyy.module.setting.Setting;
import dev.krispyy.module.setting.StringSetting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class ModuleButton {
   public List<Component> settings = new ArrayList();
   public CategoryWindow parent;
   public Module module;
   public int offset;
   public boolean extended;
   public int settingOffset;
   public Color currentColor;
   public Color currentAlpha;
   public invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw animation = new invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(0.0D);
   private final float invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = 6.0F;
   private final Color invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = new Color(65, 105, 225);
   private final Color invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = new Color(255, 255, 255, 20);
   private final Color invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = new Color(120, 190, 255);
   private final Color invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = new Color(180, 180, 180);
   private final Color invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = new Color(40, 40, 40, 200);
   private float invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = 0.0F;
   private float invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = 0.0F;
   private final float invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = 0.0F;

   public ModuleButton(CategoryWindow var1, Module var2, int var3) {
      this.parent = var1;
      this.module = var2;
      this.offset = var3;
      this.extended = false;
      this.settingOffset = var1.getHeight();

      for(Iterator var4 = var2.getSettings().iterator(); var4.hasNext(); this.settingOffset += var1.getHeight()) {
         Object var5 = var4.next();
         if (var5 instanceof BooleanSetting) {
            this.settings.add(new Checkbox(this, (Setting)var5, this.settingOffset));
         } else if (var5 instanceof NumberSetting) {
            this.settings.add(new NumberBox(this, (Setting)var5, this.settingOffset));
         } else if (var5 instanceof ModeSetting) {
            this.settings.add(new ModeBox(this, (Setting)var5, this.settingOffset));
         } else if (var5 instanceof BindSetting) {
            this.settings.add(new Keybind(this, (Setting)var5, this.settingOffset));
         } else if (var5 instanceof StringSetting) {
            this.settings.add(new TextBox(this, (Setting)var5, this.settingOffset));
         } else if (var5 instanceof MinMaxSetting) {
            this.settings.add(new Slider(this, (Setting)var5, this.settingOffset));
         } else if (var5 instanceof ItemSetting) {
            this.settings.add(new ItemBox(this, (Setting)var5, this.settingOffset));
         } else if (var5 instanceof MacroSetting) {
            this.settings.add(new MacroBox(this, (Setting)var5, this.settingOffset));
         } else if (var5 instanceof ColorSetting) {
            this.settings.add(new ColorBox(this, (Setting)var5, this.settingOffset));
         }
      }

   }

   public void render(class_332 var1, int var2, int var3, float var4) {
      if (this.parent.getY() + this.offset <= class_310.method_1551().method_22683().method_4507()) {
         Iterator var5 = this.settings.iterator();

         while(var5.hasNext()) {
            ((Component)var5.next()).onUpdate();
         }

         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var2, var3, var4);
         int var6 = this.parent.getX();
         int var7 = this.parent.getY() + this.offset;
         int var8 = this.parent.getWidth();
         int var9 = this.parent.getHeight();
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var6, var7, var8, var9);
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var6, var7, var9);
         this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var1, var6, var7, var8, var9);
         if (this.extended) {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var2, var3, var4);
         }

      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var1, int var2, float var3) {
      float var4 = var3 * 0.05F;
      float var5;
      if (this.isHovered((double)var1, (double)var2) && !this.parent.dragging) {
         var5 = 1.0F;
      } else {
         var5 = 0.0F;
      }

      this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = (float)invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((double)this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku, (double)var5, 0.05000000074505806D, (double)var4);
      float var6;
      if (this.module.isEnabled()) {
         var6 = 1.0F;
      } else {
         var6 = 0.0F;
      }

      this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = (float)invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((double)this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW, (double)var6, 0.004999999888241291D, (double)var4);
      this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = (float)invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq((double)this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW, 0.0D, 1.0D);
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 var1, int var2, int var3, int var4, int var5) {
      Color var6 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(new Color(30, 30, 30, 200), this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq, this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku);
      boolean var7 = this.parent.moduleButtons.get(this.parent.moduleButtons.size() - 1) == this;
      float var8 = 0.0F;
      float var9 = 0.0F;
      float var10 = var7 && !this.extended ? 6.0F : 0.0F;
      float var11 = var7 && !this.extended ? 6.0F : 0.0F;
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), var6, (double)var2, (double)var3, (double)(var2 + var4), (double)(var3 + var5), (double)var8, (double)var9, (double)var10, (double)var11, 50.0D);
      if (this.parent.moduleButtons.indexOf(this) > 0) {
         Color var12 = new Color(50, 50, 50, 100);
         var1.method_25294(var2 + 8, var3, var2 + var4 - 8, var3 + 1, var12.getRGB());
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 var1, int var2, int var3, int var4) {
      Color var5;
      if (this.module.isEnabled()) {
         var5 = invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(255, DonutBBC.INSTANCE.getModuleManager().a(this.module.getCategory()).indexOf(this.module));
      } else {
         var5 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
      }

      float var6 = 5.0F * this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW;
      if (var6 > 0.1F) {
         invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy, var5, this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW), (double)var2, (double)(var3 + 2), (double)((float)var2 + var6), (double)(var3 + var4 - 2), 1.5D, 1.5D, 1.5D, 1.5D, 60.0D);
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_332 var1, int var2, int var3, int var4, int var5) {
      Color var6 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy, this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm, this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW);
      invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(this.module.getName(), var1, var2 + 12, var3 + var5 / 2 - 6, var6.getRGB());
      int var7 = var2 + var4 - 36;
      int var8 = var3 + var5 / 2 - 6;
      Color var9 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(new Color(40, 40, 40, 200), new Color(70, 130, 180, 150), this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW);
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), var9, (double)var7, (double)var8, (double)((float)var7 + 24.0F), (double)((float)var8 + 12.0F), 6.0D, 6.0D, 6.0D, 6.0D, 50.0D);
      float var10 = (float)var7 + 6.0F + 12.0F * this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW;
      Color var11 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(new Color(180, 180, 180), this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm, this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW);
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), var11, (double)var10, (double)((float)var8 + 6.0F), 5.0D, 12);
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 var1, int var2, int var3, float var4) {
      int var5 = this.parent.getY() + this.offset + this.parent.getHeight();
      double var6 = this.animation.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
      RenderSystem.enableScissor(this.parent.getX(), DonutBBC.mc.method_22683().method_4507() - (var5 + (int)var6), this.parent.getWidth(), (int)var6);
      Iterator var8 = this.settings.iterator();

      while(var8.hasNext()) {
         ((Component)var8.next()).render(var1, var2, var3 - var5, var4);
      }

      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1);
      RenderSystem.disableScissor();
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 var1) {
      Iterator var2 = this.settings.iterator();

      while(var2.hasNext()) {
         Component var3 = (Component)var2.next();
         if (var3 instanceof NumberBox) {
            NumberBox var4 = (NumberBox)var3;
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, (double)var3.parentX() + Math.max(var4.lerpedOffsetX, 2.5D), (double)(var3.parentY() + var4.offset + var3.parentOffset()) + 27.5D, var4.currentColor1);
         } else if (var3 instanceof Slider) {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, (double)var3.parentX() + Math.max(((Slider)var3).lerpedOffsetMinX, 2.5D), (double)(var3.parentY() + var3.offset + var3.parentOffset()) + 27.5D, ((Slider)var3).accentColor1);
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, (double)var3.parentX() + Math.max(((Slider)var3).lerpedOffsetMaxX, 2.5D), (double)(var3.parentY() + var3.offset + var3.parentOffset()) + 27.5D, ((Slider)var3).accentColor1);
         }
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 var1, double var2, double var4, Color var6) {
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(0, 0, 0, 100), var2, var4, 7.0D, 18);
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), var6, var2, var4, 5.5D, 16);
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(255, 255, 255, 70), var2, var4 - 1.0D, 3.0D, 12);
   }

   public void onExtend() {
      for(Iterator var1 = this.parent.moduleButtons.iterator(); var1.hasNext(); ((ModuleButton)var1.next()).extended = false) {
      }

   }

   public void keyPressed(int var1, int var2, int var3) {
      Iterator var4 = this.settings.iterator();

      while(var4.hasNext()) {
         ((Component)var4.next()).keyPressed(var1, var2, var3);
      }

   }

   public void mouseDragged(double var1, double var3, int var5, double var6, double var8) {
      if (this.extended) {
         Iterator var10 = this.settings.iterator();

         while(var10.hasNext()) {
            ((Component)var10.next()).mouseDragged(var1, var3, var5, var6, var8);
         }
      }

   }

   public void mouseClicked(double var1, double var3, int var5) {
      if (this.isHovered(var1, var3)) {
         if (var5 == 0) {
            int var6 = this.parent.getX() + this.parent.getWidth() - 30;
            int var7 = this.parent.getY() + this.offset + this.parent.getHeight() / 2 - 3;
            if (var1 >= (double)var6 && var1 <= (double)(var6 + 12) && var3 >= (double)var7 && var3 <= (double)(var7 + 6)) {
               this.module.toggle();
            } else if (!this.module.getSettings().isEmpty() && var1 > (double)(this.parent.getX() + this.parent.getWidth() - 25)) {
               if (!this.extended) {
                  this.onExtend();
               }

               this.extended = !this.extended;
            } else {
               this.module.toggle();
            }
         } else if (var5 == 1) {
            if (this.module.getSettings().isEmpty()) {
               return;
            }

            if (!this.extended) {
               this.onExtend();
            }

            this.extended = !this.extended;
         }
      }

      if (this.extended) {
         Iterator var8 = this.settings.iterator();

         while(var8.hasNext()) {
            Component var9 = (Component)var8.next();
            var9.mouseClicked(var1, var3, var5);
         }
      }

   }

   public void onGuiClose() {
      this.currentAlpha = null;
      this.currentColor = null;
      this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = 0.0F;
      float var1;
      if (this.module.isEnabled()) {
         var1 = 1.0F;
      } else {
         var1 = 0.0F;
      }

      this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = var1;
      Iterator var2 = this.settings.iterator();

      while(var2.hasNext()) {
         ((Component)var2.next()).onGuiClose();
      }

   }

   public void mouseReleased(double var1, double var3, int var5) {
      if (this.extended) {
         Iterator var6 = this.settings.iterator();

         while(var6.hasNext()) {
            ((Component)var6.next()).mouseReleased(var1, var3, var5);
         }
      }

   }

   public boolean isHovered(double var1, double var3) {
      return var1 > (double)this.parent.getX() && var1 < (double)(this.parent.getX() + this.parent.getWidth()) && var3 > (double)(this.parent.getY() + this.offset) && var3 < (double)(this.parent.getY() + this.offset + this.parent.getHeight());
   }
}
