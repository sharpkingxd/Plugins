package dev.krispyy.gui.components;

import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK;
import dev.krispyy.module.modules.client.DonutBBC;
import dev.krispyy.module.setting.MacroSetting;
import java.awt.Color;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class MacroFilter extends class_437 {
   private final MacroSetting invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
   private String invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
   private int invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
   private long invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy;
   private boolean invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo;
   private final int invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = 530;
   private int invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW;
   private final int invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = 6;
   final MacroBox invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;

   public MacroFilter(MacroBox var1, MacroSetting var2) {
      super(class_2561.method_43473());
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = var1;
      this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = "";
      this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = 0;
      this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = 0L;
      this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = true;
      this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = 0;
      this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = var2;
   }

   public void method_25394(class_332 var1, int var2, int var3, float var4) {
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm();
      int var5 = var2 * (int)class_310.method_1551().method_22683().method_4495();
      int var6 = var3 * (int)class_310.method_1551().method_22683().method_4495();
      super.method_25394(var1, var5, var6, var4);
      int var7 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.mc.method_22683().method_4480();
      int var8 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.mc.method_22683().method_4507();
      short var9;
      if (DonutBBC.renderBackground.getValue()) {
         var9 = 180;
      } else {
         var9 = 0;
      }

      var1.method_25294(0, 0, var7, var8, (new Color(0, 0, 0, var9)).getRGB());
      double var10 = DonutBBC.guiScale.getValue();
      int var12 = (int)(600.0D * var10);
      int var13 = (int)(450.0D * var10);
      int var14 = (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.mc.method_22683().method_4480() - var12) / 2;
      int var15 = (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.mc.method_22683().method_4507() - var13) / 2;
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(30, 30, 35, 240), (double)var14, (double)var15, (double)(var14 + var12), (double)(var15 + var13), 8.0D, 8.0D, 8.0D, 8.0D, 20.0D);
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(40, 40, 45, 255), (double)var14, (double)var15, (double)(var14 + var12), (double)(var15 + 30), 8.0D, 8.0D, 0.0D, 0.0D, 20.0D);
      var1.method_25294(var14, var15 + 30, var14 + var12, var15 + 31, invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(255, 1).getRGB());
      invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp("Macro Editor: " + String.valueOf(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.getName()), var1, var14 + var12 / 2, var15 + 8, (new Color(245, 245, 245, 255)).getRGB());
      int var16 = var14 + 20;
      int var17 = var15 + 50;
      int var18 = var12 - 40;
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(20, 20, 25, 255), (double)var16, (double)var17, (double)(var16 + var18), (double)(var17 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, new Color(60, 60, 65, 255), (double)var16, (double)var17, (double)(var16 + var18), (double)(var17 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 2.0D, 20.0D);
      long var19 = System.currentTimeMillis();
      if (var19 - this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy > 530L) {
         this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo;
         this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = var19;
      }

      String var21 = this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
      if (this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo) {
         var21 = var21 + "|";
      }

      invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Add Command: " + var21, var1, var16 + 10, var17 + 8, (new Color(50, 50, 50, 255)).getRGB());
      int var22 = var16 + var18 - 80;
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(50, 205, 50, 255), (double)var22, (double)var17, (double)(var22 + 80), (double)(var17 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
      invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp("Add", var1, var22 + 40, var17 + 8, (new Color(245, 245, 245, 255)).getRGB());
      int var23 = var15 + 100;
      int var24 = var16;
      int var25 = var17 + 30 + 20;
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(40, 40, 45, 255), (double)var16, (double)var25, (double)(var16 + var18), (double)(var25 + 25), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
      invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp("Commands (" + this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.getCommands().size() + ")", var1, var16 + var18 / 2, var25 + 5, (new Color(245, 245, 245, 255)).getRGB());
      List var26 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.getCommands();
      int var10000 = this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW;
      Objects.requireNonNull(this);
      int var27 = var10000 * 6;
      Objects.requireNonNull(this);
      int var28 = Math.min(var27 + 6, var26.size());

      int var29;
      int var30;
      int var32;
      int var33;
      for(var29 = var27; var29 < var28; ++var29) {
         var30 = var25 + 30 + (var29 - var27) * 35;
         String var31 = (String)var26.get(var29);
         var32 = var18 - 100;
         invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(255, 255, 255, 200), (double)var24, (double)var30, (double)(var24 + var32), (double)(var30 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
         invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, new Color(60, 60, 65, 255), (double)var24, (double)var30, (double)(var24 + var32), (double)(var30 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 1.0D, 20.0D);
         invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var29 + 1 + ". " + var31, var1, var24 + 10, var30 + 8, (new Color(50, 50, 50, 255)).getRGB());
         var33 = var24 + var32 + 5;
         invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(220, 20, 60, 255), (double)var33, (double)var30, (double)(var33 + 75), (double)(var30 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
         invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp("Delete", var1, var33 + 37, var30 + 8, (new Color(245, 245, 245, 255)).getRGB());
      }

      var29 = var15 + var13 - 45;
      var30 = var14 + var12 - 80 - 20;
      int var34 = var30 - 80 - 10;
      var32 = var34 - 80 - 10;
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(50, 205, 50, 255), (double)var30, (double)var29, (double)(var30 + 80), (double)(var29 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
      invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp("Save", var1, var30 + 40, var29 + 8, (new Color(245, 245, 245, 255)).getRGB());
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(128, 128, 128, 255), (double)var34, (double)var29, (double)(var34 + 80), (double)(var29 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
      invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp("Cancel", var1, var34 + 40, var29 + 8, (new Color(245, 245, 245, 255)).getRGB());
      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(220, 20, 60, 255), (double)var32, (double)var29, (double)(var32 + 80), (double)(var29 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
      invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp("Clear All", var1, var32 + 40, var29 + 8, (new Color(245, 245, 245, 255)).getRGB());
      var10000 = var26.size();
      Objects.requireNonNull(this);
      if (var10000 > 6) {
         var10000 = var25 + 30;
         Objects.requireNonNull(this);
         var33 = var10000 + 6 * 35 + 10;
         if (this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW > 0) {
            invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(255, 105, 180, 255), (double)var24, (double)var33, (double)(var24 + 40), (double)(var33 + 20), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
            invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp("←", var1, var24 + 20, var33 + 5, (new Color(245, 245, 245, 255)).getRGB());
         }

         var10000 = this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW + 1;
         Objects.requireNonNull(this);
         if (var10000 * 6 < var26.size()) {
            invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(255, 105, 180, 255), (double)(var24 + var18 - 40), (double)var33, (double)(var24 + var18), (double)(var33 + 20), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
            invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp("→", var1, var24 + var18 - 20, var33 + 5, (new Color(245, 245, 245, 255)).getRGB());
         }
      }

      invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy();
   }

   public boolean method_25402(double var1, double var3, int var5) {
      double var6 = var1 * class_310.method_1551().method_22683().method_4495();
      double var8 = var3 * class_310.method_1551().method_22683().method_4495();
      double var10 = DonutBBC.guiScale.getValue();
      int var12 = (int)(600.0D * var10);
      int var13 = (int)(450.0D * var10);
      int var14 = (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.mc.method_22683().method_4480() - var12) / 2;
      int var15 = (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.mc.method_22683().method_4507() - var13) / 2;
      int var16 = var15 + var13 - 45;
      int var17 = var14 + var12 - 80 - 20;
      int var18 = var17 - 80 - 10;
      int var19 = var18 - 80 - 10;
      if (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var6, var8, var17, var16, 80, 30)) {
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.mc.method_1507(dev.krispyy.DonutBBC.INSTANCE.GUI);
         return true;
      } else if (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var6, var8, var18, var16, 80, 30)) {
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.mc.method_1507(dev.krispyy.DonutBBC.INSTANCE.GUI);
         return true;
      } else if (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var6, var8, var19, var16, 80, 30)) {
         this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.clearCommands();
         return true;
      } else {
         int var20 = var14 + 20;
         int var21 = var15 + 50;
         int var22 = var12 - 40;
         if (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var6, var8, var20 + var22 - 80, var21, 80, 30)) {
            if (!this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.trim().isEmpty()) {
               this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.addCommand(this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.trim());
               this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = "";
               this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = 0;
            }

            return true;
         } else {
            List var23 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.getCommands();
            int var10000 = this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW;
            Objects.requireNonNull(this);
            int var24 = var10000 * 6;
            Objects.requireNonNull(this);
            int var25 = Math.min(var24 + 6, var23.size());

            int var26;
            for(var26 = var24; var26 < var25; ++var26) {
               int var27 = var15 + 100 + 30 + 20 + 30 + (var26 - var24) * 35;
               int var28 = var22 - 100;
               int var29 = var14 + 20 + var28 + 5;
               if (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var6, var8, var29, var27, 75, 30)) {
                  this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.removeCommand(var26);
                  return true;
               }
            }

            var10000 = var23.size();
            Objects.requireNonNull(this);
            if (var10000 > 6) {
               var10000 = var15 + 100 + 30 + 20 + 30;
               Objects.requireNonNull(this);
               var26 = var10000 + 6 * 35 + 10;
               if (this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW > 0 && this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var6, var8, var14 + 20, var26, 40, 20)) {
                  --this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW;
                  return true;
               }

               var10000 = this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW + 1;
               Objects.requireNonNull(this);
               if (var10000 * 6 < var23.size() && this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var6, var8, var14 + 20 + var22 - 40, var26, 40, 20)) {
                  ++this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW;
                  return true;
               }
            }

            return super.method_25402(var6, var8, var5);
         }
      }
   }

   public boolean method_25404(int var1, int var2, int var3) {
      this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = true;
      this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = System.currentTimeMillis();
      if (var1 == 256) {
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.mc.method_1507(dev.krispyy.DonutBBC.INSTANCE.GUI);
         return true;
      } else if (var1 == 257) {
         if (!this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.trim().isEmpty()) {
            this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.addCommand(this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.trim());
            this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = "";
            this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = 0;
         }

         return true;
      } else if (var1 == 259) {
         if (this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm > 0) {
            String var10001 = this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.substring(0, this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm - 1);
            this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = var10001 + this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.substring(this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm);
            --this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
         }

         return true;
      } else if (var1 == 262) {
         if (this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm < this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.length()) {
            ++this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
         }

         return true;
      } else if (var1 == 263) {
         if (this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm > 0) {
            --this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
         }

         return true;
      } else {
         return super.method_25404(var1, var2, var3);
      }
   }

   public boolean method_25400(char var1, int var2) {
      if (Character.isISOControl(var1)) {
         return false;
      } else {
         this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.substring(0, this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm) + var1 + this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.substring(this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm);
         ++this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
         return true;
      }
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(double var1, double var3, int var5, int var6, int var7, int var8) {
      return var1 >= (double)var5 && var1 <= (double)(var5 + var7) && var3 >= (double)var6 && var3 <= (double)(var6 + var8);
   }
}
