package dev.krispyy.gui;

import dev.krispyy.gui.components.ModuleButton;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
import dev.krispyy.module.setting.Setting;
import java.awt.Color;
import net.minecraft.class_310;
import net.minecraft.class_332;

public abstract class Component {
   public class_310 mc = class_310.method_1551();
   public ModuleButton parent;
   public Setting setting;
   public int offset;
   public Color currentColor;
   public boolean mouseOver;
   int invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
   int invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
   int invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
   int invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;

   public Component(ModuleButton var1, Setting var2, int var3) {
      this.parent = var1;
      this.setting = var2;
      this.offset = var3;
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = this.parentX();
      this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = this.parentY() + this.parentOffset() + var3;
      this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = this.parentX() + this.parentWidth();
      this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = this.parentY() + this.parentOffset() + var3 + this.parentHeight();
   }

   public int parentX() {
      return this.parent.parent.getX();
   }

   public int parentY() {
      return this.parent.parent.getY();
   }

   public int parentWidth() {
      return this.parent.parent.getWidth();
   }

   public int parentHeight() {
      return this.parent.parent.getHeight();
   }

   public int parentOffset() {
      return this.parent.offset;
   }

   public void render(class_332 var1, int var2, int var3, float var4) {
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((double)var2, (double)var3);
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = this.parentX();
      this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = this.parentY() + this.parentOffset() + this.offset;
      this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = this.parentX() + this.parentWidth();
      this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = this.parentY() + this.parentOffset() + this.offset + this.parentHeight();
      if (this.currentColor == null) {
         this.currentColor = new Color(0, 0, 0, 0);
      }

      var1.method_25294(this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp, this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq, this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm, this.currentColor.getRGB());
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(double var1, double var3) {
      this.mouseOver = this.isHovered(var1, var3);
   }

   public void renderDescription(class_332 var1, int var2, int var3, float var4) {
      if (this.isHovered((double)var2, (double)var3) && this.setting.getDescription() != null && !this.parent.parent.dragging) {
         CharSequence var5 = this.setting.getDescription();
         int var6 = invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var5);
         int var7 = this.mc.method_22683().method_4480() / 2 - var6 / 2;
         invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.method_51448(), new Color(100, 100, 100, 100), (double)(var7 - 5), (double)(this.mc.method_22683().method_4507() / 2 + 294), (double)(var7 + var6 + 5), (double)(this.mc.method_22683().method_4507() / 2 + 318), 3.0D, 10.0D);
         invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var5, var1, var7, this.mc.method_22683().method_4507() / 2 + 300, Color.WHITE.getRGB());
      }

   }

   public void onGuiClose() {
      this.currentColor = null;
   }

   public void keyPressed(int var1, int var2, int var3) {
   }

   public boolean isHovered(double var1, double var3) {
      return var1 > (double)this.parentX() && var1 < (double)(this.parentX() + this.parentWidth()) && var3 > (double)(this.offset + this.parentOffset() + this.parentY()) && var3 < (double)(this.offset + this.parentOffset() + this.parentY() + this.parentHeight());
   }

   public void onUpdate() {
      if (this.currentColor == null) {
         this.currentColor = new Color(0, 0, 0, 0);
      } else {
         this.currentColor = new Color(0, 0, 0, this.currentColor.getAlpha());
      }

      if (this.currentColor.getAlpha() != 120) {
         this.currentColor = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(0.05F, 120, this.currentColor);
      }

   }

   public void mouseClicked(double var1, double var3, int var5) {
   }

   public void mouseReleased(double var1, double var3, int var5) {
   }

   public void mouseDragged(double var1, double var3, int var5, double var6, double var8) {
   }
}
