package dev.krispyy.module;

import dev.krispyy.gui.ClickGUI;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
import dev.krispyy.module.modules.client.ConfigDebug;
import dev.krispyy.module.modules.client.DonutBBC;
import dev.krispyy.module.modules.client.Friends;
import dev.krispyy.module.modules.client.SelfDestruct;
import dev.krispyy.module.modules.combat.ElytraSwap;
import dev.krispyy.module.modules.combat.Hitbox;
import dev.krispyy.module.modules.combat.MaceSwap;
import dev.krispyy.module.modules.combat.StaticHitboxes;
import dev.krispyy.module.modules.crystal.AnchorMacro;
import dev.krispyy.module.modules.crystal.AutoCrystal;
import dev.krispyy.module.modules.crystal.AutoHitCrystal;
import dev.krispyy.module.modules.crystal.AutoInventoryTotem;
import dev.krispyy.module.modules.crystal.AutoTotem;
import dev.krispyy.module.modules.crystal.DoubleAnchor;
import dev.krispyy.module.modules.crystal.HoverTotem;
import dev.krispyy.module.modules.donut.AntiTrap;
import dev.krispyy.module.modules.donut.AuctionSniper;
import dev.krispyy.module.modules.donut.AutoSell;
import dev.krispyy.module.modules.donut.AutoSpawnerSell;
import dev.krispyy.module.modules.donut.BoneDropper;
import dev.krispyy.module.modules.donut.NetheriteFinder;
import dev.krispyy.module.modules.donut.RTPEndBaseFinder;
import dev.krispyy.module.modules.donut.RtpBaseFinder;
import dev.krispyy.module.modules.donut.ShulkerDropper;
import dev.krispyy.module.modules.donut.TunnelBaseFinder;
import dev.krispyy.module.modules.misc.AutoEat;
import dev.krispyy.module.modules.misc.AutoFirework;
import dev.krispyy.module.modules.misc.AutoMine;
import dev.krispyy.module.modules.misc.AutoTPA;
import dev.krispyy.module.modules.misc.AutoTool;
import dev.krispyy.module.modules.misc.CordSnapper;
import dev.krispyy.module.modules.misc.ElytraGlide;
import dev.krispyy.module.modules.misc.FastPlace;
import dev.krispyy.module.modules.misc.Freecam;
import dev.krispyy.module.modules.misc.KeyPearl;
import dev.krispyy.module.modules.misc.NameProtect;
import dev.krispyy.module.modules.misc.PearlBoost;
import dev.krispyy.module.modules.misc.QuickMacro;
import dev.krispyy.module.modules.misc.TridentBoost;
import dev.krispyy.module.modules.misc.WeatherNotifier;
import dev.krispyy.module.modules.render.Animations;
import dev.krispyy.module.modules.render.ChunkFinder;
import dev.krispyy.module.modules.render.FullBright;
import dev.krispyy.module.modules.render.HUD;
import dev.krispyy.module.modules.render.KelpESP;
import dev.krispyy.module.modules.render.NoRender;
import dev.krispyy.module.modules.render.PlayerESP;
import dev.krispyy.module.modules.render.ScoreboardModule;
import dev.krispyy.module.modules.render.StorageESP;
import dev.krispyy.module.modules.render.SwingSpeed;
import dev.krispyy.module.modules.render.TargetHUD;
import dev.krispyy.module.modules.render.TridentESP;
import dev.krispyy.module.setting.BindSetting;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.class_408;

public final class ModuleManager {
   private final List<Module> invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = new ArrayList();

   public ModuleManager() {
      this.a();
      this.d();
   }

   public void a() {
      this.add(new ElytraSwap());
      this.add(new Hitbox());
      this.add(new MaceSwap());
      this.add(new StaticHitboxes());
      this.add(new ConfigDebug());
      this.add(new DonutBBC());
      this.add(new SelfDestruct());
      this.add(new Friends());
      this.add(new Animations());
      this.add(new ChunkFinder());
      this.add(new FullBright());
      this.add(new HUD());
      this.add(new KelpESP());
      this.add(new NoRender());
      this.add(new PlayerESP());
      this.add(new StorageESP());
      this.add(new SwingSpeed());
      this.add(new TargetHUD());
      this.add(new TridentESP());
      this.add(new ScoreboardModule());
      this.add(new AutoEat());
      this.add(new AutoFirework());
      this.add(new AutoMine());
      this.add(new AutoTPA());
      this.add(new AutoTool());
      this.add(new CordSnapper());
      this.add(new ElytraGlide());
      this.add(new FastPlace());
      this.add(new Freecam());
      this.add(new KeyPearl());
      this.add(new NameProtect());
      this.add(new WeatherNotifier());
      this.add(new TridentBoost());
      this.add(new PearlBoost());
      this.add(new AnchorMacro());
      this.add(new AutoCrystal());
      this.add(new AutoHitCrystal());
      this.add(new AutoInventoryTotem());
      this.add(new AutoTotem());
      this.add(new DoubleAnchor());
      this.add(new HoverTotem());
      this.add(new AntiTrap());
      this.add(new AuctionSniper());
      this.add(new AutoSell());
      this.add(new AutoSpawnerSell());
      this.add(new BoneDropper());
      this.add(new NetheriteFinder());
      this.add(new RtpBaseFinder());
      this.add(new RTPEndBaseFinder());
      this.add(new ShulkerDropper());
      this.add(new TunnelBaseFinder());
      this.add(new QuickMacro());
      Friends var1 = Friends.getInstance();
      var1.setEnabled(true);
   }

   public List<Module> b() {
      return this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.stream().filter(Module::isEnabled).toList();
   }

   public List<Module> c() {
      return this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
   }

   public void d() {
      dev.krispyy.DonutBBC.INSTANCE.getEventBus().register(this);
      Iterator var1 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.iterator();

      while(var1.hasNext()) {
         Module var2 = (Module)var1.next();
         var2.addsetting((new BindSetting(invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Keybind"), var2.getKeybind(), true)).setDescription(invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Key to enabled the module")));
      }

   }

   public List<Module> a(Category var1) {
      return this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.stream().filter((var1x) -> {
         return var1x.getCategory() == var1;
      }).toList();
   }

   public Module getModuleByClass(Class<? extends Module> var1) {
      Objects.requireNonNull(var1);
      Stream var10000 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.stream();
      Objects.requireNonNull(var1);
      return (Module)var10000.filter(var1::isInstance).findFirst().orElse((Object)null);
   }

   public void add(Module var1) {
      dev.krispyy.DonutBBC.INSTANCE.getEventBus().register(var1);
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.add(var1);
   }

   @invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq
   public void a(invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW var1) {
      if (dev.krispyy.DonutBBC.mc.field_1724 != null && !(dev.krispyy.DonutBBC.mc.field_1755 instanceof class_408)) {
         if (!(dev.krispyy.DonutBBC.mc.field_1755 instanceof ClickGUI)) {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.forEach((var1x) -> {
               if (var1x.getKeybind() == var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw && var1.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp == 1) {
                  if (var1x instanceof SelfDestruct && SelfDestruct.isActive) {
                     return;
                  }

                  if (var1x instanceof DonutBBC && SelfDestruct.hasSelfDestructed) {
                     return;
                  }

                  var1x.toggle();
               }

            });
         }
      }
   }
}
