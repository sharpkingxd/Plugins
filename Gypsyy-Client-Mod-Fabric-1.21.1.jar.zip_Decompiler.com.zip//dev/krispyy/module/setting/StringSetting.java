package dev.krispyy.module.setting;

public class StringSetting extends Setting {
   public String value;

   public StringSetting(CharSequence var1, String var2) {
      super(var1);
      this.value = var2;
   }

   public void setValue(String var1) {
      this.value = var1;
   }

   public String getValue() {
      return this.value;
   }

   public StringSetting setDescription(CharSequence var1) {
      super.setDescription(var1);
      return this;
   }
}
