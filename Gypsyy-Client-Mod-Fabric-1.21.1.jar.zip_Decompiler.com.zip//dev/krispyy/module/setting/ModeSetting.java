package dev.krispyy.module.setting;

import java.util.Arrays;
import java.util.List;

public final class ModeSetting<T extends Enum<T>> extends Setting {
   public int index;
   private final List<T> invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
   private final int invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;

   public ModeSetting(CharSequence var1, T var2, Class<T> var3) {
      super(var1);
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = Arrays.asList((Enum[])var3.getEnumConstants());
      this.index = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.indexOf(var2);
      this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = this.index;
   }

   public Enum<T> getValue() {
      return (Enum)this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.get(this.index);
   }

   public void setMode(Enum<T> var1) {
      this.index = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.indexOf(var1);
   }

   public void setModeIndex(int var1) {
      this.index = var1;
   }

   public int getModeIndex() {
      return this.index;
   }

   public int getOriginalValue() {
      return this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
   }

   public void cycleUp() {
      if (this.index < this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.size() - 1) {
         ++this.index;
      } else {
         this.index = 0;
      }

   }

   public void cycleDown() {
      if (this.index > 0) {
         --this.index;
      } else {
         this.index = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.size() - 1;
      }

   }

   public boolean isMode(Enum<T> var1) {
      return this.index == this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.indexOf(var1);
   }

   public List<T> getPossibleValues() {
      return this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
   }

   public ModeSetting<T> setDescription(CharSequence var1) {
      super.setDescription(var1);
      return this;
   }
}
