package dev.krispyy.module.setting;

public final class NumberSetting extends Setting {
   private final double invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
   private final double invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
   private double invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
   private final double invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
   private final double invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy;

   public NumberSetting(CharSequence var1, double var2, double var4, double var6, double var8) {
      super(var1);
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = var2;
      this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = var4;
      this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = var6;
      this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = var8;
      this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = var6;
   }

   public double getValue() {
      return this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
   }

   public double getDefaultValue() {
      return this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy;
   }

   public double getFormat() {
      return this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
   }

   public double getMin() {
      return this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
   }

   public double getMax() {
      return this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
   }

   public int getIntValue() {
      return (int)this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
   }

   public float getFloatValue() {
      return (float)this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
   }

   public long getLongValue() {
      return (long)this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
   }

   public void setValue(double var1) {
      double var3 = 1.0D / this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
      this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = (double)Math.round(Math.max(this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, Math.min(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp, var1)) * var3) / var3;
   }

   public void getValue(double var1) {
      this.setValue(var1);
   }

   public NumberSetting getValue(CharSequence var1) {
      super.setDescription(var1);
      return this;
   }

   public NumberSetting setDescription(CharSequence var1) {
      super.setDescription(var1);
      return this;
   }
}
