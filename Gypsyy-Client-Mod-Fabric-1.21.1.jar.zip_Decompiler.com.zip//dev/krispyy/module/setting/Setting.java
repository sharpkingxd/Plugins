package dev.krispyy.module.setting;

public abstract class Setting {
   private CharSequence invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
   public CharSequence description;

   public Setting(CharSequence var1) {
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = var1;
   }

   public void getDescription(CharSequence var1) {
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = var1;
   }

   public CharSequence getName() {
      return this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
   }

   public CharSequence getDescription() {
      return this.description;
   }

   public Setting setDescription(CharSequence var1) {
      this.description = var1;
      return this;
   }
}
