package dev.krispyy.module.modules.donut;

import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
import dev.krispyy.module.Category;
import dev.krispyy.module.Module;
import dev.krispyy.module.setting.NumberSetting;
import dev.krispyy.module.setting.Setting;
import dev.krispyy.module.setting.StringSetting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import net.minecraft.class_1923;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2826;
import net.minecraft.class_2919;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5321;
import net.minecraft.class_638;
import net.minecraft.class_7833;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2902.class_2903;
import net.minecraft.class_2919.class_6675;

public final class NetheriteFinder extends Module {
   private final NumberSetting invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = new NumberSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Alpha"), 1.0D, 255.0D, 125.0D, 1.0D);
   private final NumberSetting invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = new NumberSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Range"), 1.0D, 10.0D, 5.0D, 1.0D);
   private final StringSetting invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = new StringSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Custom Seed"), "6608149111735331168");
   private final Map<Long, Map<invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, Set<class_243>>> invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = new ConcurrentHashMap();
   private Map<class_5321<class_1959>, List<invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw>> invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;

   public NetheriteFinder() {
      super(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Netherite Finder"), dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Finds netherites"), -1, Category.DONUT);
      this.addsettings(new Setting[]{this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq, this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm, this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy});
   }

   public void onEnable() {
      super.onEnable();
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
   }

   public void onDisable() {
      super.onDisable();
      this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.clear();
   }

   @invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq
   public void onRender3D(invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG var1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null && this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku != null) {
         class_4184 var2 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1773.method_19418();
         if (var2 != null) {
            class_4587 var3 = var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
            var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.method_22903();
            class_243 var4 = var2.method_19326();
            class_7833 var5 = class_7833.field_40714;
            var3.method_22907(var5.rotationDegrees(var2.method_19329()));
            class_7833 var6 = class_7833.field_40716;
            var3.method_22907(var6.rotationDegrees(var2.method_19330() + 180.0F));
            var3.method_22904(-var4.field_1352, -var4.field_1351, -var4.field_1350);
         }

         int var8 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_31476().field_9181;
         int var9 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_31476().field_9180;
         int var10 = this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getIntValue();

         for(int var11 = var8 - var10; var11 <= var8 + var10; ++var11) {
            for(int var7 = var9 - var10; var7 <= var9 + var10; ++var7) {
               this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var11, var7, var1);
            }
         }

         var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.method_22909();
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var1, int var2, invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG var3) {
      long var4 = class_1923.method_8331(var1, var2);
      Map var6 = (Map)this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.get(var4);
      if (var6 != null) {
         Iterator var7 = var6.entrySet().iterator();

         while(var7.hasNext()) {
            Entry var8 = (Entry)var7.next();
            Iterator var9 = ((Set)var8.getValue()).iterator();

            while(var9.hasNext()) {
               class_243 var10 = (class_243)var9.next();
               class_4587 var11 = var3.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
               float var12 = (float)var10.field_1352;
               float var13 = (float)var10.field_1351;
               float var14 = (float)var10.field_1350;
               invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var11, var12, var13, var14, (float)(var10.field_1352 + 1.0D), (float)(var10.field_1351 + 1.0D), (float)(var10.field_1350 + 1.0D), this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.getIntValue()));
            }
         }
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.clear();
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 != null) {
         this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
         this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp();
      }

   }

   private Color invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var1) {
      return new Color(191, 64, 191, var1);
   }

   @invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq
   public void onChunkDataReceived(invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm var1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku == null && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 != null) {
         this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
      }

      class_638 var2 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687;
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((class_2791)var2.method_8497(var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.method_11523(), var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.method_11524()));
   }

   @invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq
   public void onBlockStateChange(invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz var1) {
      if (var1.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.method_26204().equals(class_2246.field_10124)) {
         long var2 = class_1923.method_37232(var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw);
         Map var4 = (Map)this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.get(var2);
         if (var4 != null) {
            class_243 var5 = class_243.method_24954(var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw);
            Iterator var6 = var4.values().iterator();

            while(var6.hasNext()) {
               Set var7 = (Set)var6.next();
               var7.remove(var5);
            }
         }
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp() {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
         Iterator var1 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw().iterator();

         while(var1.hasNext()) {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((class_2791)var1.next());
         }
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_2791 var1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku != null) {
         class_1923 var2 = var1.method_12004();
         long var3 = var2.method_8324();
         class_638 var5 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687;
         if (!this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.containsKey(var3) && var5 != null) {
            HashSet var6 = new HashSet();
            class_1923.method_19280(var2, 1).forEach((var2x) -> {
               class_2791 var3 = var5.method_8402(var2x.field_9181, var2x.field_9180, class_2806.field_12794, false);
               if (var3 != null) {
                  class_2826[] var4 = var3.method_12006();

                  for(int var5x = 0; var5x < var4.length; ++var5x) {
                     var4[var5x].method_38294().method_39793((var1) -> {
                        var6.add((class_5321)var1.method_40230().get());
                     });
                  }
               }

            });
            Set var7 = (Set)var6.stream().flatMap((var1x) -> {
               return this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1x).stream();
            }).collect(Collectors.toSet());
            int var8 = var2.field_9181 << 4;
            int var9 = var2.field_9180 << 4;
            class_2919 var10 = new class_2919(class_6675.field_35143.method_39006(0L));

            long var11;
            try {
               var11 = Long.parseLong(this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getValue());
            } catch (NumberFormatException var25) {
               var11 = 6608149111735331168L;
            }

            long var13 = var10.method_12661(var11, var8, var9);
            HashMap var15 = new HashMap();
            Iterator var16 = var7.iterator();

            while(var16.hasNext()) {
               invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw var17 = (invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw)var16.next();
               HashSet var18 = new HashSet();
               var10.method_12664(var13, var17.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp, var17.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw);
               int var19 = var17.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.method_35008(var10);

               for(int var20 = 0; var20 < var19; ++var20) {
                  if (var17.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo != 1.0F) {
                     float var21 = 1.0F / var17.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo;
                     if (var10.method_43057() >= var21) {
                        continue;
                     }
                  }

                  int var26 = var10.method_43048(16) + var8;
                  int var22 = var10.method_43048(16) + var9;
                  int var23 = var17.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.method_35391(var10, var17.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy);
                  class_2338 var24 = new class_2338(var26, var23, var22);
                  if (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((class_5321)var1.method_16359(var26, var23, var22).method_40230().get()).contains(var17)) {
                     if (var17.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX) {
                        var18.addAll(this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var5, var10, var24, var17.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW));
                     } else {
                        var18.addAll(this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var5, var10, var24, var17.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW, var17.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku));
                     }
                  }
               }

               if (!var18.isEmpty()) {
                  var15.put(var17, var18);
               }
            }

            this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.put(var3, var15);
         }
      }

   }

   private List<invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw> invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_5321<class_1959> var1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku == null) {
         this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
      }

      return this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.containsKey(var1) ? (List)this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.get(var1) : (List)this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.values().stream().findAny().get();
   }

   private ArrayList<class_243> invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_638 var1, class_2919 var2, class_2338 var3, int var4, float var5) {
      float var6 = var2.method_43057() * 3.1415927F;
      float var7 = (float)var4 / 8.0F;
      int var8 = class_3532.method_15386(((float)var4 / 16.0F * 2.0F + 1.0F) / 2.0F);
      int var9 = var3.method_10263();
      int var10 = var3.method_10263();
      double var11 = Math.sin((double)var6);
      int var13 = var3.method_10260();
      int var14 = var3.method_10260();
      double var15 = Math.cos((double)var6);
      int var17 = var3.method_10264();
      int var18 = var3.method_10264();
      int var19 = var3.method_10263() - class_3532.method_15386(var7) - var8;
      int var20 = var3.method_10264() - 2 - var8;
      int var21 = var3.method_10260() - class_3532.method_15386(var7) - var8;
      int var22 = 2 * (class_3532.method_15386(var7) + var8);

      for(int var23 = var19; var23 <= var19 + var22; ++var23) {
         for(int var24 = var21; var24 <= var21 + var22; ++var24) {
            if (var20 <= var1.method_8624(class_2903.field_13197, var23, var24)) {
               return this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var2, var4, (double)var9 + Math.sin((double)var6) * (double)var7, (double)var10 - var11 * (double)var7, (double)var13 + Math.cos((double)var6) * (double)var7, (double)var14 - var15 * (double)var7, (double)(var17 + var2.method_43048(3) - 2), (double)(var18 + var2.method_43048(3) - 2), var19, var20, var21, var22, 2 * (2 + var8), var5);
            }
         }
      }

      return new ArrayList();
   }

   private ArrayList<class_243> invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_638 var1, class_2919 var2, int var3, double var4, double var6, double var8, double var10, double var12, double var14, int var16, int var17, int var18, int var19, int var20, float var21) {
      BitSet var22 = new BitSet(var19 * var20 * var19);
      class_2339 var23 = new class_2339();
      double[] var24 = new double[var3 * 4];
      ArrayList var25 = new ArrayList();

      int var26;
      double var30;
      double var32;
      for(var26 = 0; var26 < var3; ++var26) {
         float var27 = (float)var26 / (float)var3;
         double var28 = class_3532.method_16436((double)var27, var4, var6);
         var30 = class_3532.method_16436((double)var27, var12, var14);
         var32 = class_3532.method_16436((double)var27, var8, var10);
         var24[var26 * 4] = var28;
         var24[var26 * 4 + 1] = var30;
         var24[var26 * 4 + 2] = var32;
         var24[var26 * 4 + 3] = ((double)(class_3532.method_15374(3.1415927F * var27) + 1.0F) * (var2.method_43058() * (double)var3 / 16.0D) + 1.0D) / 2.0D;
      }

      double var56;
      for(var26 = 0; var26 < var3 - 1; ++var26) {
         var56 = var24[var26 * 4 + 3];
         if (!(var56 <= 0.0D)) {
            for(int var29 = var26 + 1; var29 < var3; ++var29) {
               var30 = var24[var29 * 4 + 3];
               if (!(var30 <= 0.0D)) {
                  var32 = var24[var26 * 4];
                  double var34 = var24[var29 * 4];
                  double var36 = var32 - var34;
                  double var38 = var24[var26 * 4 + 1];
                  double var40 = var24[var29 * 4 + 1];
                  double var42 = var38 - var40;
                  double var44 = var24[var26 * 4 + 2];
                  double var46 = var24[var29 * 4 + 2];
                  double var48 = var44 - var46;
                  double var50 = var24[var26 * 4 + 3];
                  double var52 = var24[var29 * 4 + 3];
                  double var54 = var50 - var52;
                  if (var54 * var54 > var36 * var36 + var42 * var42 + var48 * var48) {
                     if (var54 > 0.0D) {
                        var24[var29 * 4 + 3] = -1.0D;
                     } else {
                        var24[var26 * 4 + 3] = -1.0D;
                     }
                  }
               }
            }
         }
      }

      for(var26 = 0; var26 < var3; ++var26) {
         var56 = var24[var26 * 4 + 3];
         if (!(var56 < 0.0D)) {
            double var57 = var24[var26 * 4];
            double var31 = var24[var26 * 4 + 1];
            double var33 = var24[var26 * 4 + 2];
            int var35 = Math.max(class_3532.method_15357(var57 - var56), var16);
            int var58 = Math.max(class_3532.method_15357(var31 - var56), var17);
            int var37 = Math.max(class_3532.method_15357(var33 - var56), var18);
            int var59 = Math.max(class_3532.method_15357(var57 + var56), var35);
            int var39 = Math.max(class_3532.method_15357(var31 + var56), var58);

            for(int var60 = Math.max(class_3532.method_15357(var33 + var56), var37); var35 <= var59; ++var35) {
               double var41 = ((double)var35 + 0.5D - var57) / var56;
               if (var41 * var41 < 1.0D) {
                  for(; var58 <= var39; ++var58) {
                     double var43 = ((double)var58 + 0.5D - var31) / var56;
                     if (var41 * var41 + var43 * var43 < 1.0D && var37 <= var60) {
                        double var45 = ((double)var37 + 0.5D - var33) / var56;
                        if (var41 * var41 + var43 * var43 + var45 * var45 < 1.0D) {
                           int var47 = var35 - var16 + (var58 - var17) * var19 + (var37 - var18) * var19 * var20;
                           if (!var22.get(var47)) {
                              var22.set(var47);
                              var23.method_10103(var35, var58, var37);
                              if (var58 >= -64 && var58 < 320 && var1.method_8320(var23).method_26225() && this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var23, var21, var2)) {
                                 var25.add(new class_243((double)var35, (double)var58, (double)var37));
                              }
                           }
                        }

                        ++var37;
                     }
                  }
               }
            }
         }
      }

      return var25;
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_638 var1, class_2338 var2, float var3, class_2919 var4) {
      if (var3 != 0.0F && (var3 == 1.0F || !(var4.method_43057() >= var3))) {
         class_2350[] var5 = class_2350.values();
         class_2350[] var6 = var5;
         int var7 = var5.length;

         for(int var8 = 0; var8 < var7; ++var8) {
            class_2350 var9 = var6[var8];
            if (!var1.method_8320(var2.method_10081(var9.method_10163())).method_26225() && var3 != 1.0F) {
               return false;
            }
         }
      }

      return true;
   }

   private ArrayList<class_243> invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_638 var1, class_2919 var2, class_2338 var3, int var4) {
      ArrayList var5 = new ArrayList();
      int var6 = var2.method_43048(var4 + 1);

      for(int var7 = 0; var7 < var6; ++var7) {
         int var8 = Math.min(var7, 7);
         int var9 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var2, var8) + var3.method_10263();
         int var10 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var2, var8) + var3.method_10264();
         int var11 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var2, var8) + var3.method_10260();
         if (var1.method_8320(new class_2338(var9, var10, var11)).method_26225() && this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, new class_2338(var9, var10, var11), 1.0F, var2)) {
            var5.add(new class_243((double)var9, (double)var10, (double)var11));
         }
      }

      return var5;
   }

   private int invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_2919 var1, int var2) {
      return Math.round((var1.method_43057() - var1.method_43057()) * (float)var2);
   }
}
