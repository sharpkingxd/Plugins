package dev.krispyy.module.modules.donut;

import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
import dev.krispyy.module.Category;
import dev.krispyy.module.Module;
import dev.krispyy.module.setting.ModeSetting;
import dev.krispyy.module.setting.NumberSetting;
import dev.krispyy.module.setting.Setting;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_304;
import net.minecraft.class_3675.class_307;

public final class BoneDropper extends Module {
   private final ModeSetting<BoneDropper.Mode> invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
   private final NumberSetting invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
   private final NumberSetting invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy;
   private int invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo;
   private boolean invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;

   public BoneDropper() {
      super(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Bone Dropper"), dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Automatically drops bones from spawner"), -1, Category.DONUT);
      this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = new ModeSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Mode"), BoneDropper.Mode.SPAWNER, BoneDropper.Mode.class);
      this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = (new NumberSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Drop Delay"), 0.0D, 120.0D, 30.0D, 1.0D)).getValue(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("How often it should start dropping bones in minutes"));
      this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = (new NumberSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Page Switch Delay"), 0.0D, 720.0D, 4.0D, 1.0D)).getValue(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("How often it should switch pages in seconds"));
      this.addsettings(new Setting[]{this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq, this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm, this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy});
   }

   public void onEnable() {
      super.onEnable();
      this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 20;
      this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = false;
   }

   public void onDisable() {
      super.onDisable();
   }

   @invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq
   public void onTick(invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi var1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo > 0) {
         --this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo;
      } else if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
         int var3;
         if (this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.isMode(BoneDropper.Mode.SPAWNER)) {
            if (!(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512 instanceof class_1707)) {
               class_304.method_1420(class_307.field_1672.method_1447(1));
               this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 20;
               return;
            }

            if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.method_7611(13).method_7677().method_31574(class_1802.field_8398)) {
               this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2906(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.field_7763, 11, 0, class_1713.field_7790, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724);
               this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 20;
               return;
            }

            if (!this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.method_7611(53).method_7677().method_31574(class_1802.field_8695)) {
               this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_7346();
               this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 20;
               return;
            }

            if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.method_7611(48).method_7677().method_31574(class_1802.field_8107)) {
               this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2906(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.field_7763, 48, 0, class_1713.field_7790, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724);
               this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 20;
               return;
            }

            boolean var2 = true;

            for(var3 = 0; var3 < 45; ++var3) {
               if (!this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.method_7611(var3).method_7677().method_31574(class_1802.field_8606)) {
                  var2 = false;
                  break;
               }
            }

            if (var2) {
               this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2906(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.field_7763, 52, 1, class_1713.field_7795, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724);
               this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = true;
               this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getIntValue() * 20;
            } else if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku) {
               this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = false;
               this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2906(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.field_7763, 50, 0, class_1713.field_7790, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724);
               this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 20;
            } else {
               this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2906(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.field_7763, 45, 1, class_1713.field_7795, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724);
               this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = false;
               this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 1200 * this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getIntValue();
            }
         } else {
            class_1703 var4 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512;
            if (!(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512 instanceof class_1707)) {
               this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.method_1562().method_45730("order");
               this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 20;
               return;
            }

            if (((class_1707)var4).method_17388() == 6) {
               if (var4.method_7611(49).method_7677().method_31574(class_1802.field_8895)) {
                  this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2906(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.field_7763, 51, 0, class_1713.field_7790, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724);
                  this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 20;
                  return;
               }

               for(var3 = 0; var3 < 45; ++var3) {
                  if (var4.method_7611(var3).method_7677().method_31574(class_1802.field_8606)) {
                     this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2906(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.field_7763, var3, 1, class_1713.field_7795, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724);
                     this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getIntValue();
                     return;
                  }
               }

               byte var5;
               if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku) {
                  var5 = 45;
               } else {
                  var5 = 53;
               }

               this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2906(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.field_7763, var5, 0, class_1713.field_7790, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724);
               this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = !this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
               this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getIntValue();
            } else if (((class_1707)var4).method_17388() == 3) {
               if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1755 == null) {
                  return;
               }

               if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1755.method_25440().getString().contains("Your Orders")) {
                  for(var3 = 0; var3 < 26; ++var3) {
                     if (var4.method_7611(var3).method_7677().method_31574(class_1802.field_8606)) {
                        this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2906(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.field_7763, var3, 0, class_1713.field_7790, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724);
                        this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 20;
                        return;
                     }
                  }

                  this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 200;
                  return;
               }

               if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1755.method_25440().getString().contains("Edit Order")) {
                  if (var4.method_7611(13).method_7677().method_31574(class_1802.field_8106)) {
                     this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2906(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.field_7763, 13, 0, class_1713.field_7790, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724);
                     this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 20;
                     return;
                  }

                  if (var4.method_7611(15).method_7677().method_31574(class_1802.field_8106)) {
                     this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2906(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.field_7763, 15, 0, class_1713.field_7790, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724);
                     this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 20;
                     return;
                  }
               }

               this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 200;
            }
         }

      }
   }

   static enum Mode {
      SPAWNER("Spawner", 0),
      ORDER("Order", 1);

      private Mode(String var3, int var4) {
      }

      // $FF: synthetic method
      private static BoneDropper.Mode[] invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
         return new BoneDropper.Mode[]{SPAWNER, ORDER};
      }
   }
}
