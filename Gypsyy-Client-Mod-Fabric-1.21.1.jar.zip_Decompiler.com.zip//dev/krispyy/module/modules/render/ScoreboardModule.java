package dev.krispyy.module.modules.render;

import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
import dev.krispyy.module.Category;
import dev.krispyy.module.Module;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_8646;
import net.minecraft.class_9014;
import net.minecraft.class_9015;
import net.minecraft.class_9022;
import net.minecraft.class_274.class_275;

public final class ScoreboardModule extends Module {
   private static final String invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = "gypsyy_scoreboard";
   private class_266 invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
   private class_266 invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy;
   private boolean invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = false;
   private final Boolean invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = true;

   public ScoreboardModule() {
      super(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Fake Scoreboard"), dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Custom scoreboard overlay"), -1, Category.RENDER);
   }

   public void onEnable() {
      super.onEnable();
      this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = true;
   }

   public void onDisable() {
      super.onDisable();
      this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq();
      this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = false;
   }

   @invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq
   public void onTick(invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi this) {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 != null) {
         if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku && this.isEnabled()) {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
         } else if (this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo) {
            this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq();
            this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = false;
         }

      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      class_269 v1 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_8428();
      if (this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy == null) {
         this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = v1.method_1189(class_8646.field_45157);
      }

      if (this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm == null) {
         Object v2 = v1.method_1170("gypsyy_scoreboard");
         if (v2 != null) {
            v1.method_1194(v2);
         }

         this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = v1.method_1168("gypsyy_scoreboard", class_274.field_1468, this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("  Protected by gypsyy  ", "#007CF9", "#00C6F9"), class_275.field_1472, true, (class_9022)null);
      }

      v1.method_1158(class_8646.field_45157, this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm);
      v1.method_1194(this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm);
      this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = v1.method_1168("gypsyy_scoreboard", class_274.field_1468, this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("  Protected by gypsyy  ", "#007CF9", "#00C6F9"), class_275.field_1472, true, (class_9022)null);
      v1.method_1158(class_8646.field_45157, this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm);
      Object v2 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp();

      for(int i3 = 0; i3 < v2.size(); ++i3) {
         class_2561 v4 = (class_2561)v2.get(i3);
         String v5 = "§" + i3 + "§r";
         class_9015 v6 = class_9015.method_55422(v5);
         class_9014 v7 = v1.method_1180(v6, this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm);
         v7.method_55410(v2.size() - i3);
         v7.method_55411(v4);
      }

      this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.method_1121(this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("  Protected by gypsyy  ", "#007CF9", "#00C6F9"));
   }

   private List<class_2561> invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp() {
      ArrayList v1 = new ArrayList();
      v1.add(class_2561.method_43470(" "));
      v1.add(class_2561.method_43470("").method_10852(class_2561.method_43470("$ ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(64512)).method_10982(true))).method_10852(class_2561.method_43470("Money ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215)))).method_10852(class_2561.method_43470("67M").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(64512)))));
      v1.add(class_2561.method_43470("").method_10852(class_2561.method_43470("★ ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(10683385)))).method_10852(class_2561.method_43470("Shards ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215)))).method_10852(class_2561.method_43470("67").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(10683385)))));
      v1.add(class_2561.method_43470("").method_10852(class_2561.method_43470("\ud83d\udde1 ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16515072)))).method_10852(class_2561.method_43470("Kills ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215)))).method_10852(class_2561.method_43470("67").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16515072)))));
      v1.add(class_2561.method_43470("").method_10852(class_2561.method_43470("☠ ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16348675)))).method_10852(class_2561.method_43470("Deaths ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215)))).method_10852(class_2561.method_43470("67").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16348675)))));
      v1.add(class_2561.method_43470("").method_10852(class_2561.method_43470("⌛ ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(42236)))).method_10852(class_2561.method_43470("Keyall ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215)))).method_10852(class_2561.method_43470("6m 7s").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(42236)))));
      v1.add(class_2561.method_43470("").method_10852(class_2561.method_43470("⌚ ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16573184)))).method_10852(class_2561.method_43470("Playtime ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215)))).method_10852(class_2561.method_43470("6h 7m").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16573184)))));
      v1.add(class_2561.method_43470("").method_10852(class_2561.method_43470("\ud83e\ude93 ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(42236)))).method_10852(class_2561.method_43470("Team ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215)))).method_10852(class_2561.method_43470("6 7 team ✌").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(42236)))));
      v1.add(class_2561.method_43470(" "));
      v1.add(class_2561.method_43470("").method_10852(class_2561.method_43470("Protected by gypsyy (").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(11053224)))).method_10852(class_2561.method_43470("67").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(42236)))).method_10852(class_2561.method_43470(")").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(11053224)))));
      return v1;
   }

   private void invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq() {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 != null) {
         class_269 v1 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_8428();
         if (this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm != null) {
            v1.method_1194(this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm);
            this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = null;
         }

         if (this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy != null) {
            v1.method_1158(class_8646.field_45157, this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy);
            this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = null;
         }

      }
   }

   private class_2561 invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(String this, String v1, String v2) {
      if (v1.isEmpty()) {
         return class_2561.method_43470("");
      } else {
         Color v4 = Color.decode(v2);
         Color v5 = Color.decode(v3);
         class_5250 v6 = class_2561.method_43470("");

         for(int i7 = 0; i7 < v1.length(); ++i7) {
            float f8 = v1.length() > 1 ? (float)i7 / (float)(v1.length() - 1) : 0.0F;
            Color v9 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v4, v5, f8);
            int i10 = v9.getRed() << 16 | v9.getGreen() << 8 | v9.getBlue();
            v6.method_10852(class_2561.method_43470(String.valueOf(v1.charAt(i7))).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(i10)).method_10982(true)));
         }

         return v6;
      }
   }

   private String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(String this, String v1) {
      Color v3 = Color.decode(v2);
      StringBuilder v4 = new StringBuilder();

      for(int i5 = 0; i5 < v1.length(); ++i5) {
         v4.append(this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v3));
         v4.append(v1.charAt(i5));
      }

      return v4.toString();
   }

   private String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Color this) {
      String v2 = String.format("%02x%02x%02x", v1.getRed(), v1.getGreen(), v1.getBlue());
      StringBuilder v3 = new StringBuilder("§x");
      char[] v4 = v2.toCharArray();
      int i5 = v4.length;

      for(int i6 = 0; i6 < i5; ++i6) {
         int i7 = v4[i6];
         v3.append("§").append(i7);
      }

      return v3.toString();
   }
}
