package dev.krispyy.module.modules.render;

import dev.krispyy.DonutBBC;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
import dev.krispyy.module.Category;
import dev.krispyy.module.Module;
import dev.krispyy.module.setting.BooleanSetting;
import dev.krispyy.module.setting.ModeSetting;
import dev.krispyy.module.setting.NumberSetting;
import dev.krispyy.module.setting.Setting;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.class_332;

public final class HUD extends Module {
   private static final CharSequence invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Gypsyy");
   private static final SimpleDateFormat invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = new SimpleDateFormat("HH:mm:ss");
   private final Map<Module, Float> invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = new HashMap();
   private float invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 0.0F;
   private long invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = System.currentTimeMillis();
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Watermark"), true);
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Info"), true);
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX = new BooleanSetting("Modules", true);
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg = new BooleanSetting("Time", true);
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn = new BooleanSetting("Coordinates", true);
   private final ModeSetting<HUD.HUDTheme> invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav;
   private final ModeSetting<HUD.ModuleListSorting> invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft;
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK;
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG;
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy;
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu;
   private final NumberSetting invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz;

   public HUD() {
      super(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("HUD"), dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Modern glassmorphic HUD"), -1, Category.RENDER);
      this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav = new ModeSetting("Theme", HUD.HUDTheme.MODERN_DARK, HUD.HUDTheme.class);
      this.invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft = new ModeSetting("Sort Mode", HUD.ModuleListSorting.LENGTH, HUD.ModuleListSorting.class);
      this.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK = new BooleanSetting("Blur Effect", true);
      this.invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG = new BooleanSetting("Glow", true);
      this.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy = new BooleanSetting("Animations", true);
      this.invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu = new BooleanSetting("Gradient", true);
      this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz = new NumberSetting("Corner Radius", 8.0D, 0.0D, 16.0D, 1.0D);
      this.addsettings(new Setting[]{this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW, this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh, this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX, this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg, this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn, this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav, this.invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft, this.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK, this.invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG, this.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy, this.invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu, this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz});
   }

   @invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq
   public void onRender2D(invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK this) {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1755 != DonutBBC.INSTANCE.GUI) {
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
         class_332 v2 = v1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
         int i3 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.method_22683().method_4480();
         int i4 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.method_22683().method_4507();
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm();
         HUD.HUDTheme v5 = (HUD.HUDTheme)this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.getValue();
         if (this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW.getValue()) {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v2, i3, v5);
         }

         if (this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getValue() && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v2, v5);
         }

         if (this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.getValue() && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
            this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(v2, i4, v5);
         }

         if (this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.getValue()) {
            this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(v2, i3, v5);
         }

         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy();
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      long j1 = System.currentTimeMillis();
      float f3 = Math.min((float)(j1 - this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku) / 16.67F, 3.0F);
      this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = j1;
      if (this.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy.getValue()) {
         this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = (float)((Math.sin((double)j1 / 500.0D) + 1.0D) / 2.0D);
         List v4 = DonutBBC.INSTANCE.getModuleManager().b();
         this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.keySet().removeIf((v1) -> {
            return !v4.contains(v1);
         });
         Iterator v5 = v4.iterator();

         while(v5.hasNext()) {
            Module v6 = (Module)v5.next();
            float f7 = (Float)this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getOrDefault(v6, 0.0F);
            this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.put(v6, Math.min(f7 + 0.08F * f3, 1.0F));
         }
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 this, int v1, HUD.HUDTheme i2) {
      String v4 = invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.toString();
      String v5 = invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.format(new Date());
      int i6 = 20;
      int i7 = 12;
      int i8 = (int)this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz.getValue();
      int i9 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v4);
      int i10 = 20;
      int i11 = i9 + i10 * 2;
      int i12 = i2 / 2 - i11 / 2;
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, i12, i6, i11, 32, v3, i8, true);
      if (this.invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu.getValue()) {
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, i12, i6, i11, 32, v3.accent, v3.secondary, i8);
      }

      Color v13 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v3.text, v3.accent, this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo * 0.3F);
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, v4, i12, i6, i11, 32, v13, true);
      if (this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg.getValue()) {
         int i14 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v5);
         int i15 = 16;
         int i16 = i14 + i15 * 2;
         int i17 = i2 / 2 - i16 / 2;
         int i18 = i6 + 32 + i7;
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, i17, i18, i16, 24, v3, i8, false);
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, v5, i17, i18, i16, 24, v3.subtext, false);
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 this, HUD.HUDTheme v1) {
      int i3 = 20;
      int i4 = 20;
      int i5 = 10;
      int i6 = (int)this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz.getValue();
      String[] v7 = new String[]{"FPS " + this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.method_47599(), "Gypsyy+"};

      for(int i8 = 0; i8 < v7.length; ++i8) {
         String v9 = v7[i8];
         int i10 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v9);
         int i11 = i10 + 24;
         int i12 = 28;
         int i13 = i4 + (i12 + i5) * i8;
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, i3, i13, i11, i12, v2, i6, false);
         Color v14 = i8 == 0 ? v2.accent : v2.primary;
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), v14, (double)(i3 + 4), (double)(i13 + 4), (double)(i3 + 6), (double)(i13 + i12 - 4), 1.0D, 1.0D);
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, v9, i3 + 10, i13, i11 - 10, i12, v2.text, false);
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_332 this, int v1, HUD.HUDTheme i2) {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
         int i4 = 20;
         int i5 = i2 - 60;
         int i6 = (int)this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz.getValue();
         String v7 = String.format("%.0f %.0f %.0f", this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23317(), this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23318(), this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23321());
         String v8 = this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq();
         String v9 = v8.isEmpty() ? this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp() : v8;
         int i10 = Math.max(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v7), dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v9));
         int i11 = i10 + 28;
         int i12 = 44;
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, i4, i5, i11, i12, v3, i6, false);
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), v3.accent, (double)(i4 + 8), (double)(i5 + 8), (double)(i4 + 12), (double)(i5 + 12), 2.0D, 2.0D);
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, v7, i4 + 18, i5 + 4, i11 - 18, 20, v3.text, false);
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, v9, i4 + 18, i5 + 24, i11 - 18, 20, v3.subtext, false);
      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(class_332 this, int v1, HUD.HUDTheme i2) {
      List v4 = this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm();
      if (!v4.isEmpty()) {
         int i5 = 20;
         int i6 = 20;
         int i7 = 8;
         int i8 = (int)this.invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz.getValue();

         for(int i9 = 0; i9 < v4.size(); ++i9) {
            Module v10 = (Module)v4.get(i9);
            String v11 = v10.getName().toString();
            float f12 = this.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy.getValue() ? (Float)this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getOrDefault(v10, 0.0F) : 1.0F;
            if (!(f12 < 0.01F)) {
               int i13 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v11);
               int i14 = 16;
               int i15 = (int)((float)(i13 + i14 * 2) * f12);
               int i16 = 26;
               int i17 = i2 - i15 - i6;
               this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, i17, i5, i15, i16, v3, i8, false);
               Color v18 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v3, i9);
               int i19 = (int)(3.0F * f12);
               dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), v18, (double)i17, (double)i5, (double)(i17 + i19), (double)(i5 + i16), (double)i8, 0.0D);
               Color v20 = new Color(v3.text.getRed(), v3.text.getGreen(), v3.text.getBlue(), (int)((float)v3.text.getAlpha() * f12));
               this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1, v11, i17, i5, i15, i16, v20, false);
               i5 += (int)((float)(i16 + i7) * f12);
            }
         }

      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 this, int v1, int i2, int i3, int i4, HUD.HUDTheme i5, int v6, boolean i7) {
      Color v9 = i8 ? v6.backgroundEmphasized : v6.background;
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), v9, (double)i2, (double)i3, (double)(i2 + i4), (double)(i3 + i5), (double)i7, (double)i7);
      Color v10;
      if (this.invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG.getValue()) {
         v10 = new Color(v6.accent.getRed(), v6.accent.getGreen(), v6.accent.getBlue(), i8 ? 40 : 20);
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), v10, (double)(i2 - 1), (double)(i3 - 1), (double)(i2 + i4 + 1), (double)(i3 + i5 + 1), (double)(i7 + 1), (double)(i7 + 1));
      }

      v10 = new Color(255, 255, 255, 15);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), v10, (double)(i2 + 2), (double)(i3 + 1), (double)(i2 + i4 - 2), (double)(i3 + 2), (double)i7, (double)i7);
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 this, int v1, int i2, int i3, int i4, Color i5, Color v6, int v7) {
      Color v9 = new Color(v6.getRed(), v6.getGreen(), v6.getBlue(), 30);
      new Color(v7.getRed(), v7.getGreen(), v7.getBlue(), 10);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1.method_51448(), v9, (double)i2, (double)i3, (double)(i2 + i4), (double)(i3 + i5 / 2), (double)i8, 0.0D);
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 this, String v1, int v2, int i3, int i4, int i5, Color i6, boolean v7) {
      int i9 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v2);
      int i10 = 10;
      int i11 = i3 + (i5 - i9) / 2;
      int i12 = i4 + (i6 - i10) / 2;
      if (this.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.getValue()) {
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v2, v1, i11 + 1, i12 + 1, (new Color(0, 0, 0, 60)).getRGB());
      }

      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v2, v1, i11, i12, v7.getRGB());
   }

   private String invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp() {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 == null) {
         return "";
      } else {
         String v1 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_27983().method_29177().method_12832();
         return v1.contains("nether") ? "Nether" : (v1.contains("end") ? "End" : "Overworld");
      }
   }

   private String invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq() {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 == null) {
         return "";
      } else {
         String v1 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_27983().method_29177().method_12832();
         if (v1.contains("nether")) {
            return String.format("OW %.0f %.0f", this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23317() * 8.0D, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23321() * 8.0D);
         } else {
            return v1.contains("overworld") ? String.format("Nether %.0f %.0f", this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23317() / 8.0D, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23321() / 8.0D) : "";
         }
      }
   }

   private Color invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(HUD.HUDTheme this, int v1) {
      Color[] v3 = new Color[]{v1.accent, v1.primary, v1.secondary};
      return v3[i2 % v3.length];
   }

   private Color invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Color this, Color v1, float v2) {
      f3 = Math.max(0.0F, Math.min(1.0F, f3));
      int i4 = (int)((float)v1.getRed() + (float)(v2.getRed() - v1.getRed()) * f3);
      int i5 = (int)((float)v1.getGreen() + (float)(v2.getGreen() - v1.getGreen()) * f3);
      int i6 = (int)((float)v1.getBlue() + (float)(v2.getBlue() - v1.getBlue()) * f3);
      int i7 = (int)((float)v1.getAlpha() + (float)(v2.getAlpha() - v1.getAlpha()) * f3);
      return new Color(i4, i5, i6, i7);
   }

   private List<Module> invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm() {
      List v1 = DonutBBC.INSTANCE.getModuleManager().b();
      HUD.ModuleListSorting v2 = (HUD.ModuleListSorting)this.invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft.getValue();
      List var10000;
      switch(v2.ordinal()) {
      case 0:
         var10000 = v1.stream().sorted((v0, v1x) -> {
            return Integer.compare(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v1x.getName()), dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(v0.getName()));
         }).toList();
         break;
      case 1:
         var10000 = v1.stream().sorted(Comparator.comparing((v0) -> {
            return v0.getName().toString();
         })).toList();
         break;
      case 2:
         var10000 = v1.stream().sorted(Comparator.comparing(Module::getCategory).thenComparing((v0) -> {
            return v0.getName().toString();
         })).toList();
         break;
      default:
         throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   static enum HUDTheme {
      MODERN_DARK("Modern Dark", new Color(20, 20, 25, 160), new Color(25, 25, 30, 180), new Color(240, 240, 245, 230), new Color(180, 180, 190, 200), new Color(88, 166, 255), new Color(138, 180, 248), new Color(168, 130, 255)),
      CYBER("Cyber", new Color(10, 15, 25, 160), new Color(15, 20, 30, 180), new Color(0, 255, 255, 240), new Color(180, 180, 200, 200), new Color(0, 255, 255), new Color(255, 0, 128), new Color(138, 43, 226)),
      MINIMAL("Minimal", new Color(30, 30, 32, 140), new Color(35, 35, 37, 160), new Color(255, 255, 255, 240), new Color(200, 200, 205, 200), new Color(120, 120, 128), new Color(140, 140, 148), new Color(160, 160, 168)),
      OCEAN("Ocean", new Color(15, 25, 35, 160), new Color(20, 30, 40, 180), new Color(220, 240, 255, 240), new Color(160, 180, 200, 200), new Color(64, 224, 208), new Color(72, 209, 204), new Color(32, 178, 170)),
      SUNSET("Sunset", new Color(30, 20, 25, 160), new Color(35, 25, 30, 180), new Color(255, 240, 230, 240), new Color(200, 180, 170, 200), new Color(255, 107, 107), new Color(255, 159, 64), new Color(255, 193, 7));

      public final String name;
      public final Color background;
      public final Color backgroundEmphasized;
      public final Color text;
      public final Color subtext;
      public final Color accent;
      public final Color primary;
      public final Color secondary;

      private HUDTheme(String var3, Color var4, Color var5, Color var6, Color var7, Color var8, Color var9, Color var10) {
         this.name = var3;
         this.background = var4;
         this.backgroundEmphasized = var5;
         this.text = var6;
         this.subtext = var7;
         this.accent = var8;
         this.primary = var9;
         this.secondary = var10;
      }

      public String toString() {
         return this.name;
      }

      // $FF: synthetic method
      private static HUD.HUDTheme[] invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
         return new HUD.HUDTheme[]{MODERN_DARK, CYBER, MINIMAL, OCEAN, SUNSET};
      }
   }

   static enum ModuleListSorting {
      LENGTH("Length"),
      ALPHABETICAL("Alphabetical"),
      CATEGORY("Category");

      private final String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;

      private ModuleListSorting(String var3) {
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = var3;
      }

      public String toString() {
         return this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
      }

      // $FF: synthetic method
      private static HUD.ModuleListSorting[] invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
         return new HUD.ModuleListSorting[]{LENGTH, ALPHABETICAL, CATEGORY};
      }
   }
}
