package dev.krispyy.module.modules.render;

import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
import dev.krispyy.module.Category;
import dev.krispyy.module.Module;
import dev.krispyy.module.setting.BooleanSetting;
import dev.krispyy.module.setting.ColorSetting;
import dev.krispyy.module.setting.NumberSetting;
import dev.krispyy.module.setting.Setting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ConcurrentHashMap.KeySetView;
import net.minecraft.class_1109;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2465;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_368;
import net.minecraft.class_374;
import net.minecraft.class_3986;
import net.minecraft.class_3989;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_7833;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_368.class_369;

public class ChunkFinder extends Module {
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = (new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Tracers"), true)).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Draw lines to flagged chunks"));
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = (new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Fill"), true)).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Fill chunk highlights"));
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = (new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Outline"), true)).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Draw chunk outlines"));
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = (new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("HighlightBlocks"), true)).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Highlight individual flagged blocks"));
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = (new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("BetterChunk"), true)).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Flag chunks with Wandering Traders or Trader Llamas"));
   private final ColorSetting invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = (new ColorSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("BetterChunkColor"), new Color(255, 165, 0, 120))).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Color for trader chunks"));
   private final NumberSetting invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = (new NumberSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("FillAlpha"), 0.0D, 255.0D, 120.0D, 5.0D)).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Transparency of filled chunk highlight"));
   private static final class_2960 invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX = class_2960.method_60655("minecraft", "textures/gui/toasts.png");
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg = (new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("HoleESP"), false)).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Enable hole detection and rendering"));
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn = (new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Detect1x1Holes"), true)).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Detect 1x1 holes"));
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav = (new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Detect3x1Holes"), true)).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Detect 3x1 holes"));
   private final NumberSetting invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft = (new NumberSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("MinHoleDepth"), 4.0D, 1.0D, 20.0D, 1.0D)).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Minimum depth for holes"));
   private final ColorSetting invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK = (new ColorSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("1x1HoleColor"), new Color(255, 255, 255, 100))).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Color for 1x1 holes"));
   private final ColorSetting invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG = (new ColorSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("3x1HoleColor"), new Color(255, 255, 255, 100))).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Color for 3x1 holes"));
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy = (new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("HoleOutline"), true)).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Draw hole outlines"));
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu = (new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("HoleFill"), true)).setDescription(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Fill holes"));
   private static final int invokeConnorftw_KRISPYYCLIENT_hhciMDtPtbyRuqfNZaFvfGxDesckcimuikBDrZZfaMrRwudrCefyReHRPLz = 8;
   private static final int invokeConnorftw_KRISPYYCLIENT_wrPWDxvgUovHGfcaKuroQEdTQaRrNlPeKromnydoEbmCL = 60;
   private static final int invokeConnorftw_KRISPYYCLIENT_avFlPzcXVFPfpYsCnkluLdXBQXniIsPgxwitwcsfrezoOzxLxrzeeog = 60;
   private static final boolean invokeConnorftw_KRISPYYCLIENT_KoQcacrsFXDUvaeYSUpxlHNTvxbojrxdn = true;
   private static final boolean invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi = false;
   private static final boolean invokeConnorftw_KRISPYYCLIENT_rmJDFppvXdYxPyprpilioqmyebbamOHxkrbhlzzgwmObbvjlabbgUAgMR = true;
   private final Set<class_1923> invokeConnorftw_KRISPYYCLIENT_PyrJMQRvJViwseVKxigfeEdjitrrOJgLObaomPdRWTm = ConcurrentHashMap.newKeySet();
   private final Set<class_1923> invokeConnorftw_KRISPYYCLIENT_bfzznteptasTrbjozkexnYqkWwqwqyMHBftc = ConcurrentHashMap.newKeySet();
   private final Set<class_1923> invokeConnorftw_KRISPYYCLIENT_xUcJMYtgoHIuOdnAxUvlqksvbmhmLDltyNsgdMhhzeNxzgz = ConcurrentHashMap.newKeySet();
   private final ConcurrentMap<class_1923, Set<class_2338>> invokeConnorftw_KRISPYYCLIENT_xZrhvVPvluscyEkHsxngLlULvdpXzPrEsWIpWjgfsuHolnwuip = new ConcurrentHashMap();
   private final Set<class_1923> invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun = ConcurrentHashMap.newKeySet();
   private final Set<class_1923> invokeConnorftw_KRISPYYCLIENT_slcehdGLvyoZNZqWHWcqoJXTexSXpQFXETbcNjfgzX = ConcurrentHashMap.newKeySet();
   private final Set<class_238> invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ = Collections.newSetFromMap(new ConcurrentHashMap());
   private final Set<class_238> invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci = Collections.newSetFromMap(new ConcurrentHashMap());
   private final Set<class_1923> invokeConnorftw_KRISPYYCLIENT_DFyEkJktprBYcudvrRDbaWgfTCshlNztFdcF = ConcurrentHashMap.newKeySet();
   private ExecutorService invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh;
   private Future<?> invokeConnorftw_KRISPYYCLIENT_JmwwaZOrxROdlYtuYqddbexxwBxnfBfeCmFlinhObpxsSKfkvnqoIi;
   private Future<?> invokeConnorftw_KRISPYYCLIENT_YFebixByxAvQvFhcmsYeMzSfqVZvUFFaWenvuEntxzjTXemwqBgJXKv;
   private Future<?> invokeConnorftw_KRISPYYCLIENT_kfXxPhovqrsaLtRreINueqCxUllXIClvDloupjHvxrwri;
   private volatile boolean invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO = false;
   private Set<Integer> invokeConnorftw_KRISPYYCLIENT_fCkiLjtgMyebdGnoXekPihcquvngklgpczjFPteuLaCl = new HashSet();
   private long invokeConnorftw_KRISPYYCLIENT_fdrohJwmcpVKUeQptJempmRGfzozpljeBlwhcDjKwoeqChkAEBhviE = 0L;
   private long invokeConnorftw_KRISPYYCLIENT_fepdAsztsnXThAfEjacdogrekeXqrIeKGaxRUsueAnqAvDZimfVBgeJzxk = 0L;
   private long invokeConnorftw_KRISPYYCLIENT_tdobsyRnbqPzKnnjeyktRvUGxiiSUnobeuMpxakqWbbrnYsHdlAf = 0L;
   private long invokeConnorftw_KRISPYYCLIENT_sElXxzzQMhqzccvbrIywaqRgzNzkkzZbozTngyubBHhOOvrcfkkJrl = 0L;
   private static final long invokeConnorftw_KRISPYYCLIENT_vgncboBntuisARngtNfQnrIoCswLBijLBYehffQ = 500L;
   private static final long invokeConnorftw_KRISPYYCLIENT_jcdhaqKXGWhXsnndpnzJzckukDubCWdtebEdrhqvmRpdpeqnKDPcmKatnl = 5000L;
   private static final long invokeConnorftw_KRISPYYCLIENT_bSbniydoRWCHyZRWrUAmbYylsgTfpbVfed = 1000L;
   private static final long invokeConnorftw_KRISPYYCLIENT_ycJjyuoXBiOhuzSkAktFLuuogyWATKhIxDZjXDSHCWXntzOatacglxNosL = 2000L;

   public ChunkFinder() {
      super(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("ChunkFinder"), dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Finds Sus Chunks, Holes, and Traders"), -1, Category.DONUT);
      this.addsettings(new Setting[]{this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq, this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm, this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy, this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo, this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku, this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW, this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg, this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn, this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav, this.invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft, this.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK, this.invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG, this.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy, this.invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu});
   }

   public void onEnable() {
      this.invokeConnorftw_KRISPYYCLIENT_PyrJMQRvJViwseVKxigfeEdjitrrOJgLObaomPdRWTm.clear();
      this.invokeConnorftw_KRISPYYCLIENT_bfzznteptasTrbjozkexnYqkWwqwqyMHBftc.clear();
      this.invokeConnorftw_KRISPYYCLIENT_xUcJMYtgoHIuOdnAxUvlqksvbmhmLDltyNsgdMhhzeNxzgz.clear();
      this.invokeConnorftw_KRISPYYCLIENT_xZrhvVPvluscyEkHsxngLlULvdpXzPrEsWIpWjgfsuHolnwuip.clear();
      this.invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun.clear();
      this.invokeConnorftw_KRISPYYCLIENT_slcehdGLvyoZNZqWHWcqoJXTexSXpQFXETbcNjfgzX.clear();
      this.invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ.clear();
      this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci.clear();
      this.invokeConnorftw_KRISPYYCLIENT_DFyEkJktprBYcudvrRDbaWgfTCshlNztFdcF.clear();
      this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO = false;
      this.invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh = Executors.newSingleThreadExecutor((var0) -> {
         Thread var1 = new Thread(var0, "ChunkScanner");
         var1.setDaemon(true);
         var1.setPriority(1);
         return var1;
      });
      this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm();
      if (this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg.getValue()) {
         this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy();
      }

      if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.getValue()) {
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
      }

      System.out.println("ChunkFinder: Starting chunk scanning...");
   }

   public void onDisable() {
      this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO = true;
      if (this.invokeConnorftw_KRISPYYCLIENT_JmwwaZOrxROdlYtuYqddbexxwBxnfBfeCmFlinhObpxsSKfkvnqoIi != null && !this.invokeConnorftw_KRISPYYCLIENT_JmwwaZOrxROdlYtuYqddbexxwBxnfBfeCmFlinhObpxsSKfkvnqoIi.isDone()) {
         this.invokeConnorftw_KRISPYYCLIENT_JmwwaZOrxROdlYtuYqddbexxwBxnfBfeCmFlinhObpxsSKfkvnqoIi.cancel(true);
      }

      if (this.invokeConnorftw_KRISPYYCLIENT_YFebixByxAvQvFhcmsYeMzSfqVZvUFFaWenvuEntxzjTXemwqBgJXKv != null && !this.invokeConnorftw_KRISPYYCLIENT_YFebixByxAvQvFhcmsYeMzSfqVZvUFFaWenvuEntxzjTXemwqBgJXKv.isDone()) {
         this.invokeConnorftw_KRISPYYCLIENT_YFebixByxAvQvFhcmsYeMzSfqVZvUFFaWenvuEntxzjTXemwqBgJXKv.cancel(true);
      }

      if (this.invokeConnorftw_KRISPYYCLIENT_kfXxPhovqrsaLtRreINueqCxUllXIClvDloupjHvxrwri != null && !this.invokeConnorftw_KRISPYYCLIENT_kfXxPhovqrsaLtRreINueqCxUllXIClvDloupjHvxrwri.isDone()) {
         this.invokeConnorftw_KRISPYYCLIENT_kfXxPhovqrsaLtRreINueqCxUllXIClvDloupjHvxrwri.cancel(true);
      }

      if (this.invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh != null && !this.invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh.isShutdown()) {
         this.invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh.shutdownNow();
      }

      this.invokeConnorftw_KRISPYYCLIENT_PyrJMQRvJViwseVKxigfeEdjitrrOJgLObaomPdRWTm.clear();
      this.invokeConnorftw_KRISPYYCLIENT_bfzznteptasTrbjozkexnYqkWwqwqyMHBftc.clear();
      this.invokeConnorftw_KRISPYYCLIENT_xUcJMYtgoHIuOdnAxUvlqksvbmhmLDltyNsgdMhhzeNxzgz.clear();
      this.invokeConnorftw_KRISPYYCLIENT_xZrhvVPvluscyEkHsxngLlULvdpXzPrEsWIpWjgfsuHolnwuip.clear();
      this.invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun.clear();
      this.invokeConnorftw_KRISPYYCLIENT_slcehdGLvyoZNZqWHWcqoJXTexSXpQFXETbcNjfgzX.clear();
      this.invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ.clear();
      this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci.clear();
      this.invokeConnorftw_KRISPYYCLIENT_DFyEkJktprBYcudvrRDbaWgfTCshlNztFdcF.clear();
      System.out.println("ChunkFinder: Chunk scanning stopped");
   }

   @invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq
   public void onTick(invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi var1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 != null && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
         long var2 = System.currentTimeMillis();
         if (var2 - this.invokeConnorftw_KRISPYYCLIENT_fdrohJwmcpVKUeQptJempmRGfzozpljeBlwhcDjKwoeqChkAEBhviE > 500L) {
            this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm();
            this.invokeConnorftw_KRISPYYCLIENT_fdrohJwmcpVKUeQptJempmRGfzozpljeBlwhcDjKwoeqChkAEBhviE = var2;
         }

         if (this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg.getValue() && var2 - this.invokeConnorftw_KRISPYYCLIENT_tdobsyRnbqPzKnnjeyktRvUGxiiSUnobeuMpxakqWbbrnYsHdlAf > 1000L) {
            this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy();
            this.invokeConnorftw_KRISPYYCLIENT_tdobsyRnbqPzKnnjeyktRvUGxiiSUnobeuMpxakqWbbrnYsHdlAf = var2;
         }

         if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.getValue() && var2 - this.invokeConnorftw_KRISPYYCLIENT_sElXxzzQMhqzccvbrIywaqRgzNzkkzZbozTngyubBHhOOvrcfkkJrl > 2000L) {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
            this.invokeConnorftw_KRISPYYCLIENT_sElXxzzQMhqzccvbrIywaqRgzNzkkzZbozTngyubBHhOOvrcfkkJrl = var2;
         }

         if (var2 - this.invokeConnorftw_KRISPYYCLIENT_fepdAsztsnXThAfEjacdogrekeXqrIeKGaxRUsueAnqAvDZimfVBgeJzxk > 5000L) {
            this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh();
            this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku();
            this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq();
            this.invokeConnorftw_KRISPYYCLIENT_fepdAsztsnXThAfEjacdogrekeXqrIeKGaxRUsueAnqAvDZimfVBgeJzxk = var2;
         }

      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      if (!this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO && this.invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh != null && !this.invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh.isShutdown()) {
         if (this.invokeConnorftw_KRISPYYCLIENT_kfXxPhovqrsaLtRreINueqCxUllXIClvDloupjHvxrwri != null && !this.invokeConnorftw_KRISPYYCLIENT_kfXxPhovqrsaLtRreINueqCxUllXIClvDloupjHvxrwri.isDone()) {
            this.invokeConnorftw_KRISPYYCLIENT_kfXxPhovqrsaLtRreINueqCxUllXIClvDloupjHvxrwri.cancel(false);
         }

         this.invokeConnorftw_KRISPYYCLIENT_kfXxPhovqrsaLtRreINueqCxUllXIClvDloupjHvxrwri = this.invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh.submit(this::invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp);
      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp() {
      if (!this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 != null && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
         try {
            int var1 = 0;
            Iterator var2 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_18112().iterator();

            label115:
            while(true) {
               class_1297 var3;
               class_1923 var5;
               do {
                  do {
                     if (!var2.hasNext()) {
                        HashSet var11 = new HashSet();
                        HashSet var12 = new HashSet();
                        Iterator var13 = this.invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun.iterator();

                        while(var13.hasNext()) {
                           var5 = (class_1923)var13.next();
                           if (!this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var5)) {
                              var11.add(var5);
                           }
                        }

                        var13 = this.invokeConnorftw_KRISPYYCLIENT_fCkiLjtgMyebdGnoXekPihcquvngklgpczjFPteuLaCl.iterator();

                        Integer var14;
                        while(var13.hasNext()) {
                           var14 = (Integer)var13.next();
                           boolean var15 = false;
                           Iterator var16 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_18112().iterator();

                           label87: {
                              class_1297 var8;
                              do {
                                 do {
                                    do {
                                       if (!var16.hasNext()) {
                                          break label87;
                                       }

                                       var8 = (class_1297)var16.next();
                                    } while(var8 == null);
                                 } while(var8.method_5628() != var14);
                              } while(!(var8 instanceof class_3989) && !(var8 instanceof class_3986));

                              var15 = true;
                           }

                           if (!var15) {
                              var12.add(var14);
                           }
                        }

                        var13 = var11.iterator();

                        while(var13.hasNext()) {
                           var5 = (class_1923)var13.next();
                           this.invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun.remove(var5);
                           this.invokeConnorftw_KRISPYYCLIENT_slcehdGLvyoZNZqWHWcqoJXTexSXpQFXETbcNjfgzX.remove(var5);
                        }

                        var13 = var12.iterator();

                        while(var13.hasNext()) {
                           var14 = (Integer)var13.next();
                           this.invokeConnorftw_KRISPYYCLIENT_fCkiLjtgMyebdGnoXekPihcquvngklgpczjFPteuLaCl.remove(var14);
                        }
                        break label115;
                     }

                     var3 = (class_1297)var2.next();
                  } while(this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO);
               } while(var3 == null);

               ++var1;
               if (var3 instanceof class_3989 || var3 instanceof class_3986) {
                  class_243 var4 = var3.method_19538();
                  var5 = new class_1923((int)Math.floor(var4.field_1352 / 16.0D), (int)Math.floor(var4.field_1350 / 16.0D));
                  int var6 = var3.method_5628();
                  boolean var7 = this.invokeConnorftw_KRISPYYCLIENT_fCkiLjtgMyebdGnoXekPihcquvngklgpczjFPteuLaCl.contains(var6);
                  this.invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun.contains(var5);
                  this.invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun.add(var5);
                  if (!var7) {
                     this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var5);
                     this.invokeConnorftw_KRISPYYCLIENT_fCkiLjtgMyebdGnoXekPihcquvngklgpczjFPteuLaCl.add(var6);
                     this.invokeConnorftw_KRISPYYCLIENT_slcehdGLvyoZNZqWHWcqoJXTexSXpQFXETbcNjfgzX.add(var5);
                  }
               }

               if (var1 > 0 && var1 % 100 == 0) {
                  Thread.sleep(5L);
               }
            }
         } catch (InterruptedException var9) {
            Thread.currentThread().interrupt();
         } catch (Exception var10) {
            System.err.println("Error in ChunkFinder trader scanning: " + var10.getMessage());
         }

      }
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_1923 var1) {
      if (!this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 != null) {
         try {
            int var2 = var1.field_9181 * 16;
            int var3 = var1.field_9180 * 16;
            int var4 = var2 + 16;
            int var5 = var3 + 16;
            Iterator var6 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_18112().iterator();

            class_1297 var7;
            int var10;
            do {
               do {
                  int var9;
                  do {
                     do {
                        do {
                           do {
                              if (!var6.hasNext()) {
                                 return false;
                              }

                              var7 = (class_1297)var6.next();
                           } while(var7 == null);

                           class_243 var8 = var7.method_19538();
                           var9 = (int)Math.floor(var8.field_1352);
                           var10 = (int)Math.floor(var8.field_1350);
                        } while(var9 < var2);
                     } while(var9 >= var4);
                  } while(var10 < var3);
               } while(var10 >= var5);
            } while(!(var7 instanceof class_3989) && !(var7 instanceof class_3986));

            return true;
         } catch (Exception var11) {
            return false;
         }
      } else {
         return false;
      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_1923 var1) {
      this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.execute(() -> {
         try {
            if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
               this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_5783(class_3417.field_26979, 1.0F, 1.0F);
            }

            int var2 = var1.field_9181 * 16 + 8;
            int var3 = var1.field_9180 * 16 + 8;
            ChunkFinder.ChunkFinderToast var4 = new ChunkFinder.ChunkFinderToast(String.valueOf(var2), String.valueOf(var3));
            this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.method_1566().method_1999(var4);
         } catch (Exception var5) {
         }

      });
   }

   private void invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq() {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
         int var1 = (Integer)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1690.method_42503().method_41753();
         int var2 = (int)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23317() / 16;
         int var3 = (int)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23321() / 16;
         this.invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun.removeIf((var3x) -> {
            int var4 = Math.abs(var3x.field_9181 - var2);
            int var5 = Math.abs(var3x.field_9180 - var3);
            return var4 > var1 || var5 > var1;
         });
         this.invokeConnorftw_KRISPYYCLIENT_slcehdGLvyoZNZqWHWcqoJXTexSXpQFXETbcNjfgzX.removeIf((var3x) -> {
            int var4 = Math.abs(var3x.field_9181 - var2);
            int var5 = Math.abs(var3x.field_9180 - var3);
            return var4 > var1 || var5 > var1;
         });
      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm() {
      if (!this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO && this.invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh != null && !this.invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh.isShutdown()) {
         if (this.invokeConnorftw_KRISPYYCLIENT_JmwwaZOrxROdlYtuYqddbexxwBxnfBfeCmFlinhObpxsSKfkvnqoIi != null && !this.invokeConnorftw_KRISPYYCLIENT_JmwwaZOrxROdlYtuYqddbexxwBxnfBfeCmFlinhObpxsSKfkvnqoIi.isDone()) {
            this.invokeConnorftw_KRISPYYCLIENT_JmwwaZOrxROdlYtuYqddbexxwBxnfBfeCmFlinhObpxsSKfkvnqoIi.cancel(false);
         }

         this.invokeConnorftw_KRISPYYCLIENT_JmwwaZOrxROdlYtuYqddbexxwBxnfBfeCmFlinhObpxsSKfkvnqoIi = this.invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh.submit(this::invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW);
      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy() {
      if (!this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO && this.invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh != null && !this.invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh.isShutdown()) {
         if (this.invokeConnorftw_KRISPYYCLIENT_YFebixByxAvQvFhcmsYeMzSfqVZvUFFaWenvuEntxzjTXemwqBgJXKv != null && !this.invokeConnorftw_KRISPYYCLIENT_YFebixByxAvQvFhcmsYeMzSfqVZvUFFaWenvuEntxzjTXemwqBgJXKv.isDone()) {
            this.invokeConnorftw_KRISPYYCLIENT_YFebixByxAvQvFhcmsYeMzSfqVZvUFFaWenvuEntxzjTXemwqBgJXKv.cancel(false);
         }

         this.invokeConnorftw_KRISPYYCLIENT_YFebixByxAvQvFhcmsYeMzSfqVZvUFFaWenvuEntxzjTXemwqBgJXKv = this.invokeConnorftw_KRISPYYCLIENT_wvTPJxTKmrkOyTvzbIbniygJkjCHeReh.submit(this::invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo);
      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo() {
      if (!this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 != null && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
         try {
            List var1 = this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX();
            Iterator var2 = var1.iterator();

            while(var2.hasNext()) {
               class_2818 var3 = (class_2818)var2.next();
               if (!this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO && var3 != null && !var3.method_12223()) {
                  class_1923 var4 = var3.method_12004();
                  if (!this.invokeConnorftw_KRISPYYCLIENT_DFyEkJktprBYcudvrRDbaWgfTCshlNztFdcF.contains(var4)) {
                     this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var3);
                     this.invokeConnorftw_KRISPYYCLIENT_DFyEkJktprBYcudvrRDbaWgfTCshlNztFdcF.add(var4);
                     Thread.sleep(10L);
                  }
               }
            }
         } catch (InterruptedException var5) {
            Thread.currentThread().interrupt();
         } catch (Exception var6) {
            System.err.println("Error in ChunkFinder hole scanning: " + var6.getMessage());
         }

      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_2818 var1) {
      if (!this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO && var1 != null && !var1.method_12223()) {
         class_1923 var2 = var1.method_12004();
         int var3 = var2.method_8326();
         int var4 = var2.method_8328();
         int var5 = Math.max(var1.method_31607(), 8);
         int var6 = Math.min(var1.method_31607() + var1.method_31605(), 60);

         for(int var7 = var3; var7 < var3 + 16; ++var7) {
            for(int var8 = var4; var8 < var4 + 16; ++var8) {
               for(int var9 = var5; var9 < var6; ++var9) {
                  if (this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO) {
                     return;
                  }

                  class_2338 var10 = new class_2338(var7, var9, var8);

                  try {
                     if (this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.getValue()) {
                        this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var10);
                     }

                     if (this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.getValue()) {
                        this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var10);
                     }
                  } catch (Exception var12) {
                  }
               }
            }
         }

      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_2338 var1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(var1)) {
         class_2339 var2 = var1.method_25503();

         while(this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq((class_2338)var2)) {
            var2.method_10098(class_2350.field_11036);
         }

         if ((double)(var2.method_10264() - var1.method_10264()) >= this.invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft.getValue()) {
            class_238 var3 = new class_238((double)var1.method_10263(), (double)var1.method_10264(), (double)var1.method_10260(), (double)(var1.method_10263() + 1), (double)var2.method_10264(), (double)(var1.method_10260() + 1));
            if (!this.invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ.contains(var3) && this.invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ.stream().noneMatch((var1x) -> {
               return var1x.method_994(var3);
            })) {
               this.invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ.add(var3);
            }
         }
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_2338 var1) {
      class_2339 var2;
      class_238 var3;
      if (this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm(var1)) {
         var2 = var1.method_25503();

         while(this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm((class_2338)var2)) {
            var2.method_10098(class_2350.field_11036);
         }

         if ((double)(var2.method_10264() - var1.method_10264()) >= this.invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft.getValue()) {
            var3 = new class_238((double)var1.method_10263(), (double)var1.method_10264(), (double)var1.method_10260(), (double)(var1.method_10263() + 3), (double)var2.method_10264(), (double)(var1.method_10260() + 1));
            if (!this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci.contains(var3) && this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci.stream().noneMatch((var1x) -> {
               return var1x.method_994(var3);
            })) {
               this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci.add(var3);
            }
         }
      }

      if (this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy(var1)) {
         var2 = var1.method_25503();

         while(this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy((class_2338)var2)) {
            var2.method_10098(class_2350.field_11036);
         }

         if ((double)(var2.method_10264() - var1.method_10264()) >= this.invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft.getValue()) {
            var3 = new class_238((double)var1.method_10263(), (double)var1.method_10264(), (double)var1.method_10260(), (double)(var1.method_10263() + 1), (double)var2.method_10264(), (double)(var1.method_10260() + 3));
            if (!this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci.contains(var3) && this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci.stream().noneMatch((var1x) -> {
               return var1x.method_994(var3);
            })) {
               this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci.add(var3);
            }
         }
      }

   }

   private boolean invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(class_2338 var1) {
      return this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10095()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10072()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10078()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10067());
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm(class_2338 var1) {
      return this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1) && this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10078()) && this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10089(2)) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10095()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10072()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10089(3)) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10067()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10078().method_10095()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10078().method_10072()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10089(2).method_10095()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10089(2).method_10072());
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy(class_2338 var1) {
      return this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1) && this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10072()) && this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10077(2)) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10078()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10067()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10077(3)) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10095()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10072().method_10078()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10072().method_10067()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10077(2).method_10078()) && !this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(var1.method_10077(2).method_10067());
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(class_2338 var1) {
      return this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 == null ? false : this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_8320(var1).method_26215();
   }

   private void invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku() {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
         int var1 = (Integer)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1690.method_42503().method_41753();
         int var2 = (int)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23317() / 16;
         int var3 = (int)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23321() / 16;
         this.invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ.removeIf((var3x) -> {
            int var4 = (int)Math.floor(var3x.method_1005().method_10216()) / 16;
            int var5 = (int)Math.floor(var3x.method_1005().method_10215()) / 16;
            int var6 = Math.abs(var4 - var2);
            int var7 = Math.abs(var5 - var3);
            return var6 > var1 || var7 > var1;
         });
         this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci.removeIf((var3x) -> {
            int var4 = (int)Math.floor(var3x.method_1005().method_10216()) / 16;
            int var5 = (int)Math.floor(var3x.method_1005().method_10215()) / 16;
            int var6 = Math.abs(var4 - var2);
            int var7 = Math.abs(var5 - var3);
            return var6 > var1 || var7 > var1;
         });
         this.invokeConnorftw_KRISPYYCLIENT_DFyEkJktprBYcudvrRDbaWgfTCshlNztFdcF.removeIf((var3x) -> {
            int var4 = Math.abs(var3x.field_9181 - var2);
            int var5 = Math.abs(var3x.field_9180 - var3);
            return var4 > var1 || var5 > var1;
         });
      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW() {
      if (!this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 != null && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
         try {
            List var1 = this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX();
            Iterator var2 = var1.iterator();

            while(var2.hasNext()) {
               class_2818 var3 = (class_2818)var2.next();
               if (!this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO && var3 != null && !var3.method_12223()) {
                  class_1923 var4 = var3.method_12004();
                  if (!this.invokeConnorftw_KRISPYYCLIENT_bfzznteptasTrbjozkexnYqkWwqwqyMHBftc.contains(var4)) {
                     boolean var5 = this.invokeConnorftw_KRISPYYCLIENT_PyrJMQRvJViwseVKxigfeEdjitrrOJgLObaomPdRWTm.contains(var4);
                     Set var6 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var3);
                     boolean var7 = !var6.isEmpty();
                     if (var7) {
                        this.invokeConnorftw_KRISPYYCLIENT_PyrJMQRvJViwseVKxigfeEdjitrrOJgLObaomPdRWTm.add(var4);
                        this.invokeConnorftw_KRISPYYCLIENT_xZrhvVPvluscyEkHsxngLlULvdpXzPrEsWIpWjgfsuHolnwuip.put(var4, var6);
                        if (!var5 && !this.invokeConnorftw_KRISPYYCLIENT_xUcJMYtgoHIuOdnAxUvlqksvbmhmLDltyNsgdMhhzeNxzgz.contains(var4)) {
                           this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(var4);
                           this.invokeConnorftw_KRISPYYCLIENT_xUcJMYtgoHIuOdnAxUvlqksvbmhmLDltyNsgdMhhzeNxzgz.add(var4);
                        }
                     } else {
                        this.invokeConnorftw_KRISPYYCLIENT_PyrJMQRvJViwseVKxigfeEdjitrrOJgLObaomPdRWTm.remove(var4);
                        this.invokeConnorftw_KRISPYYCLIENT_xUcJMYtgoHIuOdnAxUvlqksvbmhmLDltyNsgdMhhzeNxzgz.remove(var4);
                        this.invokeConnorftw_KRISPYYCLIENT_xZrhvVPvluscyEkHsxngLlULvdpXzPrEsWIpWjgfsuHolnwuip.remove(var4);
                     }

                     this.invokeConnorftw_KRISPYYCLIENT_bfzznteptasTrbjozkexnYqkWwqwqyMHBftc.add(var4);
                     Thread.sleep(5L);
                  }
               }
            }
         } catch (InterruptedException var8) {
            Thread.currentThread().interrupt();
         } catch (Exception var9) {
            System.err.println("Error in ChunkFinder background scanning: " + var9.getMessage());
         }

      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(class_1923 var1) {
      this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.execute(() -> {
         try {
            if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
               this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_5783(class_3417.field_26979, 1.0F, 1.0F);
            }

            int var2 = var1.field_9181 * 16 + 8;
            int var3 = var1.field_9180 * 16 + 8;
            ChunkFinder.ChunkFinderToast var4 = new ChunkFinder.ChunkFinderToast(String.valueOf(var2), String.valueOf(var3));
            this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.method_1566().method_1999(var4);
         } catch (Exception var5) {
         }

      });
   }

   private Set<class_2338> invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_2818 var1) {
      KeySetView var2 = ConcurrentHashMap.newKeySet();
      if (!this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO && var1 != null && !var1.method_12223()) {
         class_1923 var3 = var1.method_12004();
         int var4 = var3.method_8326();
         int var5 = var3.method_8328();
         int var6 = Math.max(var1.method_31607(), 8);
         int var7 = Math.min(var1.method_31607() + var1.method_31605(), 60);

         int var8;
         int var9;
         int var10;
         for(var8 = var4; var8 < var4 + 16; ++var8) {
            for(var9 = var5; var9 < var5 + 16; ++var9) {
               for(var10 = var6; var10 < var7; ++var10) {
                  if (this.invokeConnorftw_KRISPYYCLIENT_QkisPQkGYUlQuEcanMfMZbOqQnovQkFqTpdoAwpjZnfbehuCDblcsWsxqeO) {
                     return var2;
                  }

                  class_2338 var11 = new class_2338(var8, var10, var9);

                  try {
                     class_2680 var12 = var1.method_8320(var11);
                     class_2248 var13 = var12.method_26204();
                     if ((var13 == class_2246.field_27165 || var13 == class_2246.field_28888) && var10 > 8 && var10 < 60 && this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var11) && this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku(var11)) {
                        var2.add(var11);
                     }

                     if (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var12) && var10 >= 8 && var10 <= 60 && this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var11) && this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku(var11)) {
                        var2.add(var11);
                     }

                     if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var12) && this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var11) && this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku(var11)) {
                        var2.add(var11);
                     }
                  } catch (Exception var20) {
                  }
               }
            }
         }

         for(var8 = var4; var8 < var4 + 16; ++var8) {
            for(var9 = var5; var9 < var5 + 16; ++var9) {
               var10 = 0;
               class_2248 var21 = null;
               ArrayList var22 = new ArrayList();

               for(int var23 = var6; var23 <= var7; ++var23) {
                  class_2338 var14 = new class_2338(var8, var23, var9);
                  class_2680 var15 = var1.method_8320(var14);
                  class_2248 var16 = var15.method_26204();
                  if (!this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var16)) {
                     var10 = 0;
                     var21 = null;
                     var22.clear();
                  } else {
                     if (var21 != null && var16 != var21) {
                        var10 = 1;
                        var21 = var16;
                        var22.clear();
                        var22.add(var14);
                     } else {
                        ++var10;
                        var21 = var16;
                        var22.add(var14);
                     }

                     if (var10 >= 25 && this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var8, var9, var23 - var10 + 1, var23, var21)) {
                        ArrayList var17 = new ArrayList();
                        Iterator var18 = var22.iterator();

                        while(var18.hasNext()) {
                           class_2338 var19 = (class_2338)var18.next();
                           if (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var19) && this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku(var19)) {
                              var17.add(var19);
                           }
                        }

                        var2.addAll(var17);
                     }
                  }
               }
            }
         }

         return var2;
      } else {
         return var2;
      }
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_2248 var1) {
      return var1 == class_2246.field_10474 || var1 == class_2246.field_10115 || var1 == class_2246.field_10566 || var1 == class_2246.field_10508;
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_2818 var1, int var2, int var3, int var4, int var5, class_2248 var6) {
      for(int var7 = var4; var7 <= var5; ++var7) {
         class_2338 var8 = new class_2338(var2, var7, var3);
         if (!var1.method_8320(var8).method_27852(var6)) {
            return false;
         }

         class_2350[] var9 = class_2350.values();
         int var10 = var9.length;

         for(int var11 = 0; var11 < var10; ++var11) {
            class_2350 var12 = var9[var11];
            class_2338 var13 = var8.method_10093(var12);
            class_2680 var14 = var1.method_8320(var13);
            if (var14.method_26215() || !var14.method_26212(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687, var13)) {
               return false;
            }
         }
      }

      return true;
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku(class_2338 var1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 == null) {
         return false;
      } else {
         int var2 = Math.min(var1.method_10264() + 50, 80);
         int var3 = 0;

         for(int var4 = var1.method_10264() + 1; var4 <= var2; ++var4) {
            class_2338 var5 = new class_2338(var1.method_10263(), var4, var1.method_10260());
            class_2680 var6 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_8320(var5);
            if (!var6.method_26215() && var6.method_26212(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687, var5)) {
               ++var3;
            }
         }

         return var3 >= 3;
      }
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_2680 var1) {
      if (var1 != null && !var1.method_26215()) {
         class_2248 var2 = var1.method_26204();
         if (var2 == class_2246.field_28888) {
            return !this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var1);
         } else {
            return var2 == class_2246.field_27165;
         }
      } else {
         return false;
      }
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_2680 var1) {
      if (var1 != null && !var1.method_26215()) {
         class_2248 var2 = var1.method_26204();
         if (var2 == class_2246.field_28888 && var1.method_28498(class_2465.field_11459)) {
            class_2351 var3 = (class_2351)var1.method_11654(class_2465.field_11459);
            return var3 == class_2351.field_11048 || var3 == class_2351.field_11051;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_2818 var1, class_2338 var2) {
      class_2350[] var3 = new class_2350[]{class_2350.field_11036, class_2350.field_11033, class_2350.field_11043, class_2350.field_11035, class_2350.field_11034, class_2350.field_11039};
      class_2350[] var4 = var3;
      int var5 = var3.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         class_2350 var7 = var4[var6];
         class_2338 var8 = var2.method_10093(var7);

         try {
            class_2680 var9 = null;
            if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 != null) {
               var9 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_8320(var8);
               if (!var9.method_26215() && !this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(var9)) {
                  if (var9.method_26212(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687, var8)) {
                     continue;
                  }

                  return false;
               }

               return false;
            }

            return false;
         } catch (Exception var10) {
            return false;
         }
      }

      return true;
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(class_2680 var1) {
      class_2248 var2 = var1.method_26204();
      if (var2 != class_2246.field_10033 && var2 != class_2246.field_10382 && var2 != class_2246.field_10164 && var2 != class_2246.field_10295 && var2 != class_2246.field_10225 && var2 != class_2246.field_10384) {
         if (var2 != class_2246.field_10087 && var2 != class_2246.field_10227 && var2 != class_2246.field_10574 && var2 != class_2246.field_10271 && var2 != class_2246.field_10049 && var2 != class_2246.field_10157 && var2 != class_2246.field_10317 && var2 != class_2246.field_10555 && var2 != class_2246.field_9996 && var2 != class_2246.field_10248 && var2 != class_2246.field_10399 && var2 != class_2246.field_10060 && var2 != class_2246.field_10073 && var2 != class_2246.field_10357 && var2 != class_2246.field_10272 && var2 != class_2246.field_9997 && var2 != class_2246.field_27115) {
            return var2 == class_2246.field_10503 || var2 == class_2246.field_9988 || var2 == class_2246.field_10539 || var2 == class_2246.field_10335 || var2 == class_2246.field_10098 || var2 == class_2246.field_10035 || var2 == class_2246.field_37551 || var2 == class_2246.field_42731;
         } else {
            return true;
         }
      } else {
         return true;
      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh() {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
         int var1 = (Integer)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1690.method_42503().method_41753();
         int var2 = (int)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23317() / 16;
         int var3 = (int)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23321() / 16;
         this.invokeConnorftw_KRISPYYCLIENT_PyrJMQRvJViwseVKxigfeEdjitrrOJgLObaomPdRWTm.removeIf((var4) -> {
            int var5 = Math.abs(var4.field_9181 - var2);
            int var6 = Math.abs(var4.field_9180 - var3);
            boolean var7 = var5 > var1 || var6 > var1;
            if (var7) {
               this.invokeConnorftw_KRISPYYCLIENT_xZrhvVPvluscyEkHsxngLlULvdpXzPrEsWIpWjgfsuHolnwuip.remove(var4);
            }

            return var7;
         });
         this.invokeConnorftw_KRISPYYCLIENT_bfzznteptasTrbjozkexnYqkWwqwqyMHBftc.removeIf((var3x) -> {
            int var4 = Math.abs(var3x.field_9181 - var2);
            int var5 = Math.abs(var3x.field_9180 - var3);
            return var4 > var1 || var5 > var1;
         });
         this.invokeConnorftw_KRISPYYCLIENT_xUcJMYtgoHIuOdnAxUvlqksvbmhmLDltyNsgdMhhzeNxzgz.removeIf((var3x) -> {
            int var4 = Math.abs(var3x.field_9181 - var2);
            int var5 = Math.abs(var3x.field_9180 - var3);
            return var4 > var1 || var5 > var1;
         });
      }
   }

   @invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq
   public void onRender3D(invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG var1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 != null) {
         if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.method_47599() < 8 && this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_6012 > 100) {
            this.toggle(false);
            System.out.println("ChunkFinder: Disabled due to low FPS");
         } else {
            class_4184 var2 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp();
            if (var2 != null) {
               class_243 var3 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
               class_4587 var4 = var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
               var4.method_22903();
               var4.method_22907(class_7833.field_40714.rotationDegrees(var2.method_19329()));
               var4.method_22907(class_7833.field_40716.rotationDegrees(var2.method_19330() + 180.0F));
               var4.method_22904(-var3.field_1352, -var3.field_1351, -var3.field_1350);
            }

            int var5;
            Iterator var7;
            class_1923 var8;
            if (!this.invokeConnorftw_KRISPYYCLIENT_PyrJMQRvJViwseVKxigfeEdjitrrOJgLObaomPdRWTm.isEmpty()) {
               var7 = this.invokeConnorftw_KRISPYYCLIENT_PyrJMQRvJViwseVKxigfeEdjitrrOJgLObaomPdRWTm.iterator();

               while(var7.hasNext()) {
                  var8 = (class_1923)var7.next();
                  var5 = (int)this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getValue();
                  this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, var8, new Color(0, 255, 0, var5));
                  if (this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.getValue()) {
                     this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, var8);
                  }
               }
            }

            if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.getValue() && !this.invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun.isEmpty()) {
               var7 = this.invokeConnorftw_KRISPYYCLIENT_sCugQJnihqksmSrgYjkUoMdzgiLiMClYsGWjOcktjDSaOun.iterator();

               while(var7.hasNext()) {
                  var8 = (class_1923)var7.next();
                  var5 = (int)this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getValue();
                  Color var6 = this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW.getValue();
                  this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, var8, new Color(var6.getRed(), var6.getGreen(), var6.getBlue(), var5));
               }
            }

            if (this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg.getValue()) {
               if (this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn.getValue() && !this.invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ.isEmpty()) {
                  this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw);
               }

               if (this.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.getValue() && !this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci.isEmpty()) {
                  this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw);
               }
            }

            var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.method_22909();
         }
      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_4587 var1) {
      Color var2 = this.invokeConnorftw_KRISPYYCLIENT_irywcDebfYIkkenogPloUewmodMbfbdJpiyXPiughK.getValue();
      Iterator var3 = this.invokeConnorftw_KRISPYYCLIENT_ufcBNtKuIEjIvVqwfFAcvCEYieQuoczRySssuVqguJ.iterator();

      while(var3.hasNext()) {
         class_238 var4 = (class_238)var3.next();
         if (this.invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu.getValue()) {
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, (float)var4.field_1323, (float)var4.field_1322, (float)var4.field_1321, (float)var4.field_1320, (float)var4.field_1325, (float)var4.field_1324, var2);
         }

         if (this.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy.getValue()) {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, (float)var4.field_1323, (float)var4.field_1322, (float)var4.field_1321, (float)var4.field_1320, (float)var4.field_1325, (float)var4.field_1324, new Color(var2.getRed(), var2.getGreen(), var2.getBlue(), 255));
         }
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_4587 var1) {
      Color var2 = this.invokeConnorftw_KRISPYYCLIENT_qkNljxswGoDEZDBBLrWzOrxBGoUPakG.getValue();
      Iterator var3 = this.invokeConnorftw_KRISPYYCLIENT_wtzHkAvcOQcIWYrMydvlbgThideNhufci.iterator();

      while(var3.hasNext()) {
         class_238 var4 = (class_238)var3.next();
         if (this.invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu.getValue()) {
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, (float)var4.field_1323, (float)var4.field_1322, (float)var4.field_1321, (float)var4.field_1320, (float)var4.field_1325, (float)var4.field_1324, var2);
         }

         if (this.invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy.getValue()) {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, (float)var4.field_1323, (float)var4.field_1322, (float)var4.field_1321, (float)var4.field_1320, (float)var4.field_1325, (float)var4.field_1324, new Color(var2.getRed(), var2.getGreen(), var2.getBlue(), 255));
         }
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_4587 var1, class_1923 var2, Color var3) {
      int var4 = var2.field_9181 * 16;
      int var5 = var2.field_9180 * 16;
      int var6 = var4 + 16;
      int var7 = var5 + 16;
      double var8 = 60.0D;
      double var10 = 0.10000000149011612D;
      class_238 var12 = new class_238((double)var4, var8, (double)var5, (double)var6, var8 + var10, (double)var7);
      if (this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getValue()) {
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, (float)var12.field_1323, (float)var12.field_1322, (float)var12.field_1321, (float)var12.field_1320, (float)var12.field_1325, (float)var12.field_1324, var3);
      }

      if (this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getValue()) {
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, (float)var12.field_1323, (float)var12.field_1322, (float)var12.field_1321, (float)var12.field_1320, (float)var12.field_1325, (float)var12.field_1324, var3);
      }

      if (this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.getValue()) {
         class_243 var13 = (new class_243(0.0D, 0.0D, 75.0D)).method_1037(-((float)Math.toRadians((double)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1773.method_19418().method_19329()))).method_1024(-((float)Math.toRadians((double)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1773.method_19418().method_19330()))).method_1019(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1719.method_33571());
         class_243 var14 = new class_243((double)(var4 + 8), var8 + var10 / 2.0D, (double)(var5 + 8));
         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var3, var13, var14);
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_4587 var1, class_1923 var2) {
      Set var3 = (Set)this.invokeConnorftw_KRISPYYCLIENT_xZrhvVPvluscyEkHsxngLlULvdpXzPrEsWIpWjgfsuHolnwuip.get(var2);
      if (var3 != null && !var3.isEmpty()) {
         Color var4 = new Color(255, 0, 0, 120);
         Iterator var5 = var3.iterator();

         while(var5.hasNext()) {
            class_2338 var6 = (class_2338)var5.next();
            class_238 var7 = new class_238(var6);
            dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, (float)var7.field_1323, (float)var7.field_1322, (float)var7.field_1321, (float)var7.field_1320, (float)var7.field_1325, (float)var7.field_1324, new Color(var4.getRed(), var4.getGreen(), var4.getBlue(), Math.max(40, var4.getAlpha())));
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, (float)var7.field_1323, (float)var7.field_1322, (float)var7.field_1321, (float)var7.field_1320, (float)var7.field_1325, (float)var7.field_1324, new Color(var4.getRed(), var4.getGreen(), var4.getBlue(), 200));
         }

      }
   }

   private List<class_2818> invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX() {
      ArrayList var1 = new ArrayList();
      int var2 = (Integer)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1690.method_42503().method_41753();

      for(int var3 = -var2; var3 <= var2; ++var3) {
         for(int var4 = -var2; var4 <= var2; ++var4) {
            class_2818 var5 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_2935().method_21730((int)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23317() / 16 + var3, (int)this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_23321() / 16 + var4);
            if (var5 != null) {
               var1.add(var5);
            }
         }
      }

      return var1;
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_4587 var1, float var2, float var3, float var4, float var5, float var6, float var7, Color var8) {
      class_243[] var9 = new class_243[]{new class_243((double)var2, (double)var3, (double)var4), new class_243((double)var5, (double)var3, (double)var4), new class_243((double)var5, (double)var3, (double)var7), new class_243((double)var2, (double)var3, (double)var7), new class_243((double)var2, (double)var6, (double)var4), new class_243((double)var5, (double)var6, (double)var4), new class_243((double)var5, (double)var6, (double)var7), new class_243((double)var2, (double)var6, (double)var7)};
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var8, var9[0], var9[1]);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var8, var9[1], var9[2]);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var8, var9[2], var9[3]);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var8, var9[3], var9[0]);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var8, var9[4], var9[5]);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var8, var9[5], var9[6]);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var8, var9[6], var9[7]);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var8, var9[7], var9[4]);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var8, var9[0], var9[4]);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var8, var9[1], var9[5]);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var8, var9[2], var9[6]);
      dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var8, var9[3], var9[7]);
   }

   public static class ChunkFinderToast implements class_368 {
      private final String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
      private final String invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
      private long invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
      private boolean invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = false;
      private static final long invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = 3000L;

      public ChunkFinderToast(String var1, String var2) {
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = var1;
         this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = var2;
      }

      public class_369 method_1986(class_332 var1, class_374 var2, long var3) {
         if (this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq == 0L) {
            this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = var3;
         }

         if (!this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm) {
            var2.method_1995().method_1483().method_4873(class_1109.method_4757(class_3417.field_26979, 1.0F, 1.0F));
            this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = true;
         }

         var1.method_25302(ChunkFinder.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX, 0, 0, 0, 0, this.method_29049(), this.method_29050());
         var1.method_51445(new class_1799(class_1802.field_8106), 6, 6);
         class_5250 var5 = class_2561.method_43470("ChunkFinder");
         var1.method_51439(var2.method_1995().field_1772, var5, 30, 7, 10040012, false);
         String var10000 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
         class_5250 var6 = class_2561.method_43470("X=" + var10000 + " Z=" + this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp);
         var1.method_51439(var2.method_1995().field_1772, var6, 30, 18, 16777215, false);
         return var3 - this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq < 3000L ? class_369.field_2210 : class_369.field_2209;
      }

      public Object method_1987() {
         return ChunkFinder.ChunkFinderToast.Type.INSTANCE;
      }

      public int method_29049() {
         return 160;
      }

      public int method_29050() {
         return 32;
      }

      public static class Type {
         public static final ChunkFinder.ChunkFinderToast.Type INSTANCE = new ChunkFinder.ChunkFinderToast.Type();
      }
   }
}
