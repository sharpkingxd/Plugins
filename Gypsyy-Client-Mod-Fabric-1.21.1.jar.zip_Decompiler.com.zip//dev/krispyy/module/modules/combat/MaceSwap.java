package dev.krispyy.module.modules.combat;

import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
import dev.krispyy.module.Category;
import dev.krispyy.module.Module;
import dev.krispyy.module.setting.BooleanSetting;
import dev.krispyy.module.setting.NumberSetting;
import dev.krispyy.module.setting.Setting;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1829;
import net.minecraft.class_1893;

public final class MaceSwap extends Module {
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Wind Burst"), true);
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Breach"), true);
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Only Sword"), false);
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Only Axe"), false);
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Switch Back"), true);
   private final NumberSetting invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = new NumberSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Switch Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
   private final BooleanSetting invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = new BooleanSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Debug"), false);
   private boolean invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX;
   private int invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg;
   private int invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn;

   public MaceSwap() {
      super(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Mace Swap"), dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Switches to a mace when attacking."), -1, Category.COMBAT);
      this.addsettings(new Setting[]{this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq, this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm, this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy, this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo, this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku, this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW, this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh});
   }

   public void onEnable() {
      this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq();
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq
   public void onTick(invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi var1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1755 == null) {
         if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
            if (this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX) {
               if (this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.getValue()) {
                  this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp();
               } else {
                  this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq();
               }
            }

         }
      }
   }

   @invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq
   public void onAttack(invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp var1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
         if (this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getValue()) {
            System.out.println("[MaceSwap] Attack event triggered");
         }

         if (!this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw()) {
            if (this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getValue()) {
               System.out.println("[MaceSwap] Invalid weapon - not a sword or axe");
            }

         } else {
            if (this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg == -1) {
               this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_31548().field_7545;
               if (this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getValue()) {
                  System.out.println("[MaceSwap] Stored previous slot: " + this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg);
               }
            }

            boolean var2 = false;
            if (this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.getValue() || this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getValue()) {
               var2 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((var1x) -> {
                  if (var1x.method_7960()) {
                     return false;
                  } else {
                     boolean var2 = false;
                     boolean var3 = false;
                     if (this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.getValue()) {
                        var2 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1x, class_1893.field_50159);
                     }

                     if (this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.getValue()) {
                        var3 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1x, class_1893.field_50158);
                     }

                     return var2 || var3;
                  }
               });
               if (this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getValue()) {
                  System.out.println("[MaceSwap] Tried to swap to enchanted weapon: " + var2);
               }
            }

            if (!var2) {
               var2 = dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp((var0) -> {
                  return var0 instanceof class_1829 || var0 instanceof class_1743;
               });
               if (this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getValue()) {
                  System.out.println("[MaceSwap] Tried to swap to any weapon: " + var2);
               }
            }

            if (var2) {
               this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX = true;
               if (this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getValue()) {
                  System.out.println("[MaceSwap] Successfully swapped to weapon");
               }
            } else if (this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getValue()) {
               System.out.println("[MaceSwap] Failed to find suitable weapon to swap to");
            }

         }
      }
   }

   private boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      class_1792 var1 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_6047().method_7909();
      if (this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getValue() && this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.getValue()) {
         return var1 instanceof class_1829 || var1 instanceof class_1743;
      } else if (this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy.getValue()) {
         return var1 instanceof class_1829;
      } else if (this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.getValue()) {
         return var1 instanceof class_1743;
      } else {
         return var1 instanceof class_1829 || var1 instanceof class_1743;
      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp() {
      if (this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn < this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW.getIntValue()) {
         ++this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn;
      } else {
         if (this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getValue()) {
            System.out.println("[MaceSwap] Switching back to slot: " + this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg);
         }

         dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg);
         this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq();
      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq() {
      this.invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg = -1;
      this.invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn = 0;
      this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX = false;
      if (this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh.getValue()) {
         System.out.println("[MaceSwap] Reset state");
      }

   }
}
