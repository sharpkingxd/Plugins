package dev.krispyy.module.modules.combat;

import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_KoQcacrsFXDUvaeYSUpxlHNTvxbojrxdn;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
import dev.krispyy.module.Category;
import dev.krispyy.module.Module;
import net.minecraft.class_1657;
import net.minecraft.class_4050;

public final class StaticHitboxes extends Module {
   public StaticHitboxes() {
      super(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Static HitBoxes"), dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Expands a Player's Hitbox"), -1, Category.COMBAT);
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq
   public void onTargetPose(invokeConnorftw_KRISPYYCLIENT_KoQcacrsFXDUvaeYSUpxlHNTvxbojrxdn var1) {
      if (this.isEnabled() && var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw instanceof class_1657 && !((class_1657)var1.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw).method_7340()) {
         var1.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.setReturnValue(class_4050.field_18076);
      }

   }
}
