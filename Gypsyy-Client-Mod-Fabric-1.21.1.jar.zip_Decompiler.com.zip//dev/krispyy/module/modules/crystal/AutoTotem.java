package dev.krispyy.module.modules.crystal;

import dev.krispyy.DonutBBC;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
import dev.krispyy.module.Category;
import dev.krispyy.module.Module;
import dev.krispyy.module.modules.donut.RtpBaseFinder;
import dev.krispyy.module.modules.donut.TunnelBaseFinder;
import dev.krispyy.module.setting.NumberSetting;
import dev.krispyy.module.setting.Setting;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

public final class AutoTotem extends Module {
   private final NumberSetting invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = new NumberSetting(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Delay"), 0.0D, 5.0D, 1.0D, 1.0D);
   private int invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;

   public AutoTotem() {
      super(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Auto Totem"), dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Automatically holds totem in your off hand"), -1, Category.CRYSTAL);
      this.addsettings(new Setting[]{this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq});
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq
   public void onTick(invokeConnorftw_KRISPYYCLIENT_TfttCfpbBLKmPEafyAMlaVrELnojggHlzdboAfVYuBkYUbi var1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null) {
         Module var2 = DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(RtpBaseFinder.class);
         if (!var2.isEnabled() || !((RtpBaseFinder)var2).isRepairingActive()) {
            Module var3 = DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(TunnelBaseFinder.class);
            if (!var3.isEnabled() || !((TunnelBaseFinder)var3).isDigging()) {
               if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_31548().method_5438(40).method_7909() == class_1802.field_8288) {
                  this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.getIntValue();
               } else if (this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm > 0) {
                  --this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
               } else {
                  int var4 = this.findItemSlot(class_1802.field_8288);
                  if (var4 != -1) {
                     this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2906(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.field_7512.field_7763, invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var4), 40, class_1713.field_7791, this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724);
                     this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.getIntValue();
                  }
               }
            }
         }
      }
   }

   public int findItemSlot(class_1792 var1) {
      if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 == null) {
         return -1;
      } else {
         for(int var2 = 0; var2 < 36; ++var2) {
            if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_31548().method_5438(var2).method_31574(var1)) {
               return var2;
            }
         }

         return -1;
      }
   }

   private static int invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var0) {
      return var0 < 9 ? 36 + var0 : var0;
   }
}
