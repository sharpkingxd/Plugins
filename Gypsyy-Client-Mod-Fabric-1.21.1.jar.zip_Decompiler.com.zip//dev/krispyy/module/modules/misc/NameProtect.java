package dev.krispyy.module.modules.misc;

import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
import dev.krispyy.module.Category;
import dev.krispyy.module.Module;
import dev.krispyy.module.setting.Setting;
import dev.krispyy.module.setting.StringSetting;

public class NameProtect extends Module {
   private final StringSetting invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = new StringSetting("Fake Name", "Player");

   public NameProtect() {
      super(dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Name Protect"), dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw("Replaces your name with given one."), -1, Category.MISC);
      this.addsettings(new Setting[]{this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq});
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   public String getFakeName() {
      return this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.getValue();
   }
}
