package dev.krispyy.manager;

import java.io.IOException;
import java.nio.FloatBuffer;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.class_5944;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

public class ShaderManager {
   private static class_5944 invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
   private static int invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
   private static int invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
   private static boolean invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = false;

   public static void init(class_3300 var0) {
      if (!invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm) {
         try {
            invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = new class_5944(var0, "krypton:rounded_quad", class_290.field_1585);
            invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = GL30.glGenVertexArrays();
            invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = GL20.glGenBuffers();
            invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
            invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = true;
         } catch (IOException var2) {
            System.err.println("Failed to initialize shaders: " + var2.getMessage());
            var2.printStackTrace();
         }

      }
   }

   private static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      float[] var0 = new float[]{0.0F, 1.0F, 0.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F};
      GL30.glBindVertexArray(invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp);
      GL20.glBindBuffer(34962, invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq);
      FloatBuffer var1 = MemoryUtil.memAllocFloat(var0.length);
      var1.put(var0).flip();
      GL20.glBufferData(34962, var1, 35044);
      MemoryUtil.memFree(var1);
      GL20.glVertexAttribPointer(0, 2, 5126, false, 16, 0L);
      GL20.glEnableVertexAttribArray(0);
      GL20.glVertexAttribPointer(1, 2, 5126, false, 16, 8L);
      GL20.glEnableVertexAttribArray(1);
      GL30.glBindVertexArray(0);
   }

   public static void renderRoundedQuad(float var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10, float var11) {
      if (invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm && invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw != null) {
         try {
            invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.method_34586();
            int var12 = GL20.glGetInteger(35725);
            int var13 = GL20.glGetUniformLocation(var12, "color");
            int var14 = GL20.glGetUniformLocation(var12, "size");
            int var15 = GL20.glGetUniformLocation(var12, "radius");
            int var16 = GL20.glGetUniformLocation(var12, "smoothness");
            if (var13 != -1) {
               GL20.glUniform4f(var13, var4, var5, var6, var7);
            }

            if (var14 != -1) {
               GL20.glUniform2f(var14, var2, var3);
            }

            if (var15 != -1) {
               GL20.glUniform4f(var15, var8, var9, var10, var11);
            }

            if (var16 != -1) {
               GL20.glUniform1f(var16, 1.0F);
            }

            int var17 = GL20.glGetUniformLocation(var12, "projection");
            int var18 = GL20.glGetUniformLocation(var12, "model");
            class_310 var19 = class_310.method_1551();
            float[] var20;
            if (var19 != null && var19.method_22683() != null) {
               var20 = invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(0.0F, (float)var19.method_22683().method_4486(), 0.0F, (float)var19.method_22683().method_4502(), -1.0F, 1.0F);
               if (var17 != -1) {
                  GL20.glUniformMatrix4fv(var17, false, var20);
               }
            }

            var20 = invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var0, var1, var2, var3);
            if (var18 != -1) {
               GL20.glUniformMatrix4fv(var18, false, var20);
            }

            GL30.glBindVertexArray(invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp);
            GL20.glDrawArrays(6, 0, 4);
            GL30.glBindVertexArray(0);
            invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.method_34585();
         } catch (Exception var21) {
            System.err.println("Error rendering rounded quad with shader: " + var21.getMessage());
         }

      }
   }

   private static float[] invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(float var0, float var1, float var2, float var3, float var4, float var5) {
      return new float[]{2.0F / (var1 - var0), 0.0F, 0.0F, 0.0F, 0.0F, 2.0F / (var3 - var2), 0.0F, 0.0F, 0.0F, 0.0F, -2.0F / (var5 - var4), 0.0F, -(var1 + var0) / (var1 - var0), -(var3 + var2) / (var3 - var2), -(var5 + var4) / (var5 - var4), 1.0F};
   }

   private static float[] invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(float var0, float var1, float var2, float var3) {
      return new float[]{var2, 0.0F, 0.0F, 0.0F, 0.0F, var3, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, var0, var1, 0.0F, 1.0F};
   }

   public static void cleanup() {
      if (invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp != 0) {
         GL30.glDeleteVertexArrays(invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp);
         invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = 0;
      }

      if (invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq != 0) {
         GL20.glDeleteBuffers(invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq);
         invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = 0;
      }

      invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = false;
   }

   public static boolean isInitialized() {
      return invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
   }
}
