package dev.krispyy.manager;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.krispyy.DonutBBC;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
import dev.krispyy.module.Module;
import dev.krispyy.module.setting.BindSetting;
import dev.krispyy.module.setting.BooleanSetting;
import dev.krispyy.module.setting.ItemSetting;
import dev.krispyy.module.setting.MacroSetting;
import dev.krispyy.module.setting.MinMaxSetting;
import dev.krispyy.module.setting.ModeSetting;
import dev.krispyy.module.setting.NumberSetting;
import dev.krispyy.module.setting.Setting;
import dev.krispyy.module.setting.StringSetting;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ConfigManager {
   private JsonObject invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
   private final File invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
   private final Gson invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;

   public ConfigManager() {
      String var1 = System.getProperty("user.home");
      String var2 = var1 + File.separator + ".minecraft" + File.separator + "config";
      File var3 = new File(var2);
      if (!var3.exists()) {
         var3.mkdirs();
      }

      this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = new File(var3, "krypton_config.json");
      this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = (new GsonBuilder()).setPrettyPrinting().create();
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = new JsonObject();
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      try {
         if (this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.exists()) {
            FileReader var1 = new FileReader(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp);

            try {
               this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = (JsonObject)this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.fromJson(var1, JsonObject.class);
               if (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw == null) {
                  this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = new JsonObject();
               }
            } catch (Throwable var5) {
               try {
                  var1.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }

               throw var5;
            }

            var1.close();
         } else {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = new JsonObject();
         }
      } catch (Exception var6) {
         System.err.println("[ConfigManager] Error loading config file: " + var6.getMessage());
         var6.printStackTrace();
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = new JsonObject();
      }

   }

   public void loadProfile() {
      try {
         if (this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw == null) {
            this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = new JsonObject();
            return;
         }

         int var1 = 0;
         Iterator var2 = DonutBBC.INSTANCE.getModuleManager().c().iterator();

         while(var2.hasNext()) {
            Module var3 = (Module)var2.next();

            try {
               String var4 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var3);
               JsonElement var5 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.get(var4);
               if (var5 != null && var5.isJsonObject()) {
                  JsonObject var6 = var5.getAsJsonObject();
                  JsonElement var7 = var6.get("enabled");
                  if (var7 != null && var7.isJsonPrimitive() && var7.getAsBoolean()) {
                     var3.toggle(true);
                  }

                  Iterator var8 = var3.getSettings().iterator();

                  while(var8.hasNext()) {
                     Object var9 = var8.next();

                     try {
                        String var10 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((Setting)var9);
                        JsonElement var11 = var6.get(var10);
                        if (var11 != null) {
                           this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((Setting)var9, var11, var3);
                        }
                     } catch (Exception var12) {
                        System.err.println("[ConfigManager] Error loading setting for module " + var4 + ": " + var12.getMessage());
                     }
                  }

                  ++var1;
               }
            } catch (Exception var13) {
               System.err.println("[ConfigManager] Error loading module: " + var13.getMessage());
            }
         }
      } catch (Exception var14) {
         System.err.println("[ConfigManager] Error loading profile: " + var14.getMessage());
         var14.printStackTrace();
      }

   }

   private String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Module var1) {
      try {
         CharSequence var2 = var1.getName();
         return var2 instanceof invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku ? ((invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku)var2).toString() : var2.toString();
      } catch (Exception var3) {
         return "Module_" + var1.hashCode();
      }
   }

   private String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Setting var1) {
      try {
         CharSequence var2 = var1.getName();
         return var2 instanceof invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku ? ((invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku)var2).toString() : var2.toString();
      } catch (Exception var3) {
         return "Setting_" + var1.hashCode();
      }
   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Setting var1, JsonElement var2, Module var3) {
      try {
         if (var1 instanceof BooleanSetting) {
            BooleanSetting var4 = (BooleanSetting)var1;
            if (var2.isJsonPrimitive()) {
               var4.setValue(var2.getAsBoolean());
            }
         } else {
            int var10;
            if (var1 instanceof ModeSetting) {
               ModeSetting var5 = (ModeSetting)var1;
               if (var2.isJsonPrimitive()) {
                  var10 = var2.getAsInt();
                  if (var10 != -1) {
                     var5.setModeIndex(var10);
                  } else {
                     var5.setModeIndex(var5.getOriginalValue());
                  }
               }
            } else if (var1 instanceof NumberSetting) {
               NumberSetting var6 = (NumberSetting)var1;
               if (var2.isJsonPrimitive()) {
                  var6.getValue(var2.getAsDouble());
               }
            } else if (var1 instanceof BindSetting) {
               BindSetting var7 = (BindSetting)var1;
               if (var2.isJsonPrimitive()) {
                  var10 = var2.getAsInt();
                  var7.setValue(var10);
                  if (var7.isModuleKey()) {
                     var3.setKeybind(var10);
                  }
               }
            } else if (var1 instanceof StringSetting) {
               StringSetting var8 = (StringSetting)var1;
               if (var2.isJsonPrimitive()) {
                  var8.setValue(var2.getAsString());
               }
            } else if (var1 instanceof MinMaxSetting) {
               MinMaxSetting var9 = (MinMaxSetting)var1;
               if (var2.isJsonObject()) {
                  JsonObject var16 = var2.getAsJsonObject();
                  if (var16.has("min") && var16.has("max")) {
                     double var11 = var16.get("min").getAsDouble();
                     double var13 = var16.get("max").getAsDouble();
                     var9.setCurrentMin(var11);
                     var9.setCurrentMax(var13);
                  }
               }
            } else if (var1 instanceof ItemSetting && var2.isJsonPrimitive()) {
               ((ItemSetting)var1).setItem((class_1792)class_7923.field_41178.method_10223(class_2960.method_60654(var2.getAsString())));
            } else if (var1 instanceof MacroSetting && var2.isJsonArray()) {
               MacroSetting var17 = (MacroSetting)var1;
               var17.clearCommands();
               Iterator var18 = var2.getAsJsonArray().iterator();

               while(var18.hasNext()) {
                  JsonElement var12 = (JsonElement)var18.next();
                  if (var12.isJsonPrimitive()) {
                     var17.addCommand(var12.getAsString());
                  }
               }
            }
         }
      } catch (Exception var15) {
         System.err.println("[ConfigManager] Error setting value from JSON: " + var15.getMessage());
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp() {
      try {
         File var1 = this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.getParentFile();
         if (var1 != null && !var1.exists()) {
            var1.mkdirs();
         }

         FileWriter var2 = new FileWriter(this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp);

         try {
            this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq.toJson(this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, var2);
         } catch (Throwable var6) {
            try {
               var2.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }

            throw var6;
         }

         var2.close();
      } catch (IOException var7) {
         System.err.println("[ConfigManager] Error saving config file: " + var7.getMessage());
         var7.printStackTrace();
      }

   }

   public void saveConfig() {
      this.shutdown();
   }

   public void manualSave() {
      this.shutdown();
   }

   public void reloadConfig() {
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
      this.loadProfile();
   }

   public File getConfigFile() {
      return this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
   }

   public void shutdown() {
      try {
         this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = new JsonObject();
         int var1 = 0;
         Iterator var2 = DonutBBC.INSTANCE.getModuleManager().c().iterator();

         while(var2.hasNext()) {
            Module var3 = (Module)var2.next();

            try {
               String var4 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var3);
               JsonObject var5 = new JsonObject();
               var5.addProperty("enabled", var3.isEnabled());
               Iterator var6 = var3.getSettings().iterator();

               while(var6.hasNext()) {
                  Setting var7 = (Setting)var6.next();

                  try {
                     this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var7, var5, var3);
                  } catch (Exception var9) {
                     System.err.println("[ConfigManager] Error saving setting for module " + var4 + ": " + var9.getMessage());
                  }
               }

               this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.add(var4, var5);
               ++var1;
            } catch (Exception var10) {
               System.err.println("[ConfigManager] Error saving module: " + var10.getMessage());
            }
         }

         this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp();
      } catch (Exception var11) {
         System.err.println("[ConfigManager] Error during shutdown: " + var11.getMessage());
         var11.printStackTrace(System.err);
      }

   }

   private void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Setting var1, JsonObject var2, Module var3) {
      try {
         String var4 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1);
         if (var1 instanceof BooleanSetting) {
            BooleanSetting var17 = (BooleanSetting)var1;
            var2.addProperty(var4, var17.getValue());
         } else if (var1 instanceof ModeSetting) {
            ModeSetting var6 = (ModeSetting)var1;
            var2.addProperty(var4, var6.getModeIndex());
         } else if (var1 instanceof NumberSetting) {
            NumberSetting var7 = (NumberSetting)var1;
            var2.addProperty(var4, var7.getValue());
         } else if (var1 instanceof BindSetting) {
            BindSetting var8 = (BindSetting)var1;
            var2.addProperty(var4, var8.getValue());
         } else if (var1 instanceof StringSetting) {
            StringSetting var9 = (StringSetting)var1;
            var2.addProperty(var4, var9.getValue());
         } else if (var1 instanceof MinMaxSetting) {
            JsonObject var12 = new JsonObject();
            var12.addProperty("min", ((MinMaxSetting)var1).getCurrentMin());
            var12.addProperty("max", ((MinMaxSetting)var1).getCurrentMax());
            var2.add(var4, var12);
         } else if (var1 instanceof ItemSetting) {
            ItemSetting var10 = (ItemSetting)var1;
            var2.addProperty(var4, class_7923.field_41178.method_10221(var10.getItem()).toString());
         } else if (var1 instanceof MacroSetting) {
            MacroSetting var11 = (MacroSetting)var1;
            JsonArray var18 = new JsonArray();
            Iterator var13 = var11.getCommands().iterator();

            while(var13.hasNext()) {
               String var14 = (String)var13.next();
               var18.add(var14);
            }

            var2.add(var4, var18);
         }
      } catch (Exception var16) {
         String var5 = "Unknown";

         try {
            var5 = this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1);
         } catch (Exception var15) {
            var5 = "Setting_" + var1.hashCode();
         }

         System.err.println("[ConfigManager] Error saving setting " + var5 + ": " + var16.getMessage());
      }

   }
}
