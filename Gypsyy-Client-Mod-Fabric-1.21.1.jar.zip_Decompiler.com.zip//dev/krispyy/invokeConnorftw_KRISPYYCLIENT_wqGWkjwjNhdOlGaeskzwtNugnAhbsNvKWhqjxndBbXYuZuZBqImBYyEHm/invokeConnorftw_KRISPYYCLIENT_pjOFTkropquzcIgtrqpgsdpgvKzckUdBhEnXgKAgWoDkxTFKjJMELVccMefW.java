package dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;

import java.awt.Color;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public class invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW {
   private static int invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
   private static int invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
   private static int invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq;
   private static boolean invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = false;
   private static int invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy;
   private static int invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo;
   private static int invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
   private static int invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW;
   private static int invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh;
   private static int invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX;
   private static int invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg;

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      if (!invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm) {
         String var0 = "#version 330 core\nlayout (location = 0) in vec2 aPos;\nout vec2 fragCoord;\nuniform vec2 u_resolution;\nvoid main() {\n    fragCoord = (aPos + 1.0) * 0.5 * u_resolution;\n    gl_Position = vec4(aPos, 0.0, 1.0);\n}";
         String var1 = "#version 330 core\nuniform vec2 u_resolution;\nuniform vec2 u_position;\nuniform vec2 u_size;\nuniform vec4 u_color;\nuniform vec4 u_cornerRadii;\nuniform float u_borderWidth;\nuniform vec4 u_borderColor;\nin vec2 fragCoord;\nout vec4 fragColor;\n\nfloat roundedBoxSDF(vec2 centerPos, vec2 size, vec4 radius) {\n    radius.xy = (centerPos.x > 0.0) ? radius.xy : radius.zw;\n    radius.x = (centerPos.y > 0.0) ? radius.x : radius.y;\n    vec2 q = abs(centerPos) - size + radius.x;\n    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - radius.x;\n}\n\nvoid main() {\n    vec2 halfSize = u_size * 0.5;\n    vec2 centerPos = fragCoord - u_position - halfSize;\n    float distance = roundedBoxSDF(centerPos, halfSize, u_cornerRadii);\n    float alpha = 1.0 - smoothstep(-1.0, 1.0, distance);\n    \n    if (u_borderWidth > 0.0) {\n        float borderDistance = abs(distance) - u_borderWidth * 0.5;\n        float borderAlpha = 1.0 - smoothstep(-1.0, 1.0, borderDistance);\n        vec4 finalColor = mix(u_color, u_borderColor, step(0.0, distance - u_borderWidth * 0.5));\n        fragColor = vec4(finalColor.rgb, finalColor.a * alpha * borderAlpha);\n    } else {\n        fragColor = vec4(u_color.rgb, u_color.a * alpha);\n    }\n}";

         try {
            invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var0, var1);
            invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = GL20.glGetUniformLocation(invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, "u_resolution");
            invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = GL20.glGetUniformLocation(invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, "u_position");
            invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = GL20.glGetUniformLocation(invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, "u_size");
            invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = GL20.glGetUniformLocation(invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, "u_color");
            invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = GL20.glGetUniformLocation(invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, "u_cornerRadii");
            invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX = GL20.glGetUniformLocation(invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, "u_borderWidth");
            invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg = GL20.glGetUniformLocation(invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw, "u_borderColor");
            invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq();
            invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = true;
         } catch (Exception var3) {
            System.err.println("Failed to initialize EnhancedShaderRenderer: " + var3.getMessage());
            var3.printStackTrace();
         }

      }
   }

   private static void invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq() {
      float[] var0 = new float[]{-1.0F, -1.0F, 1.0F, -1.0F, 1.0F, 1.0F, -1.0F, -1.0F, 1.0F, 1.0F, -1.0F, 1.0F};
      invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = GL30.glGenVertexArrays();
      invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = GL15.glGenBuffers();
      GL30.glBindVertexArray(invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp);
      GL15.glBindBuffer(34962, invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq);
      GL15.glBufferData(34962, var0, 35044);
      GL20.glVertexAttribPointer(0, 2, 5126, false, 8, 0L);
      GL20.glEnableVertexAttribArray(0);
      GL15.glBindBuffer(34962, 0);
      GL30.glBindVertexArray(0);
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_4587 var0, Color var1, float var2, float var3, float var4, float var5, float var6) {
      invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var0, var1, var2, var3, var4, var5, var6, var6, var6, var6, 0.0F, (Color)null);
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_4587 var0, Color var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10, Color var11) {
      if (!invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm) {
         invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw();
      }

      if (invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw != 0) {
         try {
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL20.glUseProgram(invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw);
            float var12 = (float)class_310.method_1551().method_22683().method_4489();
            float var13 = (float)class_310.method_1551().method_22683().method_4506();
            GL20.glUniform2f(invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy, var12, var13);
            GL20.glUniform2f(invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo, var2, var13 - var3 - var5);
            GL20.glUniform2f(invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku, var4, var5);
            GL20.glUniform4f(invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW, (float)var1.getRed() / 255.0F, (float)var1.getGreen() / 255.0F, (float)var1.getBlue() / 255.0F, (float)var1.getAlpha() / 255.0F);
            GL20.glUniform4f(invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh, var6, var7, var8, var9);
            if (var10 > 0.0F && var11 != null) {
               GL20.glUniform1f(invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX, var10);
               GL20.glUniform4f(invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg, (float)var11.getRed() / 255.0F, (float)var11.getGreen() / 255.0F, (float)var11.getBlue() / 255.0F, (float)var11.getAlpha() / 255.0F);
            } else {
               GL20.glUniform1f(invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX, 0.0F);
               GL20.glUniform4f(invokeConnorftw_KRISPYYCLIENT_rvxSDDhHeabjqquTDyyABoPcjQsNgOFtmYtzfanvGcIkafUunqlyIocqJTsg, 0.0F, 0.0F, 0.0F, 0.0F);
            }

            GL11.glScissor((int)var2, (int)(var13 - var3 - var5), (int)var4, (int)var5);
            GL11.glEnable(3089);
            GL30.glBindVertexArray(invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp);
            GL11.glDrawArrays(4, 0, 6);
            GL30.glBindVertexArray(0);
            GL11.glDisable(3089);
            GL20.glUseProgram(0);
            GL11.glDisable(3042);
         } catch (Exception var14) {
            System.err.println("Error rendering rounded rect: " + var14.getMessage());
         }

      }
   }

   private static int invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(String var0, String var1) {
      int var2 = invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(35633, var0);
      int var3 = invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(35632, var1);
      int var4 = GL20.glCreateProgram();
      GL20.glAttachShader(var4, var2);
      GL20.glAttachShader(var4, var3);
      GL20.glLinkProgram(var4);
      if (GL20.glGetProgrami(var4, 35714) == 0) {
         throw new RuntimeException("Failed to link shader program: " + GL20.glGetProgramInfoLog(var4));
      } else {
         GL20.glDeleteShader(var2);
         GL20.glDeleteShader(var3);
         return var4;
      }
   }

   private static int invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var0, String var1) {
      int var2 = GL20.glCreateShader(var0);
      GL20.glShaderSource(var2, var1);
      GL20.glCompileShader(var2);
      if (GL20.glGetShaderi(var2, 35713) == 0) {
         throw new RuntimeException("Failed to compile shader: " + GL20.glGetShaderInfoLog(var2));
      } else {
         return var2;
      }
   }

   public static void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp() {
      if (invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm) {
         GL20.glDeleteProgram(invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw);
         GL30.glDeleteVertexArrays(invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp);
         GL15.glDeleteBuffers(invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq);
         invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = false;
      }

   }
}
