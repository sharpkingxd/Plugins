package dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;

import dev.krispyy.DonutBBC;
import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import net.minecraft.class_3965;
import net.minecraft.class_4969;

public final class invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq {
   public static Stream<class_2818> invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      int var0 = Math.max(2, DonutBBC.mc.field_1690.method_38521()) + 3;
      int var1 = var0 * 2 + 1;
      class_1923 var2 = DonutBBC.mc.field_1724.method_31476();
      class_1923 var3 = new class_1923(var2.field_9181 - var0, var2.field_9180 - var0);
      class_1923 var4 = new class_1923(var2.field_9181 + var0, var2.field_9180 + var0);
      return Stream.iterate(var3, (var2x) -> {
         int var3x = var2x.field_9181;
         int var4x = var2x.field_9180;
         ++var3x;
         if (var3x > var4.field_9181) {
            var3x = var3.field_9181;
            ++var4x;
         }

         if (var4x > var4.field_9180) {
            throw new IllegalStateException("Stream limit didn't work.");
         } else {
            return new class_1923(var3x, var4x);
         }
      }).limit((long)var1 * (long)var1).filter((var0x) -> {
         return DonutBBC.mc.field_1687.method_8393(var0x.field_9181, var0x.field_9180);
      }).map((var0x) -> {
         return DonutBBC.mc.field_1687.method_8497(var0x.field_9181, var0x.field_9180);
      }).filter(Objects::nonNull);
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_2338 var0, class_2248 var1) {
      return DonutBBC.mc.field_1687.method_8320(var0).method_26204() == var1;
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_2338 var0) {
      return invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var0, class_2246.field_23152) && (Integer)DonutBBC.mc.field_1687.method_8320(var0).method_11654(class_4969.field_23153) != 0;
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_2338 var0) {
      return invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var0, class_2246.field_23152) && (Integer)DonutBBC.mc.field_1687.method_8320(var0).method_11654(class_4969.field_23153) == 0;
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_3965 var0, boolean var1) {
      class_1269 var2 = DonutBBC.mc.field_1761.method_2896(DonutBBC.mc.field_1724, class_1268.field_5808, var0);
      if (var2.method_23665() && var2.method_23666() && var1) {
         DonutBBC.mc.field_1724.method_6104(class_1268.field_5808);
      }

   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(class_2338 var0) {
      return DonutBBC.mc.field_1687.method_8320(var0).method_26215();
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_2338 var0, class_2248 var1) {
      return DonutBBC.mc.field_1687.method_8320(var0).method_26204() == var1;
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm(class_2338 var0) {
      return invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var0);
   }
}
