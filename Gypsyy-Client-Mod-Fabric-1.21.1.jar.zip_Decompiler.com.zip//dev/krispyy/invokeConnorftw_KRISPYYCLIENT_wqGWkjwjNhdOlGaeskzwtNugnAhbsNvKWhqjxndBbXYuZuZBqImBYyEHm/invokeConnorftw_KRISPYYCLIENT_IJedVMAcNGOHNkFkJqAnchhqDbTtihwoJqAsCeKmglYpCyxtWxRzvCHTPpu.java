package dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;

import dev.krispyy.DonutBBC;
import java.util.Iterator;
import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1675;
import net.minecraft.class_1799;
import net.minecraft.class_1831;
import net.minecraft.class_1832;
import net.minecraft.class_1834;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_9779;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

public final class invokeConnorftw_KRISPYYCLIENT_IJedVMAcNGOHNkFkJqAnchhqDbTtihwoJqAsCeKmglYpCyxtWxRzvCHTPpu {
   private static final class_310 invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;

   public static boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      return invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_18456().parallelStream().filter((var0) -> {
         return var0 != invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724;
      }).filter((var0) -> {
         return var0.method_5858(invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724) <= 36.0D;
      }).anyMatch(class_1309::method_29504);
   }

   public static class_1297 invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_1657 var0, float var1, boolean var2) {
      float var3 = Float.MAX_VALUE;
      class_1297 var4 = null;

      assert invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 != null;

      Iterator var5 = invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_18112().iterator();

      while(var5.hasNext()) {
         class_1297 var6 = (class_1297)var5.next();
         float var7 = var6.method_5739(var0);
         if (var6 != var0 && var7 <= var1 && invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_6057(var6) == var2 && var7 < var3) {
            var3 = var7;
            var4 = var6;
         }
      }

      return var4;
   }

   public static double invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_243 var0, class_243 var1) {
      return Math.sqrt(Math.pow(var1.field_1352 - var0.field_1352, 2.0D) + Math.pow(var1.field_1351 - var0.field_1351, 2.0D) + Math.pow(var1.field_1350 - var0.field_1350, 2.0D));
   }

   public static class_1657 invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_1657 var0, float var1, boolean var2, boolean var3) {
      float var4 = Float.MAX_VALUE;
      class_1657 var5 = null;
      Iterator var6 = invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_18456().iterator();

      while(var6.hasNext()) {
         class_1657 var7 = (class_1657)var6.next();
         float var8 = (float)invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var0.method_19538(), var7.method_19538());
         if (var7 != var0 && var8 <= var1 && var7.method_6057(var0) == var2 && var8 < var4) {
            var4 = var8;
            var5 = var7;
         }
      }

      return var5;
   }

   public static class_243 invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(float var0, float var1) {
      float var2 = var1 * 0.017453292F;
      float var3 = -var0 * 0.017453292F;
      float var4 = class_3532.method_15362(var3);
      float var5 = class_3532.method_15374(var3);
      float var6 = class_3532.method_15362(var2);
      float var7 = class_3532.method_15374(var2);
      return new class_243((double)(var5 * var6), (double)(-var7), (double)(var4 * var6));
   }

   public static class_243 invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_1657 var0) {
      return invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var0.method_36454(), var0.method_36455());
   }

   public static class_239 invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(double var0) {
      return invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724, false, invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_36454(), invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_36455(), var0);
   }

   public static class_239 invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_1657 var0, boolean var1, float var2, float var3, double var4) {
      if (var0 != null && invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687 != null) {
         class_243 var8 = var0.method_5836(class_9779.field_51956.method_60637(true));
         class_243 var9 = invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var2, var3);
         class_243 var10 = var8.method_1031(var9.field_1352 * var4, var9.field_1351 * var4, var9.field_1350 * var4);
         Object var11 = invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_17742(new class_3959(var8, var10, class_3960.field_17559, class_242.field_1348, var0));
         double var12 = var4 * var4;
         if (var11 != null) {
            var12 = ((class_239)var11).method_17784().method_1025(var8);
         }

         class_243 var14 = var8.method_1031(var9.field_1352 * var4, var9.field_1351 * var4, var9.field_1350 * var4);
         class_238 var15 = var0.method_5829().method_18804(var9.method_1021(var4)).method_1009(1.0D, 1.0D, 1.0D);
         class_3966 var16 = class_1675.method_18075(var0, var8, var14, var15, (var1x) -> {
            return !var1x.method_7325() && var1x.method_5863() && (!var1x.method_5767() || !var1);
         }, var12);
         if (var16 != null) {
            class_243 var17 = var16.method_17784();
            double var18 = var8.method_1025(var17);
            if (var4 > var4 && var18 > Math.pow(var4, 2.0D) || var18 < var12 || var11 == null) {
               var11 = var18 > Math.pow(var4, 2.0D) ? class_3965.method_17778(var17, class_2350.method_10142(var9.field_1352, var9.field_1351, var9.field_1350), class_2338.method_49638(var17)) : var16;
            }
         }

         return (class_239)var11;
      } else {
         return null;
      }
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_3965 var0, boolean var1) {
      class_1269 var2 = invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2896(invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724, class_1268.field_5808, var0);
      if (var2.method_23665() && var2.method_23666() && var1) {
         invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_6104(class_1268.field_5808);
      }

   }

   public static Stream<class_2818> invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp() {
      int var0 = Math.max(2, invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1690.method_38521()) + 3;
      int var1 = var0 * 2 + 1;
      class_1923 var2 = invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_31476();
      class_1923 var3 = new class_1923(var2.field_9181 - var0, var2.field_9180 - var0);
      class_1923 var4 = new class_1923(var2.field_9181 + var0, var2.field_9180 + var0);
      return Stream.iterate(var3, (var2x) -> {
         int var3x = var2x.field_9181;
         int var4x = var2x.field_9180;
         ++var3x;
         if (var3x > var4.field_9181) {
            var3x = var3.field_9181;
            ++var4x;
         }

         if (var4x > var4.field_9180) {
            throw new IllegalStateException("Stream limit didn't work.");
         } else {
            return new class_1923(var3x, var4x);
         }
      }).limit((long)var1 * (long)var1).filter((var0x) -> {
         return invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_8393(var0x.field_9181, var0x.field_9180);
      }).map((var0x) -> {
         return invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1687.method_8497(var0x.field_9181, var0x.field_9180);
      }).filter(Objects::nonNull);
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_1657 var0) {
      if (invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724 != null && var0 != null) {
         class_243 var1 = invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_19538();
         class_243 var2 = var0.method_19538();
         class_243 var3 = var1.method_1020(var2).method_1029();
         float var4 = var0.method_36454();
         float var5 = var0.method_36455();
         class_243 var6 = (new class_243(-Math.sin(Math.toRadians((double)var4)) * Math.cos(Math.toRadians((double)var5)), -Math.sin(Math.toRadians((double)var5)), Math.cos(Math.toRadians((double)var4)) * Math.cos(Math.toRadians((double)var5)))).method_1029();
         double var7 = var6.method_1026(var3);
         return var7 < 0.0D;
      } else {
         return false;
      }
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_1799 var0) {
      if (!(var0.method_7909() instanceof class_1831)) {
         return false;
      } else {
         class_1832 var1 = ((class_1831)var0.method_7909()).method_8022();
         return var1 == class_1834.field_8930 || var1 == class_1834.field_22033;
      }
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_1657 var0, class_1297 var1) {
      return var0.method_7261(0.5F) > 0.9F && var0.field_6017 > 0.0F && !var0.method_24828() && !var0.method_6101() && !var0.method_5869() && !var0.method_6059(class_1294.field_5919) && var1 instanceof class_1309;
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_1297 var0, boolean var1) {
      invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1761.method_2918(invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724, var0);
      if (var1) {
         invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp.field_1724.method_6104(class_1268.field_5808);
      }

   }

   static {
      invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = DonutBBC.mc;
   }
}
