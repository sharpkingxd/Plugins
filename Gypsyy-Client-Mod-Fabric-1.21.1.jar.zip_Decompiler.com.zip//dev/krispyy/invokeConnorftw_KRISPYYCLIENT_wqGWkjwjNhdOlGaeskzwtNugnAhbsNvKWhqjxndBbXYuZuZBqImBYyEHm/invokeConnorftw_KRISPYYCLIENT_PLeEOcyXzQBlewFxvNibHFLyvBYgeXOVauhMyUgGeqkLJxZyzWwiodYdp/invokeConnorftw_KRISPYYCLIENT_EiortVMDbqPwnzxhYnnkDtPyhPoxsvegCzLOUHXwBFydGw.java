package dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;

import dev.krispyy.mixin.CountPlacementModifierAccessor;
import dev.krispyy.mixin.HeightRangePlacementModifierAccessor;
import dev.krispyy.mixin.RarityFilterPlacementModifierAccessor;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.class_1959;
import net.minecraft.class_2794;
import net.minecraft.class_2975;
import net.minecraft.class_3037;
import net.minecraft.class_310;
import net.minecraft.class_3124;
import net.minecraft.class_5317;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_5539;
import net.minecraft.class_5868;
import net.minecraft.class_5875;
import net.minecraft.class_6016;
import net.minecraft.class_6017;
import net.minecraft.class_6122;
import net.minecraft.class_6793;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6799;
import net.minecraft.class_6816;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7145;
import net.minecraft.class_7510;
import net.minecraft.class_7887;
import net.minecraft.class_7924;
import net.minecraft.class_7225.class_7226;
import net.minecraft.class_7225.class_7874;
import net.minecraft.class_7510.class_6827;

public class invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw {
   public int invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
   public int invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp;
   public class_6017 invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = class_6016.method_34998(1);
   public class_6122 invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;
   public class_5868 invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy;
   public float invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = 1.0F;
   public float invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
   public int invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW;
   public Color invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh;
   public boolean invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX;

   public static Map<class_5321<class_1959>, List<invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw>> invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      class_7874 var0 = class_7887.method_46817();
      class_7226 var1 = var0.method_46762(class_7924.field_41245);
      List var2 = ((class_5363)((class_7145)var0.method_46762(class_7924.field_41250).method_46747(class_5317.field_25050).comp_349()).method_45546().comp_1014().get(class_5363.field_25413)).comp_1013().method_12098().method_28443().stream().toList();
      List var3 = class_7510.method_44210(var2, (var0x) -> {
         return ((class_1959)var0x.comp_349()).method_30970().method_30983();
      }, true);
      HashMap var4 = new HashMap();
      class_5321 var5 = class_6816.field_36048;
      invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var4, var3, var1, var5, 7, new Color(209, 27, 245));
      class_5321 var6 = class_6816.field_36047;
      invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var4, var3, var1, var6, 7, new Color(209, 27, 245));
      HashMap var7 = new HashMap();
      var2.forEach((var2x) -> {
         var7.put((class_5321)var2x.method_40230().get(), new ArrayList());
         Stream var3 = ((class_1959)var2x.comp_349()).method_30970().method_30983().stream().flatMap(class_6885::method_40239).map(class_6880::comp_349);
         Objects.requireNonNull(var4);
         Objects.requireNonNull(var4);
         var3.filter(var4::containsKey).forEach((var3x) -> {
            ((List)var7.get(var2x.method_40230().get())).add((invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw)var4.get(var3x));
         });
      });
      return var7;
   }

   private static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Map<class_6796, invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw> var0, List<class_6827> var1, class_7226<class_6796> var2, class_5321<class_6796> var3, int var4, Color var5) {
      class_6796 var6 = (class_6796)var2.method_46747(var3).comp_349();
      int var7 = ((class_6827)var1.get(var4)).comp_304().applyAsInt(var6);
      invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw var8 = new invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var6, var4, var7, var5);
      var0.put(var6, var8);
   }

   private invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_6796 var1, int var2, int var3, Color var4) {
      this.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = var2;
      this.invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = var3;
      this.invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh = var4;
      this.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = new class_5868((class_2794)null, class_5539.method_39034(class_310.method_1551().field_1687.method_31607(), class_310.method_1551().field_1687.method_8597().comp_653()));
      Iterator var5 = var1.comp_335().iterator();

      while(var5.hasNext()) {
         Object var6 = var5.next();
         if (var6 instanceof class_6793) {
            this.invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = ((CountPlacementModifierAccessor)var6).getCount();
         } else if (var6 instanceof class_6795) {
            this.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = ((HeightRangePlacementModifierAccessor)var6).getHeight();
         } else if (var6 instanceof class_6799) {
            this.invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = (float)((RarityFilterPlacementModifierAccessor)var6).getChance();
         }
      }

      class_3037 var7 = ((class_2975)var1.comp_334().comp_349()).comp_333();
      if (var7 instanceof class_3124) {
         this.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku = ((class_3124)var7).field_29064;
         this.invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW = ((class_3124)var7).field_13723;
         if (((class_2975)var1.comp_334().comp_349()).comp_332() instanceof class_5875) {
            this.invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX = true;
         }

      } else {
         throw new IllegalStateException("config for " + String.valueOf(var1) + "is not OreFeatureConfig.class");
      }
   }

   private static String invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp() {
      return "ANCIENT_DEBRIS_DETECTION_KEY";
   }
}
