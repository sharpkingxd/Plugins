package dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;

import dev.krispyy.module.modules.client.DonutBBC;
import dev.krispyy.module.modules.client.SelfDestruct;
import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import net.minecraft.class_243;
import org.joml.Vector3d;

public final class invokeConnorftw_KRISPYYCLIENT_cihqahqQqkagapYopqUuPdNLjMNcIesuvy {
   public static Color invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var0, int var1) {
      int var2 = DonutBBC.redColor.getIntValue();
      int var3 = DonutBBC.greenColor.getIntValue();
      int var4 = DonutBBC.blueColor.getIntValue();
      if (DonutBBC.enableRainbowEffect.getValue()) {
         return invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var1, var0);
      } else {
         return DonutBBC.enableBreathingEffect.getValue() ? invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(new Color(var2, var3, var4, var0), var1, 20) : new Color(var2, var3, var4, var0);
      }
   }

   public static File invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      return new File(SelfDestruct.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(String var0, File var1) {
      try {
         HttpURLConnection var2 = (HttpURLConnection)(new URL(var0)).openConnection();
         var2.setRequestMethod("GET");
         InputStream var3 = var2.getInputStream();
         FileOutputStream var4 = new FileOutputStream(var1);
         byte[] var5 = new byte[1024];

         while(true) {
            int var6 = var3.read(var5);
            if (var6 == -1) {
               var4.close();
               var3.close();
               var2.disconnect();
               break;
            }

            var4.write(var5, 0, var6);
         }
      } catch (Throwable var7) {
         var7.printStackTrace(System.err);
      }

   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Vector3d var0, class_243 var1) {
      var0.x = var1.field_1352;
      var0.y = var1.field_1351;
      var0.z = var1.field_1350;
   }
}
