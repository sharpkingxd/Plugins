package dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;

import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.Iterator;
import java.util.Set;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo {
   public static boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_1799 var0, class_5321<?> var1) {
      if (!var0.method_7960() && var1 != null) {
         try {
            Object2IntArrayMap var2 = new Object2IntArrayMap();
            invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((class_1799)var0, (Object2IntMap)var2);
            return invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw((Object2IntMap)var2, (class_5321)var1);
         } catch (Exception var3) {
            return false;
         }
      } else {
         return false;
      }
   }

   private static boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Object2IntMap<?> var0, class_5321<?> var1) {
      if (var0 != null && var1 != null) {
         ObjectIterator var2 = var0.keySet().iterator();

         Object var3;
         do {
            if (!var2.hasNext()) {
               return false;
            }

            var3 = var2.next();
         } while(!(var3 instanceof class_6880) || !((class_6880)var3).method_40225(var1));

         return true;
      } else {
         return false;
      }
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_1799 var0, Object2IntMap var1) {
      if (var1 != null && !var0.method_7960()) {
         var1.clear();

         try {
            Set var2;
            if (var0.method_7909() == class_1802.field_8598) {
               var2 = ((class_9304)var0.method_57824(class_9334.field_49643)).method_57539();
            } else {
               var2 = var0.method_58657().method_57539();
            }

            if (var2 != null) {
               Iterator var3 = var2.iterator();

               while(var3.hasNext()) {
                  Object var4 = var3.next();
                  if (var4 instanceof Entry) {
                     var1.put(((Entry)var4).getKey(), ((Entry)var4).getIntValue());
                  }
               }
            }
         } catch (Exception var5) {
         }

      }
   }
}
