package dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.NetworkInterface;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class invokeConnorftw_KRISPYYCLIENT_McBdmqsonhjtXWaCuyPgvijcLnpaSiAzwXft {
   private static final String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = "AES/GCM/NoPadding";
   private static final String invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = "RSA/ECB/PKCS1Padding";
   private static final int invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq = 256;
   private static final int invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm = 12;
   private static final int invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy = 16;
   private static final SecureRandom invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo = new SecureRandom();

   public static SecretKey invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      KeyGenerator var0 = KeyGenerator.getInstance("AES");
      var0.init(256, invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo);
      return var0.generateKey();
   }

   public static KeyPair invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp() {
      KeyPairGenerator var0 = KeyPairGenerator.getInstance("RSA");
      var0.initialize(2048, invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo);
      return var0.generateKeyPair();
   }

   public static byte[] invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(byte[] var0, SecretKey var1) {
      Cipher var2 = Cipher.getInstance("AES/GCM/NoPadding");
      byte[] var3 = new byte[12];
      invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.nextBytes(var3);
      GCMParameterSpec var4 = new GCMParameterSpec(128, var3);
      var2.init(1, var1, var4);
      byte[] var5 = var2.doFinal(var0);
      byte[] var6 = new byte[var3.length + var5.length];
      System.arraycopy(var3, 0, var6, 0, var3.length);
      System.arraycopy(var5, 0, var6, var3.length, var5.length);
      return var6;
   }

   public static byte[] invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(byte[] var0, SecretKey var1) {
      if (var0.length < 12) {
         throw new IllegalArgumentException("Encrypted data too short");
      } else {
         byte[] var2 = Arrays.copyOfRange(var0, 0, 12);
         byte[] var3 = Arrays.copyOfRange(var0, 12, var0.length);
         Cipher var4 = Cipher.getInstance("AES/GCM/NoPadding");
         GCMParameterSpec var5 = new GCMParameterSpec(128, var2);
         var4.init(2, var1, var5);
         return var4.doFinal(var3);
      }
   }

   public static String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(String var0, SecretKey var1) {
      byte[] var2 = invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var0.getBytes(StandardCharsets.UTF_8), var1);
      return Base64.getEncoder().encodeToString(var2);
   }

   public static String invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(String var0, SecretKey var1) {
      byte[] var2 = Base64.getDecoder().decode(var0);
      byte[] var3 = invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var2, var1);
      return new String(var3, StandardCharsets.UTF_8);
   }

   public static byte[] invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(byte[] var0, PublicKey var1) {
      Cipher var2 = Cipher.getInstance("RSA/ECB/PKCS1Padding");
      var2.init(1, var1);
      return var2.doFinal(var0);
   }

   public static byte[] invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(byte[] var0, PrivateKey var1) {
      Cipher var2 = Cipher.getInstance("RSA/ECB/PKCS1Padding");
      var2.init(2, var1);
      return var2.doFinal(var0);
   }

   public static byte[] invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(byte[] var0, PrivateKey var1) {
      Signature var2 = Signature.getInstance("SHA256withRSA");
      var2.initSign(var1);
      var2.update(var0);
      return var2.sign();
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(byte[] var0, byte[] var1, PublicKey var2) {
      Signature var3 = Signature.getInstance("SHA256withRSA");
      var3.initVerify(var2);
      var3.update(var0);
      return var3.verify(var1);
   }

   public static String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var0) {
      String var1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      StringBuilder var2 = new StringBuilder(var0);

      for(int var3 = 0; var3 < var0; ++var3) {
         var2.append(var1.charAt(invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.nextInt(var1.length())));
      }

      return var2.toString();
   }

   public static String invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(int var0) {
      StringBuilder var1 = new StringBuilder(var0);

      for(int var2 = 0; var2 < var0; ++var2) {
         var1.append(String.format("%02x", invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.nextInt(256)));
      }

      return var1.toString().toUpperCase();
   }

   public static String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(String var0) {
      MessageDigest var1 = MessageDigest.getInstance("SHA-256");
      byte[] var2 = var1.digest(var0.getBytes(StandardCharsets.UTF_8));
      return invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var2);
   }

   public static String invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(String var0) {
      MessageDigest var1 = MessageDigest.getInstance("SHA-512");
      byte[] var2 = var1.digest(var0.getBytes(StandardCharsets.UTF_8));
      return invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var2);
   }

   public static String invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(byte[] var0) {
      StringBuilder var1 = new StringBuilder();
      byte[] var2 = var0;
      int var3 = var0.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         byte var5 = var2[var4];
         var1.append(String.format("%02x", var5));
      }

      return var1.toString();
   }

   public static byte[] invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(String var0) {
      int var1 = var0.length();
      byte[] var2 = new byte[var1 / 2];

      for(int var3 = 0; var3 < var1; var3 += 2) {
         var2[var3 / 2] = (byte)((Character.digit(var0.charAt(var3), 16) << 4) + Character.digit(var0.charAt(var3 + 1), 16));
      }

      return var2;
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Key var0, String var1) {
      FileOutputStream var2 = new FileOutputStream(var1);

      try {
         var2.write(var0.getEncoded());
      } catch (Throwable var6) {
         try {
            var2.close();
         } catch (Throwable var5) {
            var6.addSuppressed(var5);
         }

         throw var6;
      }

      var2.close();
   }

   public static SecretKey invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm(String var0) {
      FileInputStream var1 = new FileInputStream(var0);

      SecretKeySpec var3;
      try {
         byte[] var2 = var1.readAllBytes();
         var3 = new SecretKeySpec(var2, "AES");
      } catch (Throwable var5) {
         try {
            var1.close();
         } catch (Throwable var4) {
            var5.addSuppressed(var4);
         }

         throw var5;
      }

      var1.close();
      return var3;
   }

   public static PrivateKey invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy(String var0) {
      FileInputStream var1 = new FileInputStream(var0);

      PrivateKey var5;
      try {
         byte[] var2 = var1.readAllBytes();
         PKCS8EncodedKeySpec var3 = new PKCS8EncodedKeySpec(var2);
         KeyFactory var4 = KeyFactory.getInstance("RSA");
         var5 = var4.generatePrivate(var3);
      } catch (Throwable var7) {
         try {
            var1.close();
         } catch (Throwable var6) {
            var7.addSuppressed(var6);
         }

         throw var7;
      }

      var1.close();
      return var5;
   }

   public static PublicKey invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo(String var0) {
      FileInputStream var1 = new FileInputStream(var0);

      PublicKey var5;
      try {
         byte[] var2 = var1.readAllBytes();
         X509EncodedKeySpec var3 = new X509EncodedKeySpec(var2);
         KeyFactory var4 = KeyFactory.getInstance("RSA");
         var5 = var4.generatePublic(var3);
      } catch (Throwable var7) {
         try {
            var1.close();
         } catch (Throwable var6) {
            var7.addSuppressed(var6);
         }

         throw var7;
      }

      var1.close();
      return var5;
   }

   public static String invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         byte[] var1 = new byte[16];
         invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo.nextBytes(var1);
         byte[] var2 = var0.getBytes(StandardCharsets.UTF_8);
         byte[] var3 = new byte[var2.length + 16];
         System.arraycopy(var1, 0, var3, 0, 16);

         for(int var4 = 0; var4 < var2.length; ++var4) {
            var3[var4 + 16] = (byte)(var2[var4] ^ var1[var4 % var1.length]);
         }

         return Base64.getEncoder().encodeToString(var3);
      } else {
         return var0;
      }
   }

   public static String invokeConnorftw_KRISPYYCLIENT_pjOFTkropquzcIgtrqpgsdpgvKzckUdBhEnXgKAgWoDkxTFKjJMELVccMefW(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         try {
            byte[] var1 = Base64.getDecoder().decode(var0);
            if (var1.length < 16) {
               return var0;
            } else {
               byte[] var2 = Arrays.copyOfRange(var1, 0, 16);
               byte[] var3 = Arrays.copyOfRange(var1, 16, var1.length);
               byte[] var4 = new byte[var3.length];

               for(int var5 = 0; var5 < var3.length; ++var5) {
                  var4[var5] = (byte)(var3[var5] ^ var2[var5 % var2.length]);
               }

               return new String(var4, StandardCharsets.UTF_8);
            }
         } catch (Exception var6) {
            return var0;
         }
      } else {
         return var0;
      }
   }

   public static String invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq() {
      try {
         StringBuilder var0 = new StringBuilder();
         var0.append(System.getProperty("os.name"));
         var0.append(System.getProperty("os.version"));
         var0.append(System.getProperty("os.arch"));
         var0.append(System.getProperty("user.name"));
         var0.append(System.getProperty("user.home"));
         var0.append(Runtime.getRuntime().availableProcessors());
         var0.append(Runtime.getRuntime().maxMemory());
         NetworkInterface.getNetworkInterfaces().asIterator().forEachRemaining((var1x) -> {
            try {
               if (var1x.isUp() && !var1x.isLoopback()) {
                  byte[] var2 = var1x.getHardwareAddress();
                  if (var2 != null) {
                     byte[] var3 = var2;
                     int var4 = var2.length;

                     for(int var5 = 0; var5 < var4; ++var5) {
                        byte var6 = var3[var5];
                        var0.append(String.format("%02X", var6));
                     }
                  }
               }
            } catch (Exception var7) {
            }

         });
         MessageDigest var1 = MessageDigest.getInstance("SHA-256");
         byte[] var2 = var1.digest(var0.toString().getBytes(StandardCharsets.UTF_8));
         return invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var2).substring(0, 32).toUpperCase();
      } catch (Exception var3) {
         String var10000 = System.getProperty("user.name");
         return "HWID_" + var10000 + "_" + System.getProperty("os.name").replaceAll("\\s+", "") + "_" + System.currentTimeMillis();
      }
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_DwtPOFHIjrAciLcBJcrnChaqVmwJVFDuaivzqwkJfewh(String var0) {
      return var0 != null && var0.length() == 32 ? var0.matches("^[A-F0-9]{32}$") : false;
   }

   public static String invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm() {
      return invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(32);
   }

   public static String invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(byte[] var0) {
      MessageDigest var1 = MessageDigest.getInstance("SHA-256");
      byte[] var2 = var1.digest(var0);
      return Base64.getEncoder().encodeToString(var2);
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(byte[] var0, String var1) {
      String var2 = invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var0);
      return var2.equals(var1);
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(String var0, String var1) {
      if (var0 != null && var1 != null) {
         if (var0.length() != var1.length()) {
            return false;
         } else {
            int var2 = 0;

            for(int var3 = 0; var3 < var0.length(); ++var3) {
               var2 |= var0.charAt(var3) ^ var1.charAt(var3);
            }

            return var2 == 0;
         }
      } else {
         return var0 == var1;
      }
   }

   public static void invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(byte[] var0) {
      if (var0 != null) {
         Arrays.fill(var0, (byte)0);
      }

   }

   public static void invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX(String var0) {
      if (var0 != null) {
         var0 = null;
      }

   }
}
