package dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;

import dev.krispyy.DonutBBC;
import dev.krispyy.mixin.ClientPlayerInteractionManagerAccessor;
import java.util.function.Predicate;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public final class invokeConnorftw_KRISPYYCLIENT_OCZWFwMHmfjdQWAINmpnyLZvsPRfawvFgzPSicsNtYqfhZwUVKxttygnQPbX {
   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var0) {
      if (var0 >= 0 && var0 <= 8) {
         DonutBBC.mc.field_1724.method_31548().field_7545 = var0;
         ((ClientPlayerInteractionManagerAccessor)DonutBBC.mc.field_1761).syncSlot();
      }
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Predicate<class_1799> var0) {
      class_1661 var1 = DonutBBC.mc.field_1724.method_31548();

      for(int var2 = 0; var2 < 9; ++var2) {
         if (var0.test(var1.method_5438(var2))) {
            var1.field_7545 = var2;
            ((ClientPlayerInteractionManagerAccessor)DonutBBC.mc.field_1761).syncSlot();
            return true;
         }
      }

      return false;
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(Predicate<class_1792> var0) {
      class_1661 var1 = DonutBBC.mc.field_1724.method_31548();

      for(int var2 = 0; var2 < 9; ++var2) {
         if (var0.test(var1.method_5438(var2).method_7909())) {
            var1.field_7545 = var2;
            ((ClientPlayerInteractionManagerAccessor)DonutBBC.mc.field_1761).syncSlot();
            return true;
         }
      }

      return false;
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_1792 var0) {
      return invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp((var1) -> {
         return var1 == var0;
      });
   }

   public static int invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_1792 var0) {
      class_1703 var1 = DonutBBC.mc.field_1724.field_7512;
      if (DonutBBC.mc.field_1724.field_7512 instanceof class_1707) {
         int var2 = 0;

         for(int var3 = 0; var3 < ((class_1707)DonutBBC.mc.field_1724.field_7512).method_17388() * 9; ++var3) {
            if (var1.method_7611(var3).method_7677().method_7909().equals(var0)) {
               ++var2;
            }
         }

         return var2;
      } else {
         return 0;
      }
   }

   public static boolean invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(class_1792 var0) {
      class_1661 var1 = DonutBBC.mc.field_1724.method_31548();

      for(int var2 = 0; var2 < 9; ++var2) {
         if (var1.method_5438(var2).method_7909() == var0) {
            var1.field_7545 = var2;
            ((ClientPlayerInteractionManagerAccessor)DonutBBC.mc.field_1761).syncSlot();
            return true;
         }
      }

      return false;
   }
}
