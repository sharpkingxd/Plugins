package dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.krispyy.DonutBBC;
import dev.krispyy.manager.ShaderManager;
import java.awt.Color;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5944;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_8251;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

public final class invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav {
   public static class_8251 invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw;
   public static boolean invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = true;

   public static class_243 invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw() {
      return invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp().method_19326();
   }

   public static class_4184 invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp() {
      return DonutBBC.mc.method_31975().field_4344;
   }

   public static double invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq() {
      double var0;
      if (DonutBBC.mc.method_47599() > 0) {
         var0 = 1.0D / (double)DonutBBC.mc.method_47599();
      } else {
         var0 = 1.0D;
      }

      return var0;
   }

   public static float invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(float var0, float var1, float var2) {
      return (1.0F - class_3532.method_15363((float)(invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq() * (double)var2), 0.0F, 1.0F)) * var0 + class_3532.method_15363((float)(invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq() * (double)var2), 0.0F, 1.0F) * var1;
   }

   public static class_243 invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_1657 var0) {
      float var1 = class_3532.method_15362(var0.method_36454() * 0.017453292F - 3.1415927F);
      float var2 = class_3532.method_15374(var0.method_36454() * 0.017453292F - 3.1415927F);
      float var3 = class_3532.method_15362(var0.method_36455() * 0.017453292F);
      return (new class_243((double)(var2 * var3), (double)class_3532.method_15374(var0.method_36455() * 0.017453292F), (double)(var1 * var3))).method_1029();
   }

   public static void invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm() {
      invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw = RenderSystem.getVertexSorting();
      RenderSystem.setProjectionMatrix((new Matrix4f()).setOrtho(0.0F, (float)DonutBBC.mc.method_22683().method_4489(), (float)DonutBBC.mc.method_22683().method_4506(), 0.0F, 1000.0F, 21000.0F), class_8251.field_43361);
      invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = false;
   }

   public static void invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy() {
      RenderSystem.setProjectionMatrix((new Matrix4f()).setOrtho(0.0F, (float)((double)DonutBBC.mc.method_22683().method_4489() / DonutBBC.mc.method_22683().method_4495()), (float)((double)DonutBBC.mc.method_22683().method_4506() / DonutBBC.mc.method_22683().method_4495()), 0.0F, 1000.0F, 21000.0F), invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw);
      invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp = true;
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_4587 var0, Color var1, double var2, double var4, double var6, double var8, double var10, double var12, double var14, double var16, double var18) {
      int var20 = var1.getRGB();
      Matrix4f var21 = var0.method_23760().method_23761();
      RenderSystem.enableBlend();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.setShader(class_757::method_34540);
      invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var21, (float)(var20 >> 16 & 255) / 255.0F, (float)(var20 >> 8 & 255) / 255.0F, (float)(var20 & 255) / 255.0F, (float)(var20 >> 24 & 255) / 255.0F, var2, var4, var6, var8, var10, var12, var14, var16, var18);
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
   }

   private static void invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo() {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
   }

   private static void invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku() {
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_4587 var0, Color var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var0, var1, var2, var4, var6, var8, var10, var10, var10, var10, var12);
   }

   public static void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_4587 var0, Color var1, double var2, double var4, double var6, double var8, double var10, double var12, double var14, double var16, double var18) {
      if (ShaderManager.isInitialized()) {
         ShaderManager.renderRoundedQuad((float)var2, (float)var4, (float)var6, (float)var8, (float)var1.getRed() / 255.0F, (float)var1.getGreen() / 255.0F, (float)var1.getBlue() / 255.0F, (float)var1.getAlpha() / 255.0F, (float)var10, (float)var12, (float)var14, (float)var16);
      } else {
         invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var0, var1, var2, var4, var2 + var6, var4 + var8, var10, var12, var14, var16, var18);
      }

   }

   public static void invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(class_4587 var0, Color var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(var0, var1, var2, var4, var6, var8, var10, var10, var10, var10, var12);
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Matrix4f var0, float var1, float var2, float var3, float var4, double var5, double var7, double var9, double var11, double var13, double var15, double var17, double var19, double var21, double var23) {
      class_287 var25 = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
      double[][] var26 = new double[][]{{var9 - var19, var11 - var19, var19}, {var9 - var15, var7 + var15, var15}, {var5 + var13, var7 + var13, var13}, {var5 + var17, var11 - var17, var17}};

      for(int var27 = 0; var27 < 4; ++var27) {
         double[] var28 = var26[var27];
         double var29 = var28[2];

         double var31;
         double var33;
         double var35;
         double var37;
         double var39;
         for(var31 = (double)var27 * 90.0D; var31 < 90.0D + (double)var27 * 90.0D; var31 += 90.0D / var23) {
            var33 = Math.toRadians(var31);
            var35 = Math.sin((double)((float)var33));
            var37 = var35 * var29;
            var39 = Math.cos((double)((float)var33));
            double var41 = var39 * var29;
            var25.method_22918(var0, (float)var28[0] + (float)var37, (float)var28[1] + (float)var41, 0.0F).method_22915(var1, var2, var3, var4);
            var25.method_22918(var0, (float)(var28[0] + (double)((float)var37) + var35 * var21), (float)(var28[1] + (double)((float)var41) + var39 * var21), 0.0F).method_22915(var1, var2, var3, var4);
         }

         var31 = Math.toRadians(90.0D + (double)var27 * 90.0D);
         var33 = Math.sin((double)((float)var31));
         var35 = var33 * var29;
         var37 = Math.cos((double)((float)var31));
         var39 = var37 * var29;
         var25.method_22918(var0, (float)var28[0] + (float)var35, (float)var28[1] + (float)var39, 0.0F).method_22915(var1, var2, var3, var4);
         var25.method_22918(var0, (float)(var28[0] + (double)((float)var35) + var33 * var21), (float)(var28[1] + (double)((float)var39) + var37 * var21), 0.0F).method_22915(var1, var2, var3, var4);
      }

      double[] var43 = var26[0];
      double var44 = var43[2];
      var25.method_22918(var0, (float)var43[0], (float)var43[1] + (float)var44, 0.0F).method_22915(var1, var2, var3, var4);
      var25.method_22918(var0, (float)var43[0], (float)(var43[1] + (double)((float)var44) + var21), 0.0F).method_22915(var1, var2, var3, var4);
      class_286.method_43433(var25.method_60800());
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var0, int var1, int var2, int var3) {
      class_310 var4 = class_310.method_1551();
      class_437 var5 = var4.field_1755;
      int var6;
      if (var4.field_1755 == null) {
         var6 = 0;
      } else {
         var6 = var5.field_22790 - var3;
      }

      double var7 = class_310.method_1551().method_22683().method_4495();
      GL11.glScissor((int)((double)var0 * var7), (int)((double)var6 * var7), (int)((double)(var2 - var0) * var7), (int)((double)(var3 - var1) * var7));
      GL11.glEnable(3089);
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_4587 var0, Color var1, double var2, double var4, double var6, int var8) {
      int var9 = class_3532.method_15340(var8, 4, 360);
      int var10 = var1.getRGB();
      Matrix4f var11 = var0.method_23760().method_23761();
      invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo();
      RenderSystem.setShader(class_757::method_34540);
      class_287 var12 = class_289.method_1348().method_60827(class_5596.field_27381, class_290.field_1576);

      for(int var13 = 0; var13 < 360; var13 += Math.min(360 / var9, 360 - var13)) {
         double var14 = Math.toRadians((double)var13);
         var12.method_22918(var11, (float)(var2 + Math.sin(var14) * var6), (float)(var4 + Math.cos(var14) * var6), 0.0F).method_22915((float)(var10 >> 16 & 255) / 255.0F, (float)(var10 >> 8 & 255) / 255.0F, (float)(var10 & 255) / 255.0F, (float)(var10 >> 24 & 255) / 255.0F);
      }

      class_286.method_43433(var12.method_60800());
      invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku();
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_4587 var0, Color var1, Color var2, Color var3, Color var4, float var5, float var6, float var7, float var8, float var9, float var10) {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      class_287 var11 = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1592);
      var11.method_22918(var0.method_23760().method_23761(), var5 - 10.0F, var6 - 10.0F, 0.0F);
      var11.method_22918(var0.method_23760().method_23761(), var5 - 10.0F, var6 + var8 + 20.0F, 0.0F);
      var11.method_22918(var0.method_23760().method_23761(), var5 + var7 + 20.0F, var6 + var8 + 20.0F, 0.0F);
      var11.method_22918(var0.method_23760().method_23761(), var5 + var7 + 20.0F, var6 - 10.0F, 0.0F);
      class_286.method_43433(var11.method_60800());
      RenderSystem.disableBlend();
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 var0, Color var1, double var2, double var4, double var6, double var8, double var10, double var12, double var14, double var16, double var18, double var20) {
      int var22 = var1.getRGB();
      Matrix4f var23 = var0.method_51448().method_23760().method_23761();
      invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo();
      RenderSystem.setShader(class_757::method_34540);
      invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var23, (float)(var22 >> 16 & 255) / 255.0F, (float)(var22 >> 8 & 255) / 255.0F, (float)(var22 & 255) / 255.0F, (float)(var22 >> 24 & 255) / 255.0F, var2, var4, var6, var8, var10, var12, var14, var16, var18, var20);
      invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku();
   }

   public static class_4587 invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(double var0, double var2, double var4) {
      class_4587 var6 = new class_4587();
      class_4184 var7 = class_310.method_1551().field_1773.method_19418();
      var6.method_22907(class_7833.field_40714.rotationDegrees(var7.method_19329()));
      var6.method_22907(class_7833.field_40716.rotationDegrees(var7.method_19330() + 180.0F));
      var6.method_22904(var0 - var7.method_19326().field_1352, var2 - var7.method_19326().field_1351, var4 - var7.method_19326().field_1350);
      return var6;
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_4587 var0, float var1, float var2, float var3, float var4, int var5) {
      float var6 = (float)(var5 >> 24 & 255) / 255.0F;
      float var7 = (float)(var5 >> 16 & 255) / 255.0F;
      float var8 = (float)(var5 >> 8 & 255) / 255.0F;
      float var9 = (float)(var5 & 255) / 255.0F;
      var0.method_22903();
      var0.method_22905(0.5F, 0.5F, 0.5F);
      var0.method_22904((double)var1, (double)var2, 0.0D);
      class_289 var10 = class_289.method_1348();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      class_287 var11 = var10.method_60827(class_5596.field_27382, class_290.field_1576);
      var11.method_22912(0.0F, 0.0F, 0.0F).method_22915(var7, var8, var9, var6);
      var11.method_22912(0.0F, var4, 0.0F).method_22915(var7, var8, var9, var6);
      var11.method_22912(var3, var4, 0.0F).method_22915(var7, var8, var9, var6);
      var11.method_22912(var3, 0.0F, 0.0F).method_22915(var7, var8, var9, var6);
      class_286.method_43433(var11.method_60800());
      RenderSystem.disableBlend();
      var0.method_22909();
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(Matrix4f var0, float var1, float var2, float var3, float var4, double var5, double var7, double var9, double var11, double var13, double var15, double var17, double var19, double var21) {
      class_287 var23 = class_289.method_1348().method_60827(class_5596.field_27381, class_290.field_1576);
      double[][] var24 = new double[][]{{var9 - var19, var11 - var19, var19}, {var9 - var15, var7 + var15, var15}, {var5 + var13, var7 + var13, var13}, {var5 + var17, var11 - var17, var17}};

      for(int var25 = 0; var25 < 4; ++var25) {
         double[] var26 = var24[var25];
         double var27 = var26[2];

         double var29;
         for(var29 = (double)var25 * 90.0D; var29 < 90.0D + (double)var25 * 90.0D; var29 += 90.0D / var21) {
            double var31 = Math.toRadians(var29);
            var23.method_22918(var0, (float)var26[0] + (float)(Math.sin((double)((float)var31)) * var27), (float)var26[1] + (float)(Math.cos((double)((float)var31)) * var27), 0.0F).method_22915(var1, var2, var3, var4);
         }

         var29 = Math.toRadians(90.0D + (double)var25 * 90.0D);
         var23.method_22918(var0, (float)var26[0] + (float)(Math.sin((double)((float)var29)) * var27), (float)var26[1] + (float)(Math.cos((double)((float)var29)) * var27), 0.0F).method_22915(var1, var2, var3, var4);
      }

      class_286.method_43433(var23.method_60800());
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_4587 var0, float var1, float var2, float var3, float var4, float var5, float var6, Color var7) {
      RenderSystem.enableBlend();
      RenderSystem.disableDepthTest();
      RenderSystem.setShaderColor((float)var7.getRed() / 255.0F, (float)var7.getGreen() / 255.0F, (float)var7.getBlue() / 255.0F, (float)var7.getAlpha() / 255.0F);
      RenderSystem.setShader(class_757::method_34539);
      class_287 var8 = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1592);
      var8.method_22918(var0.method_23760().method_23761(), var1, var2, var3);
      var8.method_22918(var0.method_23760().method_23761(), var1, var2, var3);
      var8.method_22918(var0.method_23760().method_23761(), var1, var2, var3);
      var8.method_22918(var0.method_23760().method_23761(), var1, var2, var6);
      var8.method_22918(var0.method_23760().method_23761(), var1, var5, var3);
      var8.method_22918(var0.method_23760().method_23761(), var1, var5, var6);
      var8.method_22918(var0.method_23760().method_23761(), var1, var5, var6);
      var8.method_22918(var0.method_23760().method_23761(), var1, var2, var6);
      var8.method_22918(var0.method_23760().method_23761(), var4, var5, var6);
      var8.method_22918(var0.method_23760().method_23761(), var4, var2, var6);
      var8.method_22918(var0.method_23760().method_23761(), var4, var2, var6);
      var8.method_22918(var0.method_23760().method_23761(), var4, var2, var3);
      var8.method_22918(var0.method_23760().method_23761(), var4, var5, var6);
      var8.method_22918(var0.method_23760().method_23761(), var4, var5, var3);
      var8.method_22918(var0.method_23760().method_23761(), var4, var5, var3);
      var8.method_22918(var0.method_23760().method_23761(), var4, var2, var3);
      var8.method_22918(var0.method_23760().method_23761(), var1, var5, var3);
      var8.method_22918(var0.method_23760().method_23761(), var1, var2, var3);
      var8.method_22918(var0.method_23760().method_23761(), var1, var2, var3);
      var8.method_22918(var0.method_23760().method_23761(), var4, var2, var3);
      var8.method_22918(var0.method_23760().method_23761(), var1, var2, var6);
      var8.method_22918(var0.method_23760().method_23761(), var4, var2, var6);
      var8.method_22918(var0.method_23760().method_23761(), var4, var2, var6);
      var8.method_22918(var0.method_23760().method_23761(), var1, var5, var3);
      var8.method_22918(var0.method_23760().method_23761(), var1, var5, var3);
      var8.method_22918(var0.method_23760().method_23761(), var1, var5, var6);
      var8.method_22918(var0.method_23760().method_23761(), var4, var5, var3);
      var8.method_22918(var0.method_23760().method_23761(), var4, var5, var6);
      var8.method_22918(var0.method_23760().method_23761(), var4, var5, var6);
      var8.method_22918(var0.method_23760().method_23761(), var4, var5, var6);
      class_286.method_43433(var8.method_60800());
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.enableDepthTest();
      RenderSystem.disableBlend();
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_4587 var0, Color var1, class_243 var2, class_243 var3) {
      var0.method_22903();
      Matrix4f var4 = var0.method_23760().method_23761();
      if (dev.krispyy.module.modules.client.DonutBBC.enableMSAA.getValue()) {
         GL11.glEnable(32925);
         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
      }

      GL11.glDepthFunc(519);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableBlend();
      invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_5596.field_29344, class_290.field_1576, class_757::method_34540, var4, var2, var3.method_1020(var2), var1, (var0x, var1x, var2x, var3x, var4x, var5, var6, var7, var8, var9, var10, var11) -> {
         var0x.method_22918(var11, var1x, var2x, var3x).method_22915(var7, var8, var9, var10);
         var0x.method_22918(var11, var4x, var5, var6).method_22915(var7, var8, var9, var10);
      });
      GL11.glDepthFunc(515);
      RenderSystem.disableBlend();
      if (dev.krispyy.module.modules.client.DonutBBC.enableMSAA.getValue()) {
         GL11.glDisable(2848);
         GL11.glDisable(32925);
      }

      var0.method_22909();
   }

   public static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_332 var0, class_1799 var1, int var2, int var3, float var4, int var5) {
      if (!var1.method_7960()) {
         float var6 = var4 / 16.0F;
         class_4587 var7 = var0.method_51448();
         var7.method_22903();
         var7.method_46416((float)var2, (float)var3, (float)var5);
         var7.method_22905(var6, var6, 1.0F);
         var0.method_51427(var1, 0, 0);
         var7.method_22909();
      }
   }

   private static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_5596 var0, class_293 var1, Supplier<class_5944> var2, Matrix4f var3, class_243 var4, class_243 var5, Color var6, invokeConnorftw_KRISPYYCLIENT_NjuqBLqpabLAcigrUUDAHikPgjzdcBxZghwQDefwGPlZQqfzOlgegqav.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw var7) {
      float var8 = (float)var6.getRed() / 255.0F;
      float var9 = (float)var6.getGreen() / 255.0F;
      float var10 = (float)var6.getBlue() / 255.0F;
      float var11 = (float)var6.getAlpha() / 255.0F;
      class_243 var12 = var4.method_1019(var5);
      float var13 = (float)var4.field_1352;
      float var14 = (float)var4.field_1351;
      float var15 = (float)var4.field_1350;
      float var16 = (float)var12.field_1352;
      float var17 = (float)var12.field_1351;
      float var18 = (float)var12.field_1350;
      invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(var0, var1, var2, (var12x) -> {
         var7.run(var12x, var13, var14, var15, var16, var17, var18, var8, var9, var10, var11, var3);
      });
   }

   private static void invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(class_5596 var0, class_293 var1, Supplier<class_5944> var2, Consumer<class_287> var3) {
      class_287 var4 = class_289.method_1348().method_60827(var0, var1);
      var3.accept(var4);
      invokeConnorftw_KRISPYYCLIENT_AFPIsKtGqzlNrLrPketgdAjeMNkntaWwhjKqpCoo();
      RenderSystem.setShader(var2);
      class_286.method_43433(var4.method_60800());
      invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku();
   }

   public static int invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var0, float var1) {
      float var2 = (float)((System.currentTimeMillis() + (long)var0) % 3000L) / 3000.0F;
      return Color.HSBtoRGB(var2, 1.0F, 1.0F) | (int)(var1 * 255.0F) << 24;
   }

   interface invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw {
      void run(class_287 var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10, float var11, Matrix4f var12);
   }
}
