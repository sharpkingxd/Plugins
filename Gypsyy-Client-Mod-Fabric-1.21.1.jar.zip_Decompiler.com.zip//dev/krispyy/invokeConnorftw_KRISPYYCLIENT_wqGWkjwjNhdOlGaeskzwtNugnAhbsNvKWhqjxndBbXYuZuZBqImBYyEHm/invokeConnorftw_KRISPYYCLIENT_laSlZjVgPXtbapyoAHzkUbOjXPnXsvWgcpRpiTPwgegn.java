package dev.krispyy.invokeConnorftw_KRISPYYCLIENT_wqGWkjwjNhdOlGaeskzwtNugnAhbsNvKWhqjxndBbXYuZuZBqImBYyEHm;

public final class invokeConnorftw_KRISPYYCLIENT_laSlZjVgPXtbapyoAHzkUbOjXPnXsvWgcpRpiTPwgegn {
   public static double invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(double var0, double var2) {
      return var2 * (double)Math.round(var0 / var2);
   }

   public static double invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(double var0, double var2, double var4) {
      double var6 = Math.max(0.0D, Math.min(1.0D, var0));
      return var2 + (var4 - var2) * var6 * var6 * (3.0D - 2.0D * var6);
   }

   public static double invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(float var0, double var1, double var3) {
      double var5 = Math.ceil(Math.abs(var3 - var1) * (double)var0);
      return var1 < var3 ? Math.min(var1 + (double)((int)var5), var3) : Math.max(var1 - (double)((int)var5), var3);
   }

   public static double invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp(double var0, double var2, double var4) {
      return var2 + (var4 - var2) * var0;
   }

   public static double invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(double var0, double var2, double var4, double var6) {
      return invokeConnorftw_KRISPYYCLIENT_PLeEOcyXzQBlewFxvNibHFLyvBYgeXOVauhMyUgGeqkLJxZyzWwiodYdp((double)(1.0F - (float)Math.pow(var4, var6)), var0, var2);
   }

   public static double invokeConnorftw_KRISPYYCLIENT_xyvuPrctQOtmIdNHweEAfbOvqZnZtwtfcGkuCfrdHgknjldyyCFlq(double var0, double var2, double var4) {
      return Math.max(var2, Math.min(var0, var4));
   }

   public static int invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var0, int var1, int var2) {
      return Math.max(var1, Math.min(var0, var2));
   }

   public static int invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw(int var0, int var1) {
      return (int)(Math.random() * (double)(var1 - var0 + 1)) + var0;
   }
}
