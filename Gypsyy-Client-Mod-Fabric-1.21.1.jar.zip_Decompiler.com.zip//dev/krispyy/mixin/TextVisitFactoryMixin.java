package dev.krispyy.mixin;

import dev.krispyy.DonutBBC;
import dev.krispyy.module.modules.misc.NameProtect;
import net.minecraft.class_5223;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin({class_5223.class})
public class TextVisitFactoryMixin {
   @ModifyArg(
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/text/TextVisitFactory;visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z",
   ordinal = 0
),
      method = {"visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z"},
      index = 0
   )
   private static String adjustText(String var0) {
      NameProtect var1 = (NameProtect)DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(NameProtect.class);
      return var1.isEnabled() && var0.contains(DonutBBC.mc.method_1548().method_1676()) ? var0.replace(DonutBBC.mc.method_1548().method_1676(), var1.getFakeName()) : var0;
   }
}
