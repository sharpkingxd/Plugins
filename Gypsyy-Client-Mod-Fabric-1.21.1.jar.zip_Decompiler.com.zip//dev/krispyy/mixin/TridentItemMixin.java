package dev.krispyy.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dev.krispyy.module.modules.misc.TridentBoost;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1835;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin({class_1835.class})
public abstract class TridentItemMixin {
   @Inject(
      method = {"onStoppedUsing"},
      at = {@At("HEAD")}
   )
   private void onStoppedUsingHead(class_1799 var1, class_1937 var2, class_1309 var3, int var4, CallbackInfo var5) {
   }

   @Inject(
      method = {"onStoppedUsing"},
      at = {@At("TAIL")}
   )
   private void onStoppedUsingTail(class_1799 var1, class_1937 var2, class_1309 var3, int var4, CallbackInfo var5) {
   }

   @ModifyArgs(
      method = {"onStoppedUsing"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/player/PlayerEntity;addVelocity(DDD)V"
)
   )
   private void modifyVelocity(Args var1) {
      TridentBoost var2 = TridentBoost.getInstance();
      var1.set(0, (Double)var1.get(0) * var2.getMultiplier());
      var1.set(1, (Double)var1.get(1) * var2.getMultiplier());
      var1.set(2, (Double)var1.get(2) * var2.getMultiplier());
   }

   @ModifyExpressionValue(
      method = {"use"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/player/PlayerEntity;isTouchingWaterOrRain()Z"
)}
   )
   private boolean isInWaterUse(boolean var1) {
      TridentBoost var2 = TridentBoost.getInstance();
      return var2.allowOutOfWater() || var1;
   }

   @ModifyExpressionValue(
      method = {"onStoppedUsing"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/player/PlayerEntity;isTouchingWaterOrRain()Z"
)}
   )
   private boolean isInWaterPostUse(boolean var1) {
      TridentBoost var2 = TridentBoost.getInstance();
      return var2.allowOutOfWater() || var1;
   }
}
