package dev.krispyy.mixin;

import dev.krispyy.DonutBBC;
import dev.krispyy.module.Module;
import dev.krispyy.module.modules.combat.Hitbox;
import net.minecraft.class_238;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({class_898.class})
public class EntityRenderDispatcherMixin {
   @ModifyVariable(
      method = {"renderHitbox"},
      ordinal = 0,
      at = @At(
   value = "STORE",
   ordinal = 0
)
   )
   private static class_238 onRenderHitboxEditBox(class_238 var0) {
      Module var1 = DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(Hitbox.class);
      return var1.isEnabled() ? var0.method_1014(((Hitbox)var1).getHitboxExpansion()) : var0;
   }
}
