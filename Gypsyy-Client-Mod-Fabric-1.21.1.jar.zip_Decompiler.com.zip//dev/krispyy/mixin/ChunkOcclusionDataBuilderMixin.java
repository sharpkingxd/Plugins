package dev.krispyy.mixin;

import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy;
import dev.krispyy.manager.EventManager;
import net.minecraft.class_2338;
import net.minecraft.class_852;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_852.class})
public abstract class ChunkOcclusionDataBuilderMixin {
   @Inject(
      method = {"markClosed"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onMarkClosed(class_2338 var1, CallbackInfo var2) {
      invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy var3 = new invokeConnorftw_KRISPYYCLIENT_SQGsCqxdiwKctwNOpfcbNSrAVozujzVvxnVvonrqAzoNmYnPnSy();
      EventManager.b(var3);
      if (var3.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw()) {
         var2.cancel();
      }

   }
}
