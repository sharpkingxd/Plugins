package dev.krispyy.mixin;

import dev.krispyy.DonutBBC;
import dev.krispyy.module.Module;
import dev.krispyy.module.modules.misc.AutoFirework;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_1799.class})
public class ItemStackMixin {
   @Inject(
      method = {"decrement"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onDecrement(int var1, CallbackInfo var2) {
      if (DonutBBC.INSTANCE != null && DonutBBC.INSTANCE.MODULE_MANAGER != null) {
         Module var3 = DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(AutoFirework.class);
         if (var3 != null && var3.isEnabled()) {
            class_1799 var4 = (class_1799)this;
            if (var4.method_31574(class_1802.field_8639)) {
               try {
                  Field var5 = var3.getClass().getDeclaredField("antiConsume");
                  var5.setAccessible(true);
                  Object var6 = var5.get(var3);
                  Method var7 = var6.getClass().getMethod("getValue");
                  boolean var8 = (Boolean)var7.invoke(var6);
                  if (var8) {
                     var2.cancel();
                  }
               } catch (Exception var9) {
               }
            }
         }
      }

   }
}
