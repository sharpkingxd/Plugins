package dev.krispyy.mixin;

import dev.krispyy.module.modules.misc.PearlBoost;
import net.minecraft.class_1684;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_1684.class})
public class EnderPearlVelocityMixin {
   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void boostVelocityOnFirstTick(CallbackInfo var1) {
      class_1684 var2 = (class_1684)this;
      if (var2.field_6012 <= 1) {
         System.out.println("BOOSTING PEARL!");
         PearlBoost var3 = PearlBoost.getInstance();
         System.out.println("Module enabled: " + var3.isEnabled());
         double var4 = var3.getMultiplier();
         System.out.println("Multiplier: " + var4);
         class_243 var6 = var2.method_18798();
         System.out.println("Old velocity: " + String.valueOf(var6));
         var2.method_18799(var6.method_1021(var4));
         class_243 var7 = var2.method_18798();
         System.out.println("New velocity: " + String.valueOf(var7));
         System.out.println("---");
      }

   }
}
