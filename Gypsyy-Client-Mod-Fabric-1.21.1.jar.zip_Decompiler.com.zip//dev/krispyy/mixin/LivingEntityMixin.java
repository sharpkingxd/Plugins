package dev.krispyy.mixin;

import dev.krispyy.DonutBBC;
import dev.krispyy.module.modules.render.SwingSpeed;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1309.class})
public class LivingEntityMixin {
   @Inject(
      method = {"getHandSwingDuration"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void getHandSwingDurationInject(CallbackInfoReturnable<Integer> var1) {
      if (DonutBBC.INSTANCE != null && DonutBBC.mc != null) {
         SwingSpeed var2 = (SwingSpeed)DonutBBC.INSTANCE.getModuleManager().getModuleByClass(SwingSpeed.class);
         if (var2 != null && var2.isEnabled()) {
            var1.setReturnValue(var2.getSwingSpeed().getIntValue());
         }
      }

   }
}
