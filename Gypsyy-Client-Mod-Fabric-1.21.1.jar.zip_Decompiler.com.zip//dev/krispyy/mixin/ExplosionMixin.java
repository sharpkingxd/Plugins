package dev.krispyy.mixin;

import dev.krispyy.DonutBBC;
import dev.krispyy.module.modules.render.NoRender;
import net.minecraft.class_1541;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_1541.class})
public class ExplosionMixin {
   @Inject(
      method = {"tick"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onTick(CallbackInfo var1) {
      if (DonutBBC.INSTANCE != null) {
         NoRender var2 = (NoRender)DonutBBC.INSTANCE.getModuleManager().getModuleByClass(NoRender.class);
         if (var2 != null && var2.isEnabled() && !var2.shouldRenderExplosions()) {
            class_1541 var3 = (class_1541)this;
            var3.method_31472();
            var1.cancel();
         }
      }

   }
}
