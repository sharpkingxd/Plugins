package dev.krispyy.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_897.class})
public abstract class EntityRendererMixin<T extends class_1297> {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void onRenderHead(T var1, float var2, float var3, class_4587 var4, class_4597 var5, int var6, CallbackInfo var7) {
   }

   @Inject(
      method = {"render"},
      at = {@At("RETURN")}
   )
   private void onRenderReturn(T var1, float var2, float var3, class_4587 var4, class_4597 var5, int var6, CallbackInfo var7) {
   }
}
