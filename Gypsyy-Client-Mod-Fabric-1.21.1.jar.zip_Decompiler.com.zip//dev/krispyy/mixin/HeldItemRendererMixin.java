package dev.krispyy.mixin;

import dev.krispyy.DonutBBC;
import dev.krispyy.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_EiortVMDbqPwnzxhYnnkDtPyhPoxsvegCzLOUHXwBFydGw.invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku;
import dev.krispyy.module.modules.render.Animations;
import dev.krispyy.module.modules.render.NoRender;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1806;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin({class_759.class})
public abstract class HeldItemRendererMixin {
   @Inject(
      method = {"renderFirstPersonItem"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"
)}
   )
   private void onRenderItem(class_742 var1, float var2, float var3, class_1268 var4, float var5, class_1799 var6, float var7, class_4587 var8, class_4597 var9, int var10, CallbackInfo var11) {
      if (DonutBBC.mc.field_1724 != null && DonutBBC.mc.field_1687 != null) {
         invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku var12 = new invokeConnorftw_KRISPYYCLIENT_erkvmumVarZwxyVgLnAtoUyskfCjjgAhku(var4, var6, var7, var8);
         DonutBBC.INSTANCE.getEventBus().a(var12);
      }
   }

   @Inject(
      method = {"renderFirstPersonItem"},
      at = {@At("HEAD")}
   )
   private void onRenderItemHook(class_742 var1, float var2, float var3, class_1268 var4, float var5, class_1799 var6, float var7, class_4587 var8, class_4597 var9, int var10, CallbackInfo var11) {
      Animations var12 = (Animations)DonutBBC.INSTANCE.getModuleManager().getModuleByClass(Animations.class);
      if (var12 != null && var12.isEnabled() && var12.shouldAnimate() && !var6.method_7960() && !(var6.method_7909() instanceof class_1806)) {
         var12.applyTransformations(var8, var5);
      }

   }

   @Inject(
      method = {"renderFirstPersonItem"},
      at = {@At("RETURN")}
   )
   private void onRenderItemPost(class_742 var1, float var2, float var3, class_1268 var4, float var5, class_1799 var6, float var7, class_4587 var8, class_4597 var9, int var10, CallbackInfo var11) {
      Animations var12 = (Animations)DonutBBC.INSTANCE.getModuleManager().getModuleByClass(Animations.class);
      if (var12 != null && var12.isEnabled() && var12.shouldAnimate() && !var6.method_7960() && !(var6.method_7909() instanceof class_1806)) {
         var8.method_22909();
      }

   }

   @ModifyArgs(
      method = {"renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"
)
   )
   private void renderItem(Args var1) {
      NoRender var2 = (NoRender)DonutBBC.INSTANCE.getModuleManager().getModuleByClass(NoRender.class);
      if (var2 != null && var2.isEnabled() && !var2.shouldRenderSwing()) {
         var1.set(6, 0.0F);
      }

   }
}
