package dev.krispyy.mixin;

import dev.krispyy.DonutBBC;
import dev.krispyy.module.modules.render.NoRender;
import net.minecraft.class_2394;
import net.minecraft.class_702;
import net.minecraft.class_703;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_702.class})
public class ParticleManagerMixin {
   @Inject(
      method = {"addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onAddParticle(class_2394 var1, double var2, double var4, double var6, double var8, double var10, double var12, CallbackInfoReturnable<class_703> var14) {
      if (DonutBBC.INSTANCE != null) {
         NoRender var15 = (NoRender)DonutBBC.INSTANCE.getModuleManager().getModuleByClass(NoRender.class);
         if (var15 != null && var15.isEnabled()) {
            if (!var15.shouldRenderParticles()) {
               var14.setReturnValue((Object)null);
               return;
            }

            if (!var15.shouldRenderExplosions() && this.isExplosionParticle(var1)) {
               var14.setReturnValue((Object)null);
               return;
            }

            if (!var15.shouldRenderSmoke() && this.isSmokeParticle(var1)) {
               var14.setReturnValue((Object)null);
               return;
            }
         }
      }

   }

   private boolean isExplosionParticle(class_2394 var1) {
      String var2 = var1.method_10295().toString().toLowerCase();
      return var2.contains("explosion") || var2.contains("explode") || var2.contains("blast") || var2.contains("boom");
   }

   private boolean isSmokeParticle(class_2394 var1) {
      String var2 = var1.method_10295().toString().toLowerCase();
      return var2.contains("smoke") || var2.contains("cloud") || var2.contains("fume");
   }
}
