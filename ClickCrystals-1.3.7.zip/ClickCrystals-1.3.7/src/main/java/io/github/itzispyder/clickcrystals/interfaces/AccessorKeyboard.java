package io.github.itzispyder.clickcrystals.interfaces;

public interface AccessorKeyboard {

    void pressKey(int key, int scan);
}
