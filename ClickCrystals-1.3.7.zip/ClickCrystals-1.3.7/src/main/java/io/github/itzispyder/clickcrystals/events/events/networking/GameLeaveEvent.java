package io.github.itzispyder.clickcrystals.events.events.networking;

import io.github.itzispyder.clickcrystals.events.Event;

public class GameLeaveEvent extends Event {

    public GameLeaveEvent() {

    }
}
