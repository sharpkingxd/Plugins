package io.github.itzispyder.clickcrystals.events.events.world;

import io.github.itzispyder.clickcrystals.events.Event;

public class ClientTickEndEvent extends Event {

    public ClientTickEndEvent() {

    }
}
