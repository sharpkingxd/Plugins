package io.github.itzispyder.clickcrystals.gui.misc.callbacks;

@FunctionalInterface
public interface MouseMoveCallback {

    void handleMouse(double mouseX, double mouseY);
}
