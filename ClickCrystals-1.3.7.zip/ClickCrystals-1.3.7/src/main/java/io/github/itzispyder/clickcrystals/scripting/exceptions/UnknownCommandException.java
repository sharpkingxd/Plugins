package io.github.itzispyder.clickcrystals.scripting.exceptions;

public class UnknownCommandException extends RuntimeException {

    public UnknownCommandException(String msg) {
        super(msg);
    }
}
