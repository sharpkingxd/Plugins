package io.github.itzispyder.clickcrystals.client;

import net.fabricmc.api.ClientModInitializer;

public final class ClickCrystalsClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {

    }
}
