package io.github.itzispyder.clickcrystals.modules;

import net.minecraft.util.Identifier;

public record Category(String name, Identifier texture) {

}
