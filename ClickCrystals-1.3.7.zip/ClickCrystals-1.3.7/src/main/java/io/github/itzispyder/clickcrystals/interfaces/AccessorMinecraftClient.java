package io.github.itzispyder.clickcrystals.interfaces;

public interface AccessorMinecraftClient {

    void inputAttack();

    void inputUse();
}
