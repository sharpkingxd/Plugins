package io.github.itzispyder.clickcrystals.modules.modules.misc;

import io.github.itzispyder.clickcrystals.modules.Categories;
import io.github.itzispyder.clickcrystals.modules.Module;

public class NoBreakDelay extends Module {

    public NoBreakDelay() {
        super("no-break-delay", Categories.MISC, "No block break delay [flags-anticheat]");
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
