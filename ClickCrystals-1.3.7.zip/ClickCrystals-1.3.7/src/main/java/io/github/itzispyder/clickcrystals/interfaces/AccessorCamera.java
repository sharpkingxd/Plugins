package io.github.itzispyder.clickcrystals.interfaces;

public interface AccessorCamera {

    void setCameraRotation(float pitch, float yaw);
}
