package io.github.itzispyder.clickcrystals.events;

import io.github.itzispyder.clickcrystals.Global;

public interface Listener extends Global {

}
