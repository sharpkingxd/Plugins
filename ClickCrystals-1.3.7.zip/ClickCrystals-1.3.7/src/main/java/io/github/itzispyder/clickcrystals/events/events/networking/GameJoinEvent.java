package io.github.itzispyder.clickcrystals.events.events.networking;

import io.github.itzispyder.clickcrystals.events.Event;

public class GameJoinEvent extends Event {

    public GameJoinEvent() {

    }
}
