package io.github.itzispyder.clickcrystals.modules.modules.clickcrystals;

import io.github.itzispyder.clickcrystals.modules.Categories;
import io.github.itzispyder.clickcrystals.modules.Module;

public class GuiBorders extends Module {
    
    public GuiBorders() {
        super("gui-borders", Categories.CLIENT, "DEBUG: Renders borders around all ClickCrystals GUI elements");
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
