package io.github.itzispyder.clickcrystals.modules.modules.rendering;

import io.github.itzispyder.clickcrystals.modules.Categories;
import io.github.itzispyder.clickcrystals.modules.Module;

public class SlowSwing extends Module {

    public SlowSwing() {
        super("slow-hand-swing", Categories.RENDER,"Makes your hand swing as if you had mining fatigue");
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
