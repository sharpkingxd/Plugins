package io.github.itzispyder.clickcrystals.events;

import io.github.itzispyder.clickcrystals.Global;

public abstract class Event implements Global {

}
