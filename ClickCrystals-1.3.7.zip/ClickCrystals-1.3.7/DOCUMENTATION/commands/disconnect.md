[<-- Back to Legend](../legend.md)

# Command Name: Disconnect
Keyword: disconnect

### Usages
```
disconnect
```

### Regex
```regexp
(((disconnect)))
```

### Raw Documentation
```yml
# disconnect
```
