[<-- Back to Legend](../legend.md)

# Command Name: Desc
Keyword: desc

### Usages
```
desc "..."
```

### Regex
```regexp
(((desc)( (\"((\\\")|[^\"])*\"))))
```

### Raw Documentation
```yml
# desc "..."
```
