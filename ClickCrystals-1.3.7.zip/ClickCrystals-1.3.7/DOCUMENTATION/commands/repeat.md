[<-- Back to Legend](../legend.md)

# Command Name: Repeat
Keyword: repeat

### Usages
```
repeat <int> {}
```

### Regex
```regexp
(((repeat)( (-?\d+))))
```

### Raw Documentation
```yml
# repeat <int> {}
```
