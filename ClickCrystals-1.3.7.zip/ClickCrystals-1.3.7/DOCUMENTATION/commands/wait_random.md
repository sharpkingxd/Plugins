[<-- Back to Legend](../legend.md)

# Command Name: Wait Random
Keyword: wait_random

### Usages
```
wait_random <num> <num> {}
```

### Regex
```regexp
(((wait_random)( (-?\d*(\.\d*)?))( (-?\d*(\.\d*)?))))
```

### Raw Documentation
```yml
# wait_random <num> <num> {}
```
