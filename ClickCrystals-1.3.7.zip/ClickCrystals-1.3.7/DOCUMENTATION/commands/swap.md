[<-- Back to Legend](../legend.md)

# Command Name: Swap
Keyword: swap

### Usages
```
swap
```

### Regex
```regexp
(((swap)))
```

### Raw Documentation
```yml
# swap
```
