[<-- Back to Legend](../legend.md)

# Command Name: Gui Quickmove
Keyword: gui_quickmove

### Usages
```
gui_quickmove <identifier> <int>?
```

### Regex
```regexp
(((gui_quickmove)( !?(([#:](\w+)(\[(.*)\])?,?)+))( (-?\d+))?))
```

### Raw Documentation
```yml
# gui_quickmove <identifier> <int>?
```
