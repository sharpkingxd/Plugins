[<-- Back to Legend](../legend.md)

# Command Name: Exit
Keyword: exit

### Usages
```
exit <int>
```

### Regex
```regexp
(((exit)( (-?\d+))))
```

### Raw Documentation
```yml
# exit <int>
```
