[<-- Back to Legend](../legend.md)

# Command Name: Gui Switch
Keyword: gui_switch

### Usages
```
gui_switch <identifier>
```

### Regex
```regexp
(((gui_switch)( !?(([#:](\w+)(\[(.*)\])?,?)+))))
```

### Raw Documentation
```yml
# gui_switch <identifier>
```
