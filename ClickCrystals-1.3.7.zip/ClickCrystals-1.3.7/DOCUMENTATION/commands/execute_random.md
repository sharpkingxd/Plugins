[<-- Back to Legend](../legend.md)

# Command Name: Execute Random
Keyword: execute_random

### Usages
```
execute_random {}
```

### Regex
```regexp
(((execute_random)))
```

### Raw Documentation
```yml
# execute_random {}
```
