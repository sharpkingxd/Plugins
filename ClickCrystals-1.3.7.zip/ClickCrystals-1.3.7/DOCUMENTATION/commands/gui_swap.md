[<-- Back to Legend](../legend.md)

# Command Name: Gui Swap
Keyword: gui_swap

### Usages
```
gui_swap <identifier>
```

### Regex
```regexp
(((gui_swap)( !?(([#:](\w+)(\[(.*)\])?,?)+))))
```

### Raw Documentation
```yml
# gui_swap <identifier>
```
