[<-- Back to Legend](../legend.md)

# Command Name: Config
Keyword: config

### Usages
```
config load
config reload
config save
```

### Regex
```regexp
(((config)( (save|load|reload))))
```

### Raw Documentation
```yml
# config (save|load|reload)
```
