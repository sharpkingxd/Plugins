[<-- Back to Legend](../legend.md)

# Command Name: Notify
Keyword: notify

### Usages
```
notify "..."
```

### Regex
```regexp
(((notify)( (\"((\\\")|[^\"])*\"))))
```

### Raw Documentation
```yml
# notify "..."
```
