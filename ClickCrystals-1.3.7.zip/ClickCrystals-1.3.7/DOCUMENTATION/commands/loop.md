[<-- Back to Legend](../legend.md)

# Command Name: Loop
Keyword: loop

### Usages
```
loop <int> {}
```

### Regex
```regexp
(((loop)( (-?\d+))))
```

### Raw Documentation
```yml
# loop <int> {}
```
