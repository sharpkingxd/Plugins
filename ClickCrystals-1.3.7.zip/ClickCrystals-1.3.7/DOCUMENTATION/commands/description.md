[<-- Back to Legend](../legend.md)

# Command Name: Description
Keyword: description

### Usages
```
description "..."
```

### Regex
```regexp
(((description)( (\"((\\\")|[^\"])*\"))))
```

### Raw Documentation
```yml
# description "..."
```
