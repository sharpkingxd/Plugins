[<-- Back to Legend](../legend.md)

# Command Name: Say
Keyword: say

### Usages
```
say "..."
```

### Regex
```regexp
(((say)( (\"((\\\")|[^\"])*\"))))
```

### Raw Documentation
```yml
# say "..."
```
