[<-- Back to Legend](../legend.md)

# Command Name: Send
Keyword: send

### Usages
```
send "..."
```

### Regex
```regexp
(((send)( (\"((\\\")|[^\"])*\"))))
```

### Raw Documentation
```yml
# send "..."
```
