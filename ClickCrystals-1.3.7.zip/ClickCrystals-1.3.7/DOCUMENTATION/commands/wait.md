[<-- Back to Legend](../legend.md)

# Command Name: Wait
Keyword: wait

### Usages
```
wait <num> {}
```

### Regex
```regexp
(((wait)( (-?\d*(\.\d*)?))))
```

### Raw Documentation
```yml
# wait <num> {}
```
