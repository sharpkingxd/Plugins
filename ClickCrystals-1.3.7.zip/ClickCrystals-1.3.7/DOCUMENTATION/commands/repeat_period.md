[<-- Back to Legend](../legend.md)

# Command Name: Repeat Period
Keyword: repeat_period

### Usages
```
repeat_period <int> <num> {}
```

### Regex
```regexp
(((repeat_period)( (-?\d+))( (-?\d*(\.\d*)?))))
```

### Raw Documentation
```yml
# repeat_period <int> <num> {}
```
