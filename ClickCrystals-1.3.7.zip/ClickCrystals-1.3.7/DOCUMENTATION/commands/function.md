[<-- Back to Legend](../legend.md)

# Command Name: Function
Keyword: function

### Usages
```
function ...
```

### Regex
```regexp
(((function)( (\S+))))
```

### Raw Documentation
```yml
# function ...
```
