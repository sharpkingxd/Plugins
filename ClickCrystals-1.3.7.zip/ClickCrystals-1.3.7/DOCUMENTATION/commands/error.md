[<-- Back to Legend](../legend.md)

# Command Name: Error
Keyword: error

### Usages
```
error "..."
```

### Regex
```regexp
(((error)( (\"((\\\")|[^\"])*\"))))
```

### Raw Documentation
```yml
# error "..."
```
