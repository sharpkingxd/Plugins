[<-- Back to Legend](../legend.md)

# Command Name: Loop Period
Keyword: loop_period

### Usages
```
loop_period <int> <num> {}
```

### Regex
```regexp
(((loop_period)( (-?\d+))( (-?\d*(\.\d*)?))))
```

### Raw Documentation
```yml
# loop_period <int> <num> {}
```
