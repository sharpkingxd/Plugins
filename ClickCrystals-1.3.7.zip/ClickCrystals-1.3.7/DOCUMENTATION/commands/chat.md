[<-- Back to Legend](../legend.md)

# Command Name: Chat
Keyword: chat

### Usages
```
chat "..."
```

### Regex
```regexp
(((chat)( (\"((\\\")|[^\"])*\"))))
```

### Raw Documentation
```yml
# chat "..."
```
