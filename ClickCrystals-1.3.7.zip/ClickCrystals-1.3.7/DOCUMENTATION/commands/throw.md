[<-- Back to Legend](../legend.md)

# Command Name: Throw
Keyword: throw

### Usages
```
throw "..."
```

### Regex
```regexp
(((throw)( (\"((\\\")|[^\"])*\"))))
```

### Raw Documentation
```yml
# throw "..."
```
