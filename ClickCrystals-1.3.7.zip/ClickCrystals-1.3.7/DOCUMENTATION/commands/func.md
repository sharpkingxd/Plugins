[<-- Back to Legend](../legend.md)

# Command Name: Func
Keyword: func

### Usages
```
func ...
```

### Regex
```regexp
(((func)( (\S+))))
```

### Raw Documentation
```yml
# func ...
```
