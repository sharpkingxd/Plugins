[<-- Back to Legend](../legend.md)

# Command Name: Execute
Keyword: execute

### Usages
```
execute {}
```

### Regex
```regexp
(((execute)))
```

### Raw Documentation
```yml
# execute {}
```
