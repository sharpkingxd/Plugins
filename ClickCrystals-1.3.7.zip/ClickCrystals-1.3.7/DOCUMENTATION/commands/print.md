[<-- Back to Legend](../legend.md)

# Command Name: Print
Keyword: print

### Usages
```
print "..."
```

### Regex
```regexp
(((print)( (\"((\\\")|[^\"])*\"))))
```

### Raw Documentation
```yml
# print "..."
```
