[<-- Back to Legend](../legend.md)

# Command Name: Velocity
Keyword: velocity

### Usages
```
velocity <x> <y> <z>
```

### Regex
```regexp
(((velocity)( ([\^~]?-?\d*(\.\d*)?))( ([\^~]?-?\d*(\.\d*)?))( ([\^~]?-?\d*(\.\d*)?))))
```

### Raw Documentation
```yml
# velocity <x> <y> <z>
```
